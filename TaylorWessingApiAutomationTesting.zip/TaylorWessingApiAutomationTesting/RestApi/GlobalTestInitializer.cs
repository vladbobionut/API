﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using RestApi.FrameworkConfiguration;
using System.Diagnostics;

namespace RestApi
{
    [TestClass]
    public class GlobalTestInitializer
    {
        public static string Token;

        [AssemblyInitialize()]
        public async static Task ClassInitializeAsync(TestContext testContext)
        {
#if DEBUG
            Environment.SetEnvironmentVariable(EnvironmentVariable.ASPNETCORE_VARIABLE_KEY, "QA");

#endif
            Trace.TraceWarning($"API tests environment:{Environment.GetEnvironmentVariable(EnvironmentVariable.ASPNETCORE_VARIABLE_KEY)}");
            Debug.WriteLine($"API tests environment:{Environment.GetEnvironmentVariable(EnvironmentVariable.ASPNETCORE_VARIABLE_KEY)}");
        }
    }
}