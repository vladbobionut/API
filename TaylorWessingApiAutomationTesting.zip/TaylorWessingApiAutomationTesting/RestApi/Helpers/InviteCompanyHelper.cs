﻿using FluentAssertions;
using Microsoft.Extensions.DependencyInjection;
using Outpace.Models.Company;
using Outpace.Models.Enum;
using RestApi.FrameworkConfiguration;
using RestApi.Interfaces;
using RestApi.Models.Company;

namespace Outpace.Helpers
{
    public class InviteCompanyHelper
    {
        public static async Task InviteCompany(string token,string email,CompanyType companyType,string invitationMessage,bool isFounder,ReasonPhraseType ReasonPhrase)
        {
            var inviteCompany = new InviteUserRequest
            {
                Email = email,
                CompanyType = companyType,
                InvitationMessage = invitationMessage,
                IsFounder = isFounder
            };

            // Act
            var response = await DI.Container.GetService<IRestClient>().Post(inviteCompany, "AppUser/Invite", token);
            if (ReasonPhrase == ReasonPhraseType.Created)
            {
                response.ReasonPhrase.Should().Be(ReasonPhrase.Name);               
            }
            else
            {
            
            }
        }
    }
}