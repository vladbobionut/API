﻿using FluentAssertions;
using Microsoft.Extensions.DependencyInjection;
using Outpace.Models.Enum;
using RestApi.FrameworkConfiguration;
using RestApi.Interfaces;
using RestApi.Models.Company;
using RestApi.Models.Enum;
using RestApi.Models.ShareClass;
using System.Text.Json;

namespace Outpace.Helpers
{
    public static class ShareClassHelper
    {
        public static async Task<Guid> CreateShareClass(string token, Guid companyId, bool antiDilution, bool hurdle, decimal hurdleSharePrice, bool isEntitledForDividends, bool isEntitledForVoting,
            decimal liquidationCap, int liquidationDaysPerYear, decimal liquidationInterest, decimal liquidationMultiple, bool liquidationParticipating, 
            bool liquidationPreference, decimal liquidationSeniority, string shareClassName, decimal votingRightWeight, AntiDilutionType antiDilutionType, ReasonPhraseType ReasonPhrase)
        {
            var shareClassAntiDilutionWAB = new ShareClassCreateRequest()
            {
                AntiDilution = antiDilution,
                Hurdle = hurdle,
                HurdleSharePrice = hurdleSharePrice,
                IsEntitledForDividends = isEntitledForDividends,
                IsEntitledForVoting = isEntitledForVoting,
                LiquidationCap = liquidationCap,
                LiquidationDaysPerYear = liquidationDaysPerYear,
                LiquidationInterest = liquidationInterest,
                LiquidationMultiple = liquidationMultiple,
                LiquidationParticipating = liquidationParticipating,
                LiquidationPreference = liquidationPreference,
                LiquidationSeniority = liquidationSeniority,
                Name = shareClassName,
                VotingRightWeight = votingRightWeight,
                AntiDilutionType = antiDilutionType,
            };
            var shareClass = await DI.Container.GetService<IRestClient>().Post(shareClassAntiDilutionWAB, $"CapTable/CreateShareClass?companyId={companyId}", token);
            if (ReasonPhrase == ReasonPhraseType.OK)
            {
                shareClass.ReasonPhrase.Should().Be(ReasonPhrase.Name);
                string apiResponse = await shareClass.Content.ReadAsStringAsync();
                var responseModel = JsonSerializer.Deserialize<CompanyDto>(apiResponse, new JsonSerializerOptions() { PropertyNameCaseInsensitive = true });
                return responseModel.Id;
            }
            else
            {
                shareClass.ReasonPhrase.Should().Be(ReasonPhrase.Name);
                return Guid.Empty;
            }
        }
    }
}