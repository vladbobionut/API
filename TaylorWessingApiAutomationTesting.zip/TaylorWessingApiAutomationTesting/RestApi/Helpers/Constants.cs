﻿using Stripe.Checkout;

namespace RestApi.Helpers
{
    public static class Constants
    {
        // general constants
        public static string AddressLine1 = " Razboinei 44";
        public static string AddressLine2 = "Automation tests";
        public static string PhoneNumber = "0745151562";
        public static string Postcode = "13245";
        public static string CompanyHouseNumber = "12345678";

        //Company - Board pack
        public static string FirstAttendee = "First attendee";
        public static string SecondAttendee = "Second attendee";
        public static string ThirdAttendee = "Third attendee";
        public static string FirstDiscussionPointTitle = "Just a siple test";
        public static string SecondDiscussionPointTitle = "This is another test";
        public static string Venue = "This is just a simple test";
        public static string DiscussionPointFirstLink = "https://www.youtube.com/";
        public static string DiscussionPointSecondLink = "https://dejeanul.ro/";
        public static string Category = "Board meeting";
        public static string FirstAttendeName = "First attendee";
        public static string SecondAttendeName = "Second attendee";
        public static string ThirdAttendeName = "Third attendee";
        public static string UpdateDiscussionPointLink = "www.sport.ro";
        public static string UpdateDiscussionPointNotes = "this is a note";
        public static string UpdateDiscussionPointTitle = "Just a siple test";
        public static string UpdateThirdBoardDiscussionNote = "additional key notes for additional discusiion point";
        public static string UpdateThirdBoardDiscussionTitle = "additional key notes";
        public static string EditFirstAttendee = "vlad one";
        public static string EditSecondAttendee = "vlad doi";
        public static string EditThirdAttendee = "vlad trei";

        //Create stakeholders
        public static string PersonStakeholderFirstName = "Person";
        public static string PersonFounderLastName = "FounderP";
        public static string PersonInvestorLastName = "Investor";
        public static string EntityLastName = "Entity";
        public static string EntityFounderFirstName = "FounderE";
        public static string EntityInvestorFirstName = "InvestorE";
        public static string EmployeeLastName = "Employee";
        public static string InvestorEmail = "investor.automation@root.ro";
        public static string FounderEmail = "founder.automation@root.ro";

        //Create share classes
        public static string ShareClassName = "Ordinary Share Class";
        public static string AntiDilutionWab = "Anti-Dilution - WAB";
        public static string AntiDilutionWan = "Anti-Dilution - WAN";
        public static string AntiDilutionFullRatchet = "Anti-Dilution - FullRatchet";
        public static string LiguidationPreferance = "Liquidation preferance";
        public static string PreferedDividedRight = "Prefered divided right";
        public static string EnchancVotingWeight = "EnhancVotingWeight";
        public static string Hurdle = "Hurdle";

        // Create company - startup and institution
        public static string City = "London";
        public static string CompanyName = "Automation Startup" + DateTime.Today.ToString();
        public static string Currency = "GBP";
        public static DateTime IncorporatedDate = DateTime.Now.AddDays(-10);
        public static string CompaniesHouseNumber = "12345678";

        // Create Share Subdivision transaction
        public static DateTime DateNow = DateTime.UtcNow;
        public static int SplitFactor = 1000;

        // Create Share transfer transaction
        public static DateTime DateShareTansfer = new DateTime(2023, 5, 26);
        public static string EventName = "AddShareTransfer";
        public static int NumberOfShares = 100;

        // Create Incorporation transaction
        public static DateTime CloseDate = DateTime.UtcNow.AddDays(-4);
        public static string IncorporationName = "Incorporation Name";
        public static int PricePerShare = 1;
        public static decimal InvestmentAmount = 10000;
        public static int ShareQuantity = 10000;
        public static string TransactionTypeName = "Incorporation";
        public static decimal InvestmentAmountSecond = 15000;
        public static int ShareQuantitySecond = 15000;

        //create option pool transaction
        public static string PoolName = "Option Pool Automation test";
        public static decimal PoolPercentage = 10;
        public static int PoolSize = 111111;
        public static int NewPoolSize = 1133;

        //create option plan transaction
        public static string OptionPlanName = "option plan name automation";
        public static int OptionPlanCliff = 12;
        public static string Name = "Option Plan";
        public static decimal StrikePrice = 20;
        public static int VestingDuration = 48;
        public static int VestingFrequency = 12;

        //create granted transaction
        public static int CliffOpionsGranted = 0;
        public static int NumberOfGrants = 1000;
        public static int VestingDurationGranted = 0;
        public static int vestingFrequencyGranted = 0;
        public static string EmployeeName = "Employee Person";

        //create price round transaction
        public static decimal CommitedAmount = 10000;
        public static decimal PriceRoundPricePerShare = 50;
        public static string PriceRoundName = "FoundingRound";
        public static long PriceRoundIssuedShareCapiatal = 10000;
        public static decimal PriceRoundPreMoenyEvaluation = 500000;

        //nominal value per share
        public static string NominalValuePerShare = "0.000001000000000";

        //Home page 
        public static int HomePageStakeholderCount = 1;
        public static decimal HomePageTotalInvested = 0;
        public static decimal HomePageLatestTransaction = 0;
        public static int HomePageFullyGrantedShares = 0;
        
        //Cap table
        public static string StakeholderName = "Founder";
        public static int IssuedShares = 1000000;
        public static decimal SharesPercentage = 100;
        public static string Ordinary = "Ordinary";
        public static string OrdinaryShares = "Ordinary shares";
        public static string EquityPlansGrantable="Equity plans grantable";
        public static string Issued = "Issued (%)";
        public static string CapTableFounder = "Founder";
        public static string Total = "Total";
        public static string FullyDiluted = "Fully Diluted (%)";
        public static string Vote = "Vote (%)";
        public static string Detailed = "Detailed";
        public static string CapTableInvestor = "Investor";
        public static string Summary = "Summary";
        public static string Option = "Options";
        public static decimal OptionPoolValue = 1111111M;
        public static int CapTableNoValue = 0;

        //Ask for Help
        public static string Subject = "Just a simple test";
        public static string OutplacePlatformIssues = "Outpace platform issues";

        //Create users
        public static string IAFirstName = "Institution";
        public static string IALastName = "AdminAuto";
        public static string LawyerFirstName = "George";
        public static string LawyerLastName = "Lawyer";
        public static string PaFirstName = "Mihai";
        public static string PaLastName = "LastName";
    }
}