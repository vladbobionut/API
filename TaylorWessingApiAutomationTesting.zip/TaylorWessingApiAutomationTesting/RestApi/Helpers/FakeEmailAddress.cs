﻿namespace RestApi.Helpers
{
    public class FakeEmailAddress
    {
        public static string GenerateRandomAlphabetString(int length)
        {
            string allowedChars = "abcdefghijklmnopqrstuvwyxzABCDEFGHIJKLMNOPQRSTUVWXYZ";
            var rnd = SeedRandom();

            char[] chars = new char[length];
            for (int i = 0; i < length; i++)
            {
                chars[i] = allowedChars[rnd.Next(allowedChars.Length)];
            }

            return new string(chars);
        }
        private static Random SeedRandom()
        {
            return new Random(Guid.NewGuid().GetHashCode());
        }

        public static string GetFakeEmailAddress()
        {
            Random rnd = new Random();
            int nr1 = rnd.Next(1, 10);
            int nr2 = rnd.Next(1, 10);
            return string.Format("{0}@{1}.com", GenerateRandomAlphabetString(nr1), GenerateRandomAlphabetString(nr2));
        }
    }
}