﻿using FluentAssertions;
using Microsoft.Extensions.DependencyInjection;
using Outpace.Models.Enum;
using RestApi.FrameworkConfiguration;
using RestApi.Interfaces;
using RestApi.Models.Company;
using RestApi.Models.Enum;
using System.Text.Json;

namespace RestApi.Helpers
{
    public static class CompanyHelper
    {
        public static async Task<Guid> CreateStartupCompany(string token, CompanyType companyType, CompanyStructure companyStructure, Jurisdiction jurisdiction, ReasonPhraseType ReasonPhrase, string? name = null)
        {
            var model = new CompanyCreateRequest()
            {
                AddressLine1 = Constants.AddressLine1,
                AddressLine2 = Constants.AddressLine2,
                AssociatedInstitutionId = null,
                City = Constants.City,
                CompanyName = name == null ? "Automation Startup" + DateTime.Today.ToString() : name,
                CompanyStructure = companyStructure,
                CompanyType = companyType,
                CountryId = await CountryHelper.GetCountryId(token),
                Currency = Constants.Currency,
                IncorporatedDate = DateTime.Now.AddDays(-10),
                Postcode = Constants.Postcode,
                Jurisdiction = jurisdiction,
                CompaniesHouseNumber = Constants.CompaniesHouseNumber
            };

            //Create company fields 
            var response = await DI.Container.GetService<IRestClient>().Post(model, "company/create", token);
            if (ReasonPhrase == ReasonPhraseType.Created)
            {
                response.ReasonPhrase.Should().Be(ReasonPhrase.Name);
                string apiResponse = await response.Content.ReadAsStringAsync();
                var responseModel = JsonSerializer.Deserialize<CompanyDto>(apiResponse, new JsonSerializerOptions() { PropertyNameCaseInsensitive = true });
                return responseModel.Id;
            }
            else
            {
                response.ReasonPhrase.Should().Be(ReasonPhrase.Name);
                return Guid.Empty;
            } 
                
        }
    }
}