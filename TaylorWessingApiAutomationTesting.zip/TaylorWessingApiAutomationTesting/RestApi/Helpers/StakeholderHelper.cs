﻿using FluentAssertions;
using Microsoft.Extensions.DependencyInjection;
using Outpace.Models.Enum;
using RestApi.FrameworkConfiguration;
using RestApi.Interfaces;
using RestApi.Models.Company;
using RestApi.Models.CreateUser;
using RestApi.Models.Enum;
using System.Text.Json;

namespace Outpace.Helpers
{
    public static class StakeholderHelper
    {
        public static async Task<Guid> CreateStakeholder(string token, Guid companyId, AccessType accessType, bool legalEntity,
            UserCreationType userCreationType, string lastName, string firstName, string phoneNumber, string addressLine1,
            string addressLine2, string postalCode, string city, bool isShareHolder, string email, DateTime birthDate, ReasonPhraseType ReasonPhrase)
        {
            var stakeholderCreateRequest = new ApplicationUserCreateRequest()
            {
                CompanyIds = new List<Guid> { companyId },
                ListAccessType = new List<AccessType> { accessType },
                UserCreationType = userCreationType,
                FirstName = firstName,
                LastName = lastName,
                Email = email,
                PhoneNumber = phoneNumber,
                AddressLine1 = addressLine1,
                AddressLine2 = addressLine2,
                Postcode = postalCode,
                City = city,
                Birthdate = birthDate,
                IsShareHolder = isShareHolder,
                IsLegalEntity = legalEntity,
            };
            var stakeholder = await DI.Container.GetService<IRestClient>().Post(stakeholderCreateRequest, "AppUser/Create", token);
            if (ReasonPhrase == ReasonPhraseType.Created)
            {
                stakeholder.ReasonPhrase.Should().Be(ReasonPhrase.Name);
                string apiResponse = await stakeholder.Content.ReadAsStringAsync();
                var responseModel = JsonSerializer.Deserialize<CompanyDto>(apiResponse, new JsonSerializerOptions() { PropertyNameCaseInsensitive = true });
                return responseModel.Id;
            }
            else
            {
                stakeholder.ReasonPhrase.Should().Be(ReasonPhrase.Name);
                return Guid.Empty;
            }
        }
    }
}