﻿using Newtonsoft.Json;

namespace RestApi.Helpers
{
    internal static class HttpResponseContentExtensions
    {

        public async static Task<T> ToModelDTO<T>(this HttpResponseMessage httpResponseMessage) where T : class
        {
            return JsonConvert.DeserializeObject<T>(await httpResponseMessage.Content.ReadAsStringAsync(), new JsonSerializerSettings() { DateFormatString = "YYYY-MM-DD" });
        }

        public async static Task<string> ReadContentAsString(this HttpRequestMessage httpResponseMessage)
        {
            return await httpResponseMessage.Content.ReadAsStringAsync();
        }
    }
}