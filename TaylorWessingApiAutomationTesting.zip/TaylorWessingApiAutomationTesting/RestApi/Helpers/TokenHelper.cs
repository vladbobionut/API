﻿using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestApi.FrameworkConfiguration;
using RestApi.Interfaces;
using System.Text;

namespace RestApi.Helpers
{
    public class TokenProvider: ITokenProvider
    {
        private readonly HttpClient client = DI.Container.GetService<IHttpClientFactory>().CreateClient();

        public async Task<string> GetAccessTokenWithRole(string role)
        {
            OAuthEndpoint oAuthEndpointConfig = DI.Container.GetService<OAuthEndpoint>();
            var user = oAuthEndpointConfig.Users.FirstOrDefault(x => x.Role == role);
            return await Login(oAuthEndpointConfig.Url, user.UserName, user.Password);
        }
        private async Task<string> Login(string url, string username, string password)
        {
            var content = new StringContent(JsonConvert.SerializeObject(new { email = username, password = password }), Encoding.UTF8, "application/json");
            HttpResponseMessage accessTokenResult = await client.PostAsync(url, content);
            string responseContent = await accessTokenResult.Content.ReadAsStringAsync();
            if (!accessTokenResult.IsSuccessStatusCode)
            {
                throw new Exception($"Error obtaining token HttpStatusCode={accessTokenResult.StatusCode} Response content ={responseContent}");
            }
            JObject accessToken = JObject.Parse(responseContent);

            return accessToken["accessToken"].ToString();
        }

        public async Task<string> GetAccessTokenWithUserNameAndPassword(string username, string password)
        {
            OAuthEndpoint oAuthEndpointConfig = DI.Container.GetService<OAuthEndpoint>();
            return await Login(oAuthEndpointConfig.Url, username, password);
        }
    }
}