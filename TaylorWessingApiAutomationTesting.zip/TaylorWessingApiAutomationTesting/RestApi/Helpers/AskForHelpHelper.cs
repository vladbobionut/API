﻿using FluentAssertions;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Outpace.Models.Help;
using RestApi.FrameworkConfiguration;
using RestApi.Interfaces;
using System.Net;

namespace Outpace.Helpers
{
    public static class AskForHelpHelper
    {
        public static async Task AskForHelp(string token,Guid companyId,string subject,string descriptionMessage, IFormFile? image)
        {
            var helpRequest = new HelpRequest
            {
                DescriptionMessage = descriptionMessage,
                Subject = subject,
                CompanyId = companyId.ToString(),
                ReferenceImage = null
            };

            // Act
            var response = await DI.Container.GetService<IRestClient>().PostFormData(helpRequest, "AppUser/askForHelp", token);

            // Assert
            response.EnsureSuccessStatusCode();
            var responseContent = await response.Content.ReadAsStringAsync();
            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
        }
    }
}