﻿using System.Text.RegularExpressions;

namespace RestApi.Helpers
{
    static class StringExtensions
    {
        public static string ToLowerSplitByUnderscore(this string source)
        {
            return Regex.Replace(source, @"(?<=[A-Za-z])(?=[A-Z][a-z])|(?<=[a-z0-9])(?=[0-9]?[A-Z])", "_").ToLower();
        }
    }
}