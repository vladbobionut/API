﻿using Microsoft.Extensions.DependencyInjection;
using RestApi.FrameworkConfiguration;
using RestApi.Interfaces;
using RestApi.Models;
using RestApi.Models.Country;
using System.Text.Json;

namespace RestApi.Helpers
{
    public static class CountryHelper
    {
        public static async Task<Guid> GetCountryId(string token)
        {
            var responseCountry = await DI.Container.GetService<IRestClient>().Get("Country/GetAll", token);
            string apiResponseCountry = await responseCountry.Content.ReadAsStringAsync();
            var responseModelCountry = JsonSerializer.Deserialize<PagedResponse<CountryDto>>(apiResponseCountry);
            return responseModelCountry.Items.FirstOrDefault(x => x.Name == "United Kingdom").Id;
        }
    }
}