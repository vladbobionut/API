﻿using FluentAssertions;
using Microsoft.Extensions.DependencyInjection;
using Outpace.Models.Enum;
using Outpace.Models.Users;
using RestApi.FrameworkConfiguration;
using RestApi.Helpers;
using RestApi.Interfaces;
using RestApi.Models.Company;
using RestApi.Models.Enum;
using System.Text.Json;

namespace Outpace.Helpers
{
    public static class UserHelper
    {
        public static async Task<Guid> CreateUser(string token, string email, string firstName, string lastName, List<AccessType> listAccessType, UserCreationType userCreationType, List<Guid> companyIds, ReasonPhraseType ReasonPhrase)
        {
            var model = new ApplicationUserCreateRequest()
            {
                AddressLine1 = Constants.AddressLine1,
                AddressLine2 = Constants.AddressLine2,
                City = Constants.City,
                Email = email,
                FirstName = firstName,
                LastName = lastName,
                ListAccessType = listAccessType,
                Postcode = Constants.Postcode,
                UserCreationType = userCreationType,
                CompanyIds = companyIds
                
            };

            //Create company fields 
            var response = await DI.Container.GetService<IRestClient>().Post(model, "AppUser/Create", token);
            if (ReasonPhrase == ReasonPhraseType.Created)
            {
                response.ReasonPhrase.Should().Be(ReasonPhrase.Name);
                string apiResponse = await response.Content.ReadAsStringAsync();
                var responseModel = JsonSerializer.Deserialize<CompanyDto>(apiResponse, new JsonSerializerOptions() { PropertyNameCaseInsensitive = true });
                return responseModel.Id;
            }
            else
            {
                response.ReasonPhrase.Should().Be(ReasonPhrase.Name);
                return Guid.Empty;
            }
        }
    }
}
