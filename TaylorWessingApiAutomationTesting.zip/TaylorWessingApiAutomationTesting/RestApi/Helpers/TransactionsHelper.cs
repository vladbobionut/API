﻿using FluentAssertions;
using Microsoft.Extensions.DependencyInjection;
using Outpace.Models.Transaction;
using RestApi.FrameworkConfiguration;
using RestApi.Interfaces;
using RestApi.Models.Enum;
using RestApi.Models.Transaction;
using System.Text.Json;

namespace Outpace.Helpers
{
    public static class TransactionsHelper
    {
        public static async Task CreateIncorporation(string token, Guid companyId, DateTime closedDate, string transactionName,
               TransactionType transactionType, decimal pricePerShare, List<InvestmentCreateRequest> investments, List<OptionPoolCreateRequest> optionPool)
        {
            var incorporationCreateRequest = new TransactionRequest()
            {
                
                CompanyId = companyId,
                ClosedDate = closedDate,
                Name = transactionName,
                TransactionType = transactionType,
                PricePerShare = pricePerShare,
                Investments = investments,
                OptionPools = optionPool
            };

            var incorporation = await DI.Container.GetService<IRestClient>().Post(incorporationCreateRequest, "CapTable/CreateTransaction", token);
            incorporation.ReasonPhrase.Should().Be("OK");
        }

        public static List<InvestmentCreateRequest> CreateInvestmentForIncorporationWithOneStakeholder(DateTime closeDate, decimal investmentAmmount, 
            InvestmentType investmentType, Guid shareClassId, int shareQuantity, Guid stakeholderId )
        {
            var investments = new List<InvestmentCreateRequest>();
            AddInvestmentForTransaction(closeDate, investmentAmmount, investmentType, shareClassId, shareQuantity, stakeholderId, investments);
            return investments;
        }

        public static List<InvestmentCreateRequest> CreateInvestmentForTransactionsWithOneStakeholder(DateTime closeDate, decimal commitedAmmount,decimal investmentAmmount,
          InvestmentType investmentType, Guid shareClassId, int shareQuantity, Guid stakeholderId)
        {
            var investments = new List<InvestmentCreateRequest>();
            AddInvestmentForTransaction(closeDate, investmentAmmount, investmentType, shareClassId, shareQuantity, stakeholderId, investments);
            return investments;
        }

        public static List<InvestmentCreateRequest> CreateInvestmentForIncorporationWithTwoStakeholder(DateTime closeDate, decimal investmentAmmount,
                            InvestmentType investmentType, Guid shareClassId, int shareQuantity, Guid stakeholderId, DateTime closedDateSecondStakeholder,
                            decimal investmentAmmountSecondStakeholder, InvestmentType investmentTypeSecondStakeholder, Guid shareClassIdSecondStakeholder,
                            int shareQuantitySecondStakeholder, Guid secondStakeholderId)
        {
            var investments = new List<InvestmentCreateRequest>();
            AddInvestmentForTransaction(closeDate, investmentAmmount, investmentType, shareClassId, shareQuantity, stakeholderId, investments);
            AddInvestmentForTransaction(closedDateSecondStakeholder, investmentAmmountSecondStakeholder, investmentTypeSecondStakeholder, shareClassIdSecondStakeholder, shareQuantitySecondStakeholder, secondStakeholderId,investments,0);

            return investments;
        }

        public static async Task CreateShareTransfer(string token, Guid companyId, DateTime date, string eventName, int numberOfShares,
                Guid receiverStakeholderId, Guid shareClassId, Guid transferStakeholderId)
        {
            var modelShareTransfer = new CreateShareTransferRequest()
            {
                CompanyId = companyId,
                Date = date,
                EventName = eventName,
                NumberOfShares = numberOfShares,
                ReceiverStakeholderId = receiverStakeholderId,
                ShareClassId = shareClassId,
                TransfererStakeholderId = transferStakeholderId
            };
            var shareTransfer = await DI.Container.GetService<IRestClient>().Post(modelShareTransfer, "CapTable/CreateShareTransfer", token);
            shareTransfer.ReasonPhrase.Should().Be("OK");
        }

        public static async Task CreateShareSubdivision(string token, Guid companyId, DateTime date, int splitFactor)
        {
            var modelShareSubDivision = new ShareSubDivision()
            {
                CompanyId = companyId,
                Date = date,
                SplitFactor = splitFactor
            };
            var shareSubdivision = await DI.Container.GetService<IRestClient>().Post(modelShareSubDivision, "CapTable/CreateShareSubDivision", token);
            shareSubdivision.ReasonPhrase.Should().Be("OK");
        }

        public static async Task<Guid> CreateOptionPool(string token, Guid companyId, DateTime date, string poolName, decimal poolPercentage, int poolSize,
            bool reservedShares, Guid shareClassId)
        {         
                var createOptionPool = new OptionPoolCreateRequest()
                {
                    CompanyId = companyId,
                    Date = date,
                    PoolName = poolName,
                    PoolPercentage = poolPercentage,
                    PoolSize = poolSize,
                    ReservedShares = reservedShares,
                    ShareClassId = shareClassId
                };

                var optionPool = await DI.Container.GetService<IRestClient>().Post(createOptionPool, "OptionPool/Create", token);
                optionPool.ReasonPhrase.Should().Be("OK");
                string response = await optionPool.Content.ReadAsStringAsync();
                var optionPoolResponse = JsonSerializer.Deserialize<OptionPoolDto>(response, new JsonSerializerOptions() { PropertyNameCaseInsensitive = true });
                return optionPoolResponse.Id;
        }

        public static async Task <Guid> CreateOptionPlan(string token, Guid companyId, int cliff, DateTime date, GrantType grantType, string name, Guid optionPoolId,
                      decimal strikePrice, int vestingDuration, int vestingFrequency, VestingOption vestingOption, DateTime vestingStartDate)
        {
            var createOptionPool = new OptionPlanCreateRequest()
            {
                CompanyId=companyId,
                Cliff = cliff,
                Date = date,
                GrantType = grantType,
                Name = name,
                OptionPoolId = optionPoolId,
                StrikePrice = strikePrice,
                VestingDuration = vestingDuration,
                VestingFrequency = vestingFrequency,
                VestingOption = vestingOption,
                VestingStartDate = vestingStartDate
            };

            var optionPlan = await DI.Container.GetService<IRestClient>().Post(createOptionPool, "OptionPool/CreateOptionPlan", token);
            optionPlan.ReasonPhrase.Should().Be("OK");
            string response = await optionPlan.Content.ReadAsStringAsync();
            var optionPlanResponse = JsonSerializer.Deserialize<OptionPlanModel>(response, new JsonSerializerOptions() { PropertyNameCaseInsensitive = true });
            return optionPlanResponse.Id;
        }

        public static async Task CreateGrantedOption(string token, Guid companyId, int cliff, Guid employeeId, Guid optionPlanId, DateTime expiryDate,
            DateTime grantDate, int numberOfGrants, int vestingDuration, int vestingFrequency)
        {
            var createGrantoptions = new GrantCreateRequest()
            {
                CompanyId = companyId,
                Cliff = cliff,
                EmployeeId = employeeId.ToString(),
                OptionPlanId = optionPlanId,
                ExpiryDate = expiryDate,
                GrantDate = grantDate,
                NumberOfGrants = numberOfGrants,
                VestingDuration = vestingDuration,
                VestingFrequency = vestingFrequency
            };

            var grantedOptions = await DI.Container.GetService<IRestClient>().Post(createGrantoptions, "OptionPool/CreateGrant", token);
            grantedOptions.ReasonPhrase.Should().Be("OK");
        }

        public static async Task CreateConvertible(string token, Guid companyId, int annualInterestPercentage, int capTable, bool completed,
           int discount, DateTime issuedDate, DateTime maturityDate, string name, bool payBackAtConversion,
           List<ConvertibleInvestment> convertibleInvestments, List<ConvertibleClauseType> convertibleClauses, List<ConversionBaseType> convertibleBasis)
        {
            var convertibleCreateRequest = new CreateConvertibleLoanRequest()
            {

                CompanyId = companyId,
                AnnualInterestPercentage = annualInterestPercentage,
                Cap = capTable,
                Completed = completed,
                Discount = discount,
                IssueDate = issuedDate,
                MaturityDate = maturityDate,
                Name = name,
                PayBackAtConversion = payBackAtConversion,
                ConvertibleInvestments = convertibleInvestments,
                ConvertibleClauses = convertibleClauses,
                ConversionBasis = convertibleBasis
            };

            var incorporation = await DI.Container.GetService<IRestClient>().Post(convertibleCreateRequest, "CapTable/CreateConvertibleLoan", token);
            incorporation.ReasonPhrase.Should().Be("OK");
        }

        public static List<ConvertibleInvestment> CreateInvestmentForConvertibleWithOneStakeholder(Guid stakeholderId, int ammountCommited)
        {
            var investments = new List<ConvertibleInvestment>();
            investments.Add(new ConvertibleInvestment()
            {
                UserId = stakeholderId,
                AmountCommitted = ammountCommited,
            });
            return investments;
        }

        public static List<ConvertibleClauseType> CreateConvertibleClauses()
        {
            var convertibleClauses = new List<ConvertibleClauseType>();
            convertibleClauses.Add(ConvertibleClauseType.MostFavouredNation);
            return convertibleClauses;
        }

        public static List<ConversionBaseType> CreateConversionBasis()
        {
            var convertibleBasis = new List<ConversionBaseType>();
            convertibleBasis.Add(ConversionBaseType.IssuedShareCapital);
            convertibleBasis.Add(ConversionBaseType.NewInvestorShares);
            convertibleBasis.Add(ConversionBaseType.ConversionShares);
            convertibleBasis.Add(ConversionBaseType.ESOPIncrease);
            return convertibleBasis;
        }

        public static async Task CreatePriceRound(string token, Guid companyId, DateTime closedDate, string transactionName,
               TransactionType transactionType, decimal preMoneyValuation,long issuedShareCapital, List<InvestmentCreateRequest> investments, List<OptionPoolCreateRequest> optionPool)
        {
            var incorporationCreateRequest = new TransactionRequest()
            {

                CompanyId = companyId,
                ClosedDate = closedDate,
                Name = transactionName,
                TransactionType = transactionType,
                IssuedShareCapital =issuedShareCapital,
                PreMoneyValuation =preMoneyValuation,
                Investments = investments,
                OptionPools = optionPool
            };

            var priceRound = await DI.Container.GetService<IRestClient>().Post(incorporationCreateRequest, "CapTable/CreateTransaction", token);
            priceRound.ReasonPhrase.Should().Be("OK");
        }

        public static List<InvestmentCreateRequest> CreateInvestmentForPriceRoundWithOneStakeholder(DateTime closeDate,decimal commitedAmount, decimal investmentAmmount,
            InvestmentType investmentType,bool leadInvestor,decimal pricePerShare, Guid shareClassId, int shareQuantity, Guid stakeholderId)
        {
            var investments = new List<InvestmentCreateRequest>();
            AddInvestmentForTransaction(closeDate, investmentAmmount, investmentType, shareClassId, shareQuantity, stakeholderId, investments, pricePerShare, commitedAmount, leadInvestor);
            return investments;
        }

        public static List<InvestmentCreateRequest> CreateInvestmentForPriceRoundWithLeadInvestor(DateTime closeDate, decimal commitedAmount, 
            decimal investmentAmmount,InvestmentType investmentType, bool leadInvestor, decimal pricePerShare, Guid shareClassId,
            int shareQuantity, Guid stakeholderId, DateTime secondCloseDate, decimal secondCommitedAmount, decimal secondInvestmentAmmount,
            InvestmentType secondInvestmentType, bool secondLeadInvestor, decimal secondPricePerShare, Guid secondShareClassId,
            int secondShareQuantity, Guid secondStakeholderId)
        {
            var investments = new List<InvestmentCreateRequest>();
            AddInvestmentForTransaction(closeDate, investmentAmmount, investmentType,shareClassId, shareQuantity, stakeholderId, investments,pricePerShare, commitedAmount, leadInvestor);
            AddInvestmentForTransaction(secondCloseDate, secondInvestmentAmmount, secondInvestmentType, secondShareClassId, secondShareQuantity, secondStakeholderId, investments, pricePerShare, commitedAmount, secondLeadInvestor);
            return investments;
        }

        public static List<OptionPoolCreateRequest> CreateOptionPoolForPriceRound(Guid companyId,string poolName,Guid shareClassId,decimal poolPercentage, int poolSize, bool reservedShares)
        {
            var optionPool = new List<OptionPoolCreateRequest>();
            optionPool.Add(new OptionPoolCreateRequest()
            {
              CompanyId = companyId,
              PoolName =poolName,
              ShareClassId= shareClassId,
              PoolPercentage = poolPercentage,
              PoolSize = poolSize,
              ReservedShares =reservedShares
            });
            return optionPool;
        }

        public static List<InvestmentCreateRequest> CreateIncorporationWithFourStakeholder(DateTime closeDate, decimal investmentAmmount,
                            InvestmentType investmentType, Guid shareClassId, int shareQuantity, Guid stakeholderId, DateTime closedDateSecondStakeholder,
                            decimal investmentAmmountSecondStakeholder, InvestmentType investmentTypeSecondStakeholder, Guid shareClassIdSecondStakeholder,
                            int shareQuantitySecondStakeholder, Guid secondStakeholderId, DateTime closedDateThirdStakeholder, decimal investmentAmmountThirdStakeholder,
                            InvestmentType investmentTypeThirdStakeholder, Guid shareClassIdThirdStakeholder, int shareQuantityThirdStakeholder, Guid thirdStakeholderId,
                            DateTime closedDateFourthStakeholder,decimal investmentAmmountFourthStakeholder, InvestmentType investmentTypeFourthStakeholder,
                            Guid shareClassIdFourthStakeholder,int shareQuantityFourthStakeholder, Guid fourthStakeholderId)
        {
            var investments = new List<InvestmentCreateRequest>();
            AddInvestmentForTransaction(closeDate, investmentAmmount, investmentType, shareClassId, shareQuantity, stakeholderId, investments);
            AddInvestmentForTransaction(closedDateSecondStakeholder, investmentAmmountSecondStakeholder, investmentTypeSecondStakeholder, shareClassIdSecondStakeholder, shareQuantitySecondStakeholder, secondStakeholderId, investments);
            AddInvestmentForTransaction(closedDateThirdStakeholder, investmentAmmountThirdStakeholder, investmentTypeThirdStakeholder, shareClassIdThirdStakeholder, shareQuantityThirdStakeholder, thirdStakeholderId, investments);
            AddInvestmentForTransaction(closedDateFourthStakeholder, investmentAmmountFourthStakeholder, investmentTypeFourthStakeholder, shareClassIdFourthStakeholder, shareQuantityFourthStakeholder, fourthStakeholderId, investments);

            return investments;
        }

        public static async Task CreatePriceRoundWithInvestmnetConvertibleAndOptionPool(string token, Guid companyId, DateTime closedDate, string transactionName,
               TransactionType transactionType, decimal preMoneyValuation, long issuedShareCapital, List<InvestmentCreateRequest> investments, List<OptionPoolCreateRequest> optionPool, List<ConvertibleRequest> convertibles)
        {
            {
                var priceRoundCreateRequest = new TransactionRequest()
                {

                    CompanyId = companyId,
                    ClosedDate = closedDate,
                    Name = transactionName,
                    TransactionType = transactionType,
                    IssuedShareCapital = issuedShareCapital,
                    PreMoneyValuation = preMoneyValuation,
                    Investments = investments,
                    OptionPools = optionPool,
                    Convertibles = convertibles
                };

                var priceRound = await DI.Container.GetService<IRestClient>().Post(priceRoundCreateRequest, "CapTable/CreateTransaction", token);
                priceRound.ReasonPhrase.Should().Be("OK");
            }
        }

        public static List<ConvertibleRequest> CreateConvertiblesForPriceRound(Guid Id,decimal valuationCap, decimal Interest,List<ConversionBaseType>conversionBases,List<ConvertibleClauseType>convertibleClauses,
            List<ConvertibleInvestmentConvertRequest>convertibleInvestments)
        {
            var convertibles = new List<ConvertibleRequest>();
            convertibles.Add(new ConvertibleRequest()
            {
                Id = Id,
                ValuationCap = valuationCap,
                Interest = Interest,
                ConvertibleInvestments = convertibleInvestments,
                ConvertibleClauses = convertibleClauses,
                ConversionBasis = conversionBases

            });
            return convertibles;
        }

        public static List<ConvertibleInvestmentConvertRequest> ConvertibleInvestments( Guid id,int shareQuantity, decimal investmentAmount, Guid shareClassId, decimal ammountOfResultingEquity, decimal PricePerShare, bool UseCPPS)
        {
            var convertibleInvestments = new List<ConvertibleInvestmentConvertRequest>();
            AddInvestmentForConvertible(id, shareQuantity, investmentAmount, shareClassId, ammountOfResultingEquity, PricePerShare, UseCPPS, convertibleInvestments);
            return convertibleInvestments;
        }

        private static void AddInvestmentForTransaction(DateTime closeDate, decimal investmentAmmount, InvestmentType investmentType, Guid shareClassId, int shareQuantity, Guid stakeholderId, List<InvestmentCreateRequest> investments, decimal pricePerShare = 0, decimal commitedAmount = 0, bool leadInvestor = false)
        {
            investments.Add(new InvestmentCreateRequest()
            {
                ClosedDate = closeDate,
                CommitedAmount = commitedAmount,
                InvestmentAmount = investmentAmmount,
                InvestmentType = investmentType,
                ShareClassId = shareClassId,
                ShareQuantity = shareQuantity,
                UserId = stakeholderId,
                LeadInvestor = leadInvestor, 
                PricePerShare = pricePerShare
            }); 
        }

        private static void AddInvestmentForConvertible(Guid id, int shareQuantity, decimal investmentAmount, Guid shareClassId, decimal ammountOfResultingEquity, decimal PricePerShare, bool UseCPPS, List<ConvertibleInvestmentConvertRequest> convertibleInvestments)
        {
            convertibleInvestments.Add(new ConvertibleInvestmentConvertRequest()
            {
                Id = id,
                ShareQuantity = shareQuantity,
                InvestmentAmount = investmentAmount,
                ShareClassId = shareClassId,
                AmountOfResultingEquity = ammountOfResultingEquity,
                PricePerShare = PricePerShare,
                UseCPPS = UseCPPS
            });
        }
    }
}