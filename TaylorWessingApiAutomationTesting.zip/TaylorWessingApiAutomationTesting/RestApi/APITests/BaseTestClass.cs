﻿using FluentAssertions;
using Microsoft.Extensions.DependencyInjection;
using Outpace.Models.Enum;
using RestApi.FrameworkConfiguration;
using RestApi.Interfaces;
using System.Text.Json;

namespace Outpace.APITests
{
    public class BaseTestClass
    {
        public static string token;

        public static async Task GetTokenByRole(Role role)
        {
            token = await DI.Container.GetService<ITokenProvider>().GetAccessTokenWithRole(role.Name);
        }

        public static async Task GetTokenWithUserNameAndPassword(string username, string password)
        {
            token = await DI.Container.GetService<ITokenProvider>().GetAccessTokenWithUserNameAndPassword(username, password);
        }

        public static User GetUserInfo(Role role)
        {
            OAuthEndpoint oAuthEndpointConfig = DI.Container.GetService<OAuthEndpoint>();
            return oAuthEndpointConfig.Users.Where(user => user.Role == role.Name).First();
        }

        public static async Task<T> GetAsync<T>(string URL)
        {
            var getResponse = await DI.Container.GetService<IRestClient>().Get(URL, token);
            getResponse.ReasonPhrase.Should().Be("OK");
            string getResponseContent = await getResponse.Content.ReadAsStringAsync();
            return JsonSerializer.Deserialize<T>(getResponseContent, new JsonSerializerOptions() { PropertyNameCaseInsensitive = true });
        }

        public static async Task PostAsync<T>(string URL, T obj,ReasonPhraseType ReasonPhrase)
        {
            var response = await DI.Container.GetService<IRestClient>().Post(obj, URL, token);
            if (ReasonPhrase ==ReasonPhraseType.OK)
            {
                response.ReasonPhrase.Should().Be(ReasonPhrase.Name);
            }
            else
            {

            }
        }

        public static async Task PutAsync<T>(string URL, T obj)
        {
            var responseEditBoard = await DI.Container.GetService<IRestClient>().Put(obj, URL, token);
            responseEditBoard.ReasonPhrase.Should().Be("OK");
        }
    }
}
