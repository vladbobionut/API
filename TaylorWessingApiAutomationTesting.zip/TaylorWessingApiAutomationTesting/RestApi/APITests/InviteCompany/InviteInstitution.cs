﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Outpace.Helpers;
using Outpace.Models.Enum;
using RestApi.Helpers;
using RestApi.Models.Company;

namespace Outpace.APITests.InviteCompany
{
    [TestClass]
    public class InviteInstitution : BaseTestClass
    {
        [TestMethod]
        [TestCategory("PlatformAdmin")]
        public async Task Test1_InviteInstituion_WhenLoginAsPlatformAdmin()
        {
            await GetTokenByRole(Role.PlatformAdmin);

            await InviteCompanyHelper.InviteCompany(token, FakeEmailAddress.GetFakeEmailAddress(),CompanyType.Institution,"AutomationTesting",false, ReasonPhraseType.OK);
        }

        [TestMethod]
        [TestCategory("Lawyer")]
        public async Task Test2_ShouldNotInviteInstituion_WhenLoginAsLawyer()
        {
           await GetTokenByRole(Role.Lawyer);

           await InviteCompanyHelper.InviteCompany(token, FakeEmailAddress.GetFakeEmailAddress(), CompanyType.Institution, "AutomationTesting", false, ReasonPhraseType.Forbidden);
        }

        [TestMethod]
        [TestCategory("InstitutionAdmin")]
        public async Task Test3_InviteInstituion_WhenLoginAsInstitutionAdmin()
        {
           await GetTokenByRole(Role.InstitutionAdmin);

           await InviteCompanyHelper.InviteCompany(token, FakeEmailAddress.GetFakeEmailAddress(), CompanyType.Institution, "AutomationTesting", false, ReasonPhraseType.OK);
        }

        [TestMethod]
        [TestCategory("Founder")]
        public async Task Test4_InviteInstituion_WhenLoginAsFounder()
        {
           await GetTokenByRole(Role.Founder);

           await InviteCompanyHelper.InviteCompany(token, FakeEmailAddress.GetFakeEmailAddress(), CompanyType.Institution, "AutomationTesting", false, ReasonPhraseType.Forbidden);
        }

        [TestMethod]
        [TestCategory("Investor")]
        public async Task Test4_InviteInstituion_WhenLoginAsInvestor()
        {
           await  GetTokenByRole(Role.Investor);

           await InviteCompanyHelper.InviteCompany(token, FakeEmailAddress.GetFakeEmailAddress(), CompanyType.Institution, "AutomationTesting", false, ReasonPhraseType.OK);
        }
    }
}