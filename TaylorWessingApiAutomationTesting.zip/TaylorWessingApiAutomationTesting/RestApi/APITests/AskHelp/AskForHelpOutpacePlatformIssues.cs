﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Outpace.Helpers;
using Outpace.Models.Enum;
using RestApi.Helpers;
using RestApi.Models.Company;
using RestApi.Models.Enum;

namespace Outpace.APITests.AskHelp
{
    [TestClass]
    public class AskForHelpOutpacePlatformIssues : BaseTestClass
    {
        [TestMethod]
        [TestCategory("PlatformAdmin")]
        public async Task Test1_AskForHelpOutpacePlatformIssues_WhenLoginAsPlatformAdmin()
        {
            await GetTokenByRole(Role.PlatformAdmin);

            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            await AskForHelpHelper.AskForHelp(token, companyId, "Outpace platform issues", Constants.Subject, null);
        }

        [TestMethod]
        [TestCategory("Lawyer")]
        public async Task Test2_AskForHelpOutpacePlatformIssues_WhenLoginAsLawyer()
        {
            await GetTokenByRole(Role.Lawyer);

            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            await AskForHelpHelper.AskForHelp(token, companyId, "Outpace platform issues", Constants.Subject, null);
        }

        [TestMethod]
        [TestCategory("InstitutionAdmin")]
        public async Task Test3_AskForHelpOutpacePlatformIssues_WhenLoginAsInstitutionAdmin()
        {
            await GetTokenByRole(Role.InstitutionAdmin);

            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            await AskForHelpHelper.AskForHelp(token, companyId, "Outpace platform issues", Constants.Subject, null);
        }

        [TestMethod]
        [TestCategory("Founder")]
        public async Task Test4_AskForHelpOutpacePlatformIssues_WhenLoginAsFounder()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);
            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                            Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.FounderEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);
            await GetTokenByRole(Role.Founder);

            await AskForHelpHelper.AskForHelp(token, companyId, "Outpace platform issues", Constants.Subject, null);
        }

        [TestMethod]
        [TestCategory("Investor")]
        public async Task Test5_AskForHelpOutpacePlatformIssues_WhenLoginAsInvestor()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);
            var personInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                              UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonInvestorLastName, Constants.PhoneNumber, Constants.AddressLine1,
                              Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.InvestorEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            await GetTokenByRole(Role.Investor);

            await AskForHelpHelper.AskForHelp(token, companyId, "Outpace platform issues", Constants.Subject, null);
        }
    }
}