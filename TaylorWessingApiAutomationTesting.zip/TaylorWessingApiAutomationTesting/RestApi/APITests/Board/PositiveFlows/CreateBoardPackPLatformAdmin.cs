﻿using FluentAssertions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Outpace.APITests;
using Outpace.Assertions;
using Outpace.Models.Enum;
using RestApi.FrameworkConfiguration;
using RestApi.Helpers;
using RestApi.Interfaces;
using RestApi.Models.Board;
using RestApi.Models.Company;
using RestApi.Models.Enum;

namespace RestApi.APITests.Board.PositiveFlows
{
    [TestClass]
    public class CreateBoardPackPLatformAdmin : BaseTestClass
    {
        private static Guid companyId;
        private static Guid boardId;
        private static Guid firstAttendeesId;
        private static Guid secondAttendeesId;
        private static Guid thirdAttendeesId;
        private static Guid firsDiscusionPointId;
        private static Guid secondDiscussionPointId;

        [TestMethod]
        public async Task Test1_CreateABoardPack_When_LoginAsPlatformAdmin()
        {
            //create startup
            await GetTokenByRole(Role.PlatformAdmin);

            companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //Arange board pack
            var boardModel = new CreateBoardRequest()
            {
                CompanyId = companyId,
                EventDate = DateTime.UtcNow.AddDays(+2),
                Venue = Constants.Venue,
                DiscussionPoints = new List<CreateDiscussionPointRequest>()
                {
                    new CreateDiscussionPointRequest
                    {
                        Link = Constants.DiscussionPointFirstLink,
                        Title = Constants.FirstDiscussionPointTitle
                    },
                    new CreateDiscussionPointRequest
                    {
                        Link = Constants.DiscussionPointSecondLink,
                        Title = Constants.SecondDiscussionPointTitle
                    }
                },
                Attendees = new List<string>() { Constants.FirstAttendee, Constants.SecondAttendee, Constants.ThirdAttendee },
            };

            //Create board
            await PostAsync("Board/CreateBoard", boardModel, ReasonPhraseType.OK);

            //Assert board
            var responseBoardModel = await GetAsync<IEnumerable<BoardModel>>($"Board/GetAll/{companyId}");

            BoardPackAssertions.AssertBoard(boardModel, responseBoardModel, firstAttendeesId, secondAttendeesId, thirdAttendeesId,
                firsDiscusionPointId, secondDiscussionPointId);
            boardId = responseBoardModel.FirstOrDefault().Id;
        }

        [TestMethod]
        public async Task Test2_EditBoardPack_When_UsingValidaData()
        {
            //edit discussion point model
            await GetTokenByRole(Role.PlatformAdmin);
            var editDiscussionPointModel = new List<UpdateDiscussionPointRequest>()
            {
                new UpdateDiscussionPointRequest
                {
                BoardId = boardId,
                Link= "",
                Title="update discussion point model"
                }
            };
            //edit board pack model
            var editBoard = new UpdateBoardRequest()
            {
                CompanyId = companyId,
                Venue = "venue for edit",
                EventDate = DateTime.UtcNow.AddDays(+10),
                Attendees = new List<string>()
                {
                    Constants.EditFirstAttendee,Constants.EditSecondAttendee,Constants.EditThirdAttendee
                },
                Final = false
            };
            // edit discussion
            await PostAsync($"Board/UpdateDiscussionPoint/{boardId}", editDiscussionPointModel, ReasonPhraseType.OK);

            //edit board pack
            await PutAsync($"Board/UpdateBoard?id={boardId}", editBoard);

            //get board and assert updates
            var responseBoardEdit = await GetAsync<IEnumerable<BoardModel>>($"Board/GetAll/{companyId}");

            firstAttendeesId = responseBoardEdit.FirstOrDefault().Attendees.FirstOrDefault(attendeeId => attendeeId.Name == Constants.EditFirstAttendee).Id;
            secondAttendeesId = responseBoardEdit.FirstOrDefault().Attendees.FirstOrDefault(attendeeId => attendeeId.Name == Constants.EditSecondAttendee).Id;
            thirdAttendeesId = responseBoardEdit.FirstOrDefault().Attendees.FirstOrDefault(attendeeId => attendeeId.Name == Constants.EditThirdAttendee).Id;

            BoardPackAssertions.AssertUpdateBoard(editDiscussionPointModel, editBoard, responseBoardEdit);
        }

        [TestMethod]
        public async Task Test3_MarkAsFinalBoardPack_When_UsingValidaData()
        {
            //Mark board as final
            await GetTokenByRole(Role.PlatformAdmin);
            var responseMarkAsFinal = await DI.Container.GetService<IRestClient>().Put(new { }, $"Board/MarkAsFinal/{boardId}", token);
            responseMarkAsFinal.ReasonPhrase.Should().Be("OK");

            // get board - mark as final and assert
            var getResponse = await GetAsync<IEnumerable<BoardModel>>($"Board/GetAll/{companyId}");
            BoardPackAssertions.GetMarkedBoardAsFinalAndAssert(getResponse);
        }

        [TestMethod]
        public async Task Test4_UpdateTheModelDetailForBoardPack_When_UsingValidaData()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            var updateModelBoard = new UpdateDetailedBoardRequest()
            {
                Attendees = new List<UpdateDetailedBoardAttendeeRequest>()
                {
                    new UpdateDetailedBoardAttendeeRequest
                    {
                        Absent = false,
                        BoardId = boardId,
                        Chairman = false,
                        Id = firstAttendeesId,
                        Name = Constants.EditFirstAttendee
                    },
                    new UpdateDetailedBoardAttendeeRequest
                    {
                        Absent = false,
                        BoardId = boardId,
                        Chairman = true,
                        Id = secondAttendeesId,
                        Name = Constants.EditSecondAttendee
                    },
                    new UpdateDetailedBoardAttendeeRequest
                    {
                        Absent = true,
                        BoardId = boardId,
                        Chairman = false,
                        Id = thirdAttendeesId,
                        Name = Constants.EditThirdAttendee
                    }
                },
                DiscussionPoints = new List<UpdateDetailedBoardDiscussionPointRequest>()
                {
                    new UpdateDetailedBoardDiscussionPointRequest
                    {
                        BoardId = boardId,
                        Id = firsDiscusionPointId,
                        Link = Constants.UpdateDiscussionPointLink,
                        Notes = Constants.UpdateDiscussionPointNotes,
                        Title = Constants.FirstDiscussionPointTitle,
                        KeyActions = new List<KeyActionModel>()
                        {
                            new KeyActionModel
                            {
                                Assignee = "NameAssigne",
                                Deadline = DateTime.Now,
                                Name = "key action",
                                Id =null
                            }
                        }

                    },
                    new UpdateDetailedBoardDiscussionPointRequest
                    {
                        BoardId = boardId,
                        Id = secondDiscussionPointId,
                        Link = "www.gsp.ro",
                        Notes = "this is another note",
                        Title = "another simple test",
                        KeyActions = new List<KeyActionModel>()
                        {
                            new KeyActionModel
                            {
                                Assignee = "TestAssigne",
                                Deadline = DateTime.Now.AddDays(+5),
                                Name = "Ordinary name",
                                Id= null
                            }
                        }

                    },
                    new UpdateDetailedBoardDiscussionPointRequest
                    {
                        BoardId = boardId,
                        Id = null,
                        Link = null,
                        Notes = Constants.UpdateThirdBoardDiscussionNote,
                        Title = Constants.UpdateThirdBoardDiscussionTitle,
                        KeyActions = new List<KeyActionModel>()
                        {

                        }
                    }
                }
            };

            //update model details board
            var responseUpdateBoard = await DI.Container.GetService<IRestClient>().Put(updateModelBoard, $"Board/UpdateDetailedBoard/{boardId}", token);
            responseUpdateBoard.ReasonPhrase.Should().Be("OK");

            //assert updated model details board
            var getBoardUpdated = await GetAsync<IEnumerable<UpdateDetailedBoardResponse>>($"Board/GetAll/{companyId}");
            BoardPackAssertions.AssertUpdatedBoardDetails(getBoardUpdated, boardId);
        }


        [TestMethod]
        public async Task Test5_MarkAsFinalTheBoardPack_When_UsingValidaData()
        {
            // mark as final - board
            await GetTokenByRole(Role.PlatformAdmin);
            var responseMarkAsFinalUpdatedBoard = await DI.Container.GetService<IRestClient>().Put(new { }, $"Board/MarkAsFinal/{boardId}", token);
            responseMarkAsFinalUpdatedBoard.ReasonPhrase.Should().Be("OK");

            // get and assert that board is marked as final 
            var getResponse = await GetAsync<IEnumerable<BoardModel>>($"Board/GetAll/{companyId}");
            await BoardPackAssertions.AssertMarkAsFinalBoard(boardId, getResponse);
        }

        [TestMethod]
        public async Task Test6_DownloadBoard_When_UsingValidaData()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            // download board
            var responseMarkAsFinalUpdatedBoard = await DI.Container.GetService<IRestClient>().Get($"Board/DownloadBoard/{boardId}", token);
            responseMarkAsFinalUpdatedBoard.ReasonPhrase.Should().Be("OK");
        }
    }
}