﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Outpace.Helpers;
using Outpace.Models.Enum;
using RestApi.Helpers;
using RestApi.Models.Board;
using RestApi.Models.Company;
using RestApi.Models.Enum;

namespace Outpace.APITests.Board.PositiveFlows
{
    [TestClass]
    public class CreateBoardPackInvestor : BaseTestClass
    {
        [TestMethod]
        public async Task Test1_NotAbleToCreateABoardPack_When_LoginAsAnInvestor()
        {
            //create startup
            await GetTokenByRole(Role.PlatformAdmin);

            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created); 

            var personInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                              UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonInvestorLastName, Constants.PhoneNumber, Constants.AddressLine1,
                              Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.InvestorEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            await GetTokenByRole(Role.Investor);
            //Arange board pack
            var boardModel = new CreateBoardRequest()
            {
                CompanyId = companyId,
                EventDate = DateTime.UtcNow.AddDays(+2),
                Venue = Constants.Venue,
                DiscussionPoints = new List<CreateDiscussionPointRequest>()
                {
                    new CreateDiscussionPointRequest
                    {
                        Link = Constants.DiscussionPointFirstLink,
                        Title = Constants.FirstDiscussionPointTitle
                    },
                    new CreateDiscussionPointRequest
                    {
                        Link = Constants.DiscussionPointSecondLink,
                        Title = Constants.SecondDiscussionPointTitle
                    }
                },
                Attendees = new List<string>() { Constants.FirstAttendee, Constants.SecondAttendee, Constants.ThirdAttendee },
            };

            //Create board
            await PostAsync("Board/CreateBoard", boardModel, ReasonPhraseType.Forbidden);
        }
    }
}