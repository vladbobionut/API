﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Outpace.Models.Enum;
using RestApi.Helpers;
using RestApi.Models.Board;
using RestApi.Models.Company;
using RestApi.Models.Enum;

namespace Outpace.APITests.Board.PositiveFlows
{
    [TestClass]
    public class CreateBoardPackInstituionAdmin : BaseTestClass
    {
        [TestMethod]
        public async Task Test1_NotAbleToCreateABoardPack_When_LoginAsInstitutionAdmin()
        {
            //create startup
            await GetTokenByRole(Role.Lawyer);
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created); 

            //Arange board pack
            var boardModel = new CreateBoardRequest()
            {
                CompanyId = companyId,
                EventDate = DateTime.UtcNow.AddDays(+2),
                Venue = Constants.Venue,
                DiscussionPoints = new List<CreateDiscussionPointRequest>()
                {
                    new CreateDiscussionPointRequest
                    {
                        Link = Constants.DiscussionPointFirstLink,
                        Title = Constants.FirstDiscussionPointTitle
                    },
                    new CreateDiscussionPointRequest
                    {
                        Link = Constants.DiscussionPointSecondLink,
                        Title = Constants.SecondDiscussionPointTitle
                    }
                },
                Attendees = new List<string>() { Constants.FirstAttendee, Constants.SecondAttendee, Constants.ThirdAttendee },
            };

            //Create board
            await PostAsync("Board/CreateBoard", boardModel, ReasonPhraseType.Forbidden);
        }
    }
}