﻿using FluentAssertions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Outpace.Assertions;
using Outpace.Models.Enum;
using RestApi.FrameworkConfiguration;
using RestApi.Helpers;
using RestApi.Interfaces;
using RestApi.Models;
using RestApi.Models.Board;
using RestApi.Models.Company;
using RestApi.Models.Enum;
using System.Net;
using System.Text.Json;

namespace RestApi.APITests.Board.NegativeFlows
{
    [TestClass]
    public class CreateBoardPackNegativeFlows 
    {
        private static string token;

        [ClassInitialize]
        public static async Task ClassInitializeAsync(TestContext context)
        {
            token = await DI.Container.GetService<ITokenProvider>().GetAccessTokenWithRole(Environment.GetEnvironmentVariable("UserRole"));
        }
        [TestMethod]
        [Ignore]
        [TestCategory("UserStory - TW 858")]
        public async Task CreateBoardPack_ShouldCreateABoardPack_When_UsingValidaData()
        {
            //Arange company fields
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //Assert
            var getResponse = await DI.Container.GetService<IRestClient>().Get($"company/get/{companyId}", token);
            string apiGetResponse = await getResponse.Content.ReadAsStringAsync();
            var responseGetModel = JsonSerializer.Deserialize<CompanyDto>(apiGetResponse, new JsonSerializerOptions() { PropertyNameCaseInsensitive = true });
            CompanyAssertions.AssertCompany(responseGetModel, CompanyType.Startup, Constants.CompanyName, CompanyStructure.LTD, Jurisdiction.EnglandAndWales,
                Constants.AddressLine1, Constants.AddressLine2, Constants.City, Constants.CompaniesHouseNumber);
            responseGetModel.Currency.Should().Be(Constants.Currency);
            responseGetModel.Postcode.Should().Be(Constants.Postcode);

            //Arange board pack
            var boardModel = new CreateBoardRequest()
            {
                CompanyId = companyId,
                EventDate = DateTime.Now.AddDays(-100),
                Venue = " ",
                DiscussionPoints = new List<CreateDiscussionPointRequest>() { new CreateDiscussionPointRequest { Link = " ", Title = " " }, new CreateDiscussionPointRequest { Link = " ", Title = " " } },
                Attendees = new List<string>() { " ", " ", " " },
            };

            //Create board
            var responseBoard = await DI.Container.GetService<IRestClient>().Post(boardModel, "Board/CreateBoard", token);

            //Assert board - negative flow
            responseBoard.StatusCode.Should().Be(HttpStatusCode.BadRequest);
            string validationErrorMessage = await responseBoard.Content.ReadAsStringAsync();
            ErrorDetails errorDetails = JsonSerializer.Deserialize<ErrorDetails>(validationErrorMessage, new JsonSerializerOptions() { PropertyNameCaseInsensitive = true });
            errorDetails.Code.Should().Equals(400);
        }
    }
}