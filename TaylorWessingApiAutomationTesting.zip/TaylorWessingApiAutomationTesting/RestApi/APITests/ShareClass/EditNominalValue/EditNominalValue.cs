﻿using FluentAssertions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Outpace.Helpers;
using Outpace.Models.Enum;
using RestApi.FrameworkConfiguration;
using RestApi.Helpers;
using RestApi.Interfaces;
using RestApi.Models.Company;
using RestApi.Models.Enum;

namespace Outpace.APITests.Stakeholders.EditNominalValue
{
    [TestClass]
    public class EditNominalValue : BaseTestClass
    {
        [TestMethod]
        [TestCategory("PlatformAdmin")]
        public async Task Test1_UpdateNominalValue_WhenLoginAsPlatformAdmin()
        {
            await GetTokenByRole(Role.PlatformAdmin);

            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var response = await DI.Container.GetService<IRestClient>().Put(string.Empty, $"CapTable/UpdateNominalValue/{companyId}/{100}", token);
            response.ReasonPhrase.Should().Be("OK");
        }

        [TestMethod]
        [TestCategory("Lawyer")]
        public async Task Test2_UpdateNominalValue_WhenLoginAsLawyer()
        {
            await GetTokenByRole(Role.Lawyer);

            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var response = await DI.Container.GetService<IRestClient>().Put(string.Empty, $"CapTable/UpdateNominalValue/{companyId}/{100}", token);
            response.ReasonPhrase.Should().Be("OK");
        }

        [TestMethod]
        [TestCategory("InstitutionAdmin")]
        public async Task Test3_UpdateNominalValue_WhenLoginAsInstitutionAdmin()
        {
            await GetTokenByRole(Role.InstitutionAdmin);

            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var response = await DI.Container.GetService<IRestClient>().Put(string.Empty, $"CapTable/UpdateNominalValue/{companyId}/{100}", token);
            response.ReasonPhrase.Should().Be("OK");
        }

        [TestMethod]
        [TestCategory("Founder")]
        public async Task Test4_UpdateNominalValue_WhenLoginAsFounder()
        {
            await GetTokenByRole(Role.PlatformAdmin);

            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);
            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.FounderEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            await GetTokenByRole(Role.Founder);

            var response = await DI.Container.GetService<IRestClient>().Put(string.Empty, $"CapTable/UpdateNominalValue/{companyId}/{100}", token);
            response.ReasonPhrase.Should().Be("OK");
        }

        [TestMethod]
        [TestCategory("Investor")]
        public async Task Test5_UpdateNominalValue_WhenLoginAsInvestor()
        {
            await GetTokenByRole(Role.PlatformAdmin);

            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);
            var personInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonInvestorLastName, Constants.PhoneNumber, Constants.AddressLine1,
                            Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.InvestorEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            await GetTokenByRole(Role.Investor);

            var response = await DI.Container.GetService<IRestClient>().Put(string.Empty, $"CapTable/UpdateNominalValue/{companyId}/{100}", token);
            response.ReasonPhrase.Should().Be("Forbidden");
        }
    }
}