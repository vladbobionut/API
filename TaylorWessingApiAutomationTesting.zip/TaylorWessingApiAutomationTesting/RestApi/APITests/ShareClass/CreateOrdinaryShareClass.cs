﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Outpace.Assertions;
using Outpace.Helpers;
using Outpace.Models.Enum;
using RestApi.Helpers;
using RestApi.Models.Company;
using RestApi.Models.Enum;
using RestApi.Models.ShareClass;

namespace Outpace.APITests.ShareClass
{
    [TestClass]
    public class CreateOrdinaryShareClass : BaseTestClass
    {
        [TestMethod]
        [TestCategory("PlatformAdmin")]
        public async Task Test1_CreateOrdinaryShareClass_WhenLoginAsPlatformAdmin()
        {
            await GetTokenByRole(Role.PlatformAdmin);

            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            // Assert share class 
            var shareClass = await GetAsync<IEnumerable<ShareClassDto>>($"CapTable/GetShareclassList/{companyId}");
            ShareClassAssertions.AssertShareClass(shareClass, false, false, 0, false, false, 0, 0, 0, 0, false,
                   false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad);
        }

        [TestMethod]
        [TestCategory("Lawyer")]
        public async Task Test2_CreateOrdinaryShareClass_WhenLoginAsLawyer()
        {
            await GetTokenByRole(Role.Lawyer);

            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            // Assert share class 
            var shareClass = await GetAsync<IEnumerable<ShareClassDto>>($"CapTable/GetShareclassList/{companyId}");
            ShareClassAssertions.AssertShareClass(shareClass, false, false, 0, false, false, 0, 0, 0, 0, false,
                   false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad);
        }

        [TestMethod]
        [TestCategory("InstitutionAdmin")]
        public async Task Test3_CreateOrdinaryShareClass_WhenLoginAsInstitutionAdmin()
        {
            await GetTokenByRole(Role.InstitutionAdmin);

            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            // Assert share class 
            var shareClass = await GetAsync<IEnumerable<ShareClassDto>>($"CapTable/GetShareclassList/{companyId}");
            ShareClassAssertions.AssertShareClass(shareClass, false, false, 0, false, false, 0, 0, 0, 0, false,
                   false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad);
        }

        [TestMethod]
        [TestCategory("Founder")]
        public async Task Test4_CreateOrdinaryShareClass_WhenLoginAsFounder()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);
            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                            Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.FounderEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            await GetTokenByRole(Role.Founder);
            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            // Assert share class 
            var shareClass = await GetAsync<IEnumerable<ShareClassDto>>($"CapTable/GetShareclassList/{companyId}");
            ShareClassAssertions.AssertShareClass(shareClass, false, false, 0, false, false, 0, 0, 0, 0, false,
                   false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad);
        }

        [TestMethod]
        [TestCategory("Investor")]
        public async Task Test5_CreateOrdinaryShareClass_WhenLoginAsInvestor()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);
            var personInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                              UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonInvestorLastName, Constants.PhoneNumber, Constants.AddressLine1,
                              Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.InvestorEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            await GetTokenByRole(Role.Investor);
            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.Forbidden);
        }
    }
}