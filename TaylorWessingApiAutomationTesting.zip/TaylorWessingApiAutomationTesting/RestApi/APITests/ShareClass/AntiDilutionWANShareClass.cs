﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Outpace.Assertions;
using Outpace.Helpers;
using Outpace.Models.Enum;
using RestApi.Helpers;
using RestApi.Models.Company;
using RestApi.Models.Enum;
using RestApi.Models.ShareClass;

namespace Outpace.APITests.ShareClass
{
    [TestClass]
    public class AntiDilutionWANShareClass : BaseTestClass
    {
        [TestMethod]
        [TestCategory("PlatformAdmin")]
        public async Task Test1_CreateAntiDilutionWANShareClass_WhenLoginAsPlatformAdmin()
        {
            await GetTokenByRole(Role.PlatformAdmin);

            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            // create shareclass 
            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, true, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.AntiDilutionWan, 1, AntiDilutionType.WeightedAverageNarrow, ReasonPhraseType.OK);

            // Assert share class
            var shareClass = await GetAsync<IEnumerable<ShareClassDto>>($"CapTable/GetShareclassList/{companyId}");
            ShareClassAssertions.AssertShareClass(shareClass, true, false, 0, false, false, 0, 0, 0, 0, false,
                   false, 0, Constants.AntiDilutionWan, 1, AntiDilutionType.WeightedAverageNarrow);
        }

        [TestMethod]
        [TestCategory("Lawyer")]
        public async Task Test2_CreateAntiDilutionWANShareClass_WhenLoginAsLawyer()
        {
            await GetTokenByRole(Role.Lawyer);

            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            // create shareclass 
            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, true, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.AntiDilutionWan, 1, AntiDilutionType.WeightedAverageNarrow, ReasonPhraseType.OK);

            // Assert share class
            var shareClass = await GetAsync<IEnumerable<ShareClassDto>>($"CapTable/GetShareclassList/{companyId}");
            ShareClassAssertions.AssertShareClass(shareClass, true, false, 0, false, false, 0, 0, 0, 0, false,
                   false, 0, Constants.AntiDilutionWan, 1, AntiDilutionType.WeightedAverageNarrow);
        }

        [TestMethod]
        [TestCategory("InstitutionAdmin")]
        public async Task Test3_CreateAntiDilutionWANShareClass_WhenLoginAsInstitutionAdmin()
        {
            await GetTokenByRole(Role.InstitutionAdmin);

            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            // create shareclass 
            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, true, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.AntiDilutionWan, 1, AntiDilutionType.WeightedAverageNarrow, ReasonPhraseType.OK);

            // Assert share class
            var shareClass = await GetAsync<IEnumerable<ShareClassDto>>($"CapTable/GetShareclassList/{companyId}");
            ShareClassAssertions.AssertShareClass(shareClass, true, false, 0, false, false, 0, 0, 0, 0, false,
                   false, 0, Constants.AntiDilutionWan, 1, AntiDilutionType.WeightedAverageNarrow);
        }

        [TestMethod]
        [TestCategory("Founder")]
        public async Task Test4_CreateAntiDilutionWANShareClass_WhenLoginAsFounder()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);
            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                            Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.FounderEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            await GetTokenByRole(Role.Founder);

            // create shareclass 
            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, true, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.AntiDilutionWan, 1, AntiDilutionType.WeightedAverageNarrow, ReasonPhraseType.OK);

            // Assert share class
            var shareClass = await GetAsync<IEnumerable<ShareClassDto>>($"CapTable/GetShareclassList/{companyId}");
            ShareClassAssertions.AssertShareClass(shareClass, true, false, 0, false, false, 0, 0, 0, 0, false,
                   false, 0, Constants.AntiDilutionWan, 1, AntiDilutionType.WeightedAverageNarrow);
        }

        [TestMethod]
        [TestCategory("Investor")]
        public async Task Test5_CreateAntiDilutionWANShareClass_WhenLoginAsInvestor()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);
            var personInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                              UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonInvestorLastName, Constants.PhoneNumber, Constants.AddressLine1,
                              Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.InvestorEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            await GetTokenByRole(Role.Investor);
            // create shareclass 
            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, true, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.AntiDilutionWan, 1, AntiDilutionType.WeightedAverageNarrow, ReasonPhraseType.Forbidden);
        }
    }
}