﻿using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using RestApi.Interfaces;
using RestApi.Models;
using System.Text;

namespace RestApi.FrameworkConfiguration
{
    public class RestClient: IRestClient
    {
        public readonly HttpClient client = DI.Container.GetService<IHttpClientFactory>().CreateClient();
        public RestClient(NameOfTheService settings)
        {
            client.BaseAddress = new Uri(settings.BaseUrl);
        }

        public async Task<HttpResponseMessage> Post<TModel>(TModel model, string endpoint, string token, string? subscriptionKey = null)
        {
            Authorize(token, subscriptionKey);
            string requestBody = JsonConvert.SerializeObject(model);
            return await client.PostAsync(endpoint, new StringContent(requestBody, Encoding.UTF8, "application/json"));
        }

        public async Task<HttpResponseMessage> PostFormData<TModel>(TModel requestObject, string endpoint, string token, string? subscriptionKey = null)
        {
            Authorize(token, subscriptionKey);
            var content = CreateMultipartContent(requestObject);
            return await client.PostAsync(endpoint, content);
        }

        private static HttpContent CreateMultipartContent<T>(T requestObject)
        {
            var content = new MultipartFormDataContent();

            var properties = typeof(T).GetProperties();
            foreach (var property in properties)
            {
                var value = property.GetValue(requestObject);
                if (value != null)
                {
                    var stringValue = value.ToString();
                    content.Add(new StringContent(stringValue), property.Name);
                }
            }

            return content;
        }

        public async Task<HttpResponseMessage> Get(string endpoint, string token, string? subscriptionKey = null)
        {
            Authorize(token, subscriptionKey);
            return await client.GetAsync(endpoint);
        }

        public async Task<HttpResponseMessage> Patch<TModel>(TModel model, string endpoint, string token, string? subscriptionKey = null)
        {
            Authorize(token, subscriptionKey);
            string requestBody = JsonConvert.SerializeObject(model);
            return await client.PatchAsync(endpoint, new StringContent(requestBody, Encoding.UTF8, "application/json"));
        }

        public async Task<HttpResponseMessage> Put<TModel>(TModel model, string endpoint, string token, string? subscriptionKey = null)
        {
            Authorize(token, subscriptionKey);
            string requestBody = JsonConvert.SerializeObject(model);
            return await client.PutAsync(endpoint, new StringContent(requestBody, Encoding.UTF8, "application/json"));
        }

        public async Task<HttpResponseMessage> Delete(string endpoint, string token, string? subscriptionKey = null)
        {
            Authorize(token, subscriptionKey);
            return await client.DeleteAsync(endpoint);
        }

        

        private void Authorize(string token, string? subscriptionKey)
        {
            client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", token);
            if (subscriptionKey != null)
                client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", subscriptionKey);
        }
    }
}