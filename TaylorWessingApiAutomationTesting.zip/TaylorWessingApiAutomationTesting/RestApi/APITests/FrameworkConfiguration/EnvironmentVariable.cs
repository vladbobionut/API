﻿namespace RestApi.FrameworkConfiguration
{
    public static class EnvironmentVariable
    {
        public const string ASPNETCORE_VARIABLE_KEY = "ASPNETCORE_ENVIRONMENT";
    }
}