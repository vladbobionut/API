﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using RestApi.Helpers;
using RestApi.Interfaces;
using RestApi.Models;

namespace RestApi.FrameworkConfiguration
{
    public static class DI
    {
        private static ServiceProvider _container;

        public static ServiceProvider Container
        {
            get
            {
                if (_container is null)
                {
                    _container = new ConfigurationLoader().ServiceProvider;
                }
                return _container;
            }
        }

        public static void SetupConfigurations(IServiceCollection services)
        {
            services.AddLogging();
            services.AddHttpClient();
            services.AddSingleton(serviceProvider =>
              {
                  return serviceProvider.GetService<IConfiguration>().GetSection(OAuthEndpoint.SectionName).Get<OAuthEndpoint>();
              });

            services.AddSingleton(serviceProvider =>
            {
                return serviceProvider.GetService<IConfiguration>().GetSection(NameOfTheService.SectionName).Get<NameOfTheService>();
            });
            services.AddSingleton(typeof(ITokenProvider), typeof(TokenProvider));
            services.AddSingleton(typeof(IRestClient), typeof(RestClient));
        }
    }
}