﻿namespace RestApi.FrameworkConfiguration
{
    public class OAuthEndpoint
    {
        public const string SectionName = "OAuthEndpoint";

        public string Url { get; set; }
        public User[] Users { get; set; }

    }

    public class User
    {
        public string UserName { get; set; }

        public string Password { get; set; }

        public string Role { get; set; }
    }
}