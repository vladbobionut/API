﻿using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestPlatform.TestHost;

namespace RestApi.FrameworkConfiguration
{
    public class ConfigurationLoader : WebApplicationFactory<Program>
    {
        private IConfiguration configuration;
        public ServiceProvider ServiceProvider { get; private set; }

        public ConfigurationLoader()
        {
            string environmentName = Environment.GetEnvironmentVariable(EnvironmentVariable.ASPNETCORE_VARIABLE_KEY);
            var builder = new ConfigurationBuilder()
                 .AddJsonFile("appsettings.json", false, true)
                 .AddJsonFile($"appsettings.{environmentName}.json", optional: true, reloadOnChange: true);
            configuration = builder.Build();


            var services = new ServiceCollection();
            services.AddSingleton(configuration);
            DI.SetupConfigurations(services);

            ServiceProvider = services.BuildServiceProvider();
        }
    }
}