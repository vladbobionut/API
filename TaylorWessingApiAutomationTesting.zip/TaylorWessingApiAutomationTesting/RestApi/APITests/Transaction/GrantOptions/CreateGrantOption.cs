﻿using FluentAssertions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Outpace.Assertions;
using Outpace.Helpers;
using Outpace.Models.Enum;
using Outpace.Models.Transaction;
using RestApi.FrameworkConfiguration;
using RestApi.Helpers;
using RestApi.Interfaces;
using RestApi.Models.Company;
using RestApi.Models.Enum;
using RestApi.Models.Transaction;

namespace Outpace.APITests.Transaction.GrantOptions
{
    [TestClass]
    public class CreateGrantOption : BaseTestClass
    {
        [TestMethod]
        [TestCategory("PlatformAdmin")]
        public async Task Test1_CreateGrantedOptionTransaction_ShouldSucceed_WhenLoginAsPlatformAdmin()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            //Arrange
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var employeeId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Employee, false,
                UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.EmployeeLastName, Constants.PhoneNumber,
                Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            var optionPoolId = await TransactionsHelper.CreateOptionPool(token, companyId, DateTime.UtcNow.AddDays(-3), Constants.PoolName,
                Constants.PoolPercentage, Constants.PoolSize, false, shareClassId);

            var optionPlanId = await TransactionsHelper.CreateOptionPlan(token, companyId, Constants.OptionPlanCliff, DateTime.UtcNow.AddDays(-3), GrantType.EMI, Constants.OptionPlanName,
                optionPoolId, Constants.StrikePrice, Constants.VestingDuration, Constants.VestingFrequency, VestingOption.SimpleTime, DateTime.UtcNow);

            //Act
            await TransactionsHelper.CreateGrantedOption(token, companyId, Constants.CliffOpionsGranted, employeeId, optionPlanId, DateTime.UtcNow.AddDays(-3), DateTime.UtcNow.AddDays(+15),
               Constants.NumberOfGrants, Constants.VestingDurationGranted, Constants.vestingFrequencyGranted);

            //Assert
            var getGrantedOption = await GetAsync<IEnumerable<TransactionDto>>($"CapTable/GetAllTransactions/{companyId}");
            TransactionsAssertions.AssertGrantOption(getGrantedOption, employeeId, optionPlanId);
        }

        [TestMethod]
        [TestCategory("Lawyer")]
        public async Task Test2_CreateGrantedOptionTransaction_ShouldSucceed_WhenLoginAsLawyer()
        {
            await GetTokenByRole(Role.Lawyer);
            //Arrange
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var employeeId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Employee, false,
                UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.EmployeeLastName, Constants.PhoneNumber,
                Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            var optionPoolId = await TransactionsHelper.CreateOptionPool(token, companyId, DateTime.UtcNow.AddDays(-3), Constants.PoolName,
                Constants.PoolPercentage, Constants.PoolSize, false, shareClassId);

            var optionPlanId = await TransactionsHelper.CreateOptionPlan(token, companyId, Constants.OptionPlanCliff, DateTime.UtcNow.AddDays(-3), GrantType.EMI, Constants.OptionPlanName,
                optionPoolId, Constants.StrikePrice, Constants.VestingDuration, Constants.VestingFrequency, VestingOption.SimpleTime, DateTime.UtcNow);

            //Act
            await TransactionsHelper.CreateGrantedOption(token, companyId, Constants.CliffOpionsGranted, employeeId, optionPlanId, DateTime.UtcNow.AddDays(-3), DateTime.UtcNow.AddDays(+15),
               Constants.NumberOfGrants, Constants.VestingDurationGranted, Constants.vestingFrequencyGranted);

            //Assert
            var getGrantedOption = await GetAsync<IEnumerable<TransactionDto>>($"CapTable/GetAllTransactions/{companyId}");
            TransactionsAssertions.AssertGrantOption(getGrantedOption, employeeId, optionPlanId);
        }

        [TestMethod]
        [TestCategory("InstitutionAdmin")]
        public async Task Test3_CreateGrantedOptionTransaction_ShouldSucceed_WhenLoginAsInstitutionAdmin()
        {
            await GetTokenByRole(Role.InstitutionAdmin);
            //Arrange
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var employeeId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Employee, false,
                UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.EmployeeLastName, Constants.PhoneNumber,
                Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            var optionPoolId = await TransactionsHelper.CreateOptionPool(token, companyId, DateTime.UtcNow.AddDays(-3), Constants.PoolName,
                Constants.PoolPercentage, Constants.PoolSize, false, shareClassId);

            var optionPlanId = await TransactionsHelper.CreateOptionPlan(token, companyId, Constants.OptionPlanCliff, DateTime.UtcNow.AddDays(-3), GrantType.EMI, Constants.OptionPlanName,
                optionPoolId, Constants.StrikePrice, Constants.VestingDuration, Constants.VestingFrequency, VestingOption.SimpleTime, DateTime.UtcNow);

            //Act
            await TransactionsHelper.CreateGrantedOption(token, companyId, Constants.CliffOpionsGranted, employeeId, optionPlanId, DateTime.UtcNow.AddDays(-3), DateTime.UtcNow.AddDays(+15),
               Constants.NumberOfGrants, Constants.VestingDurationGranted, Constants.vestingFrequencyGranted);

            //Assert
            var getGrantedOption = await GetAsync<IEnumerable<TransactionDto>>($"CapTable/GetAllTransactions/{companyId}");
            TransactionsAssertions.AssertGrantOption(getGrantedOption, employeeId, optionPlanId);
        }

        [TestMethod]
        [TestCategory("Founder")]
        public async Task Test4_CreateGrantedOptionTransaction_ShouldSucceed_WhenLoginAsInAsFounder()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            //Arrange
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var employeeId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Employee, false,
                        UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.EmployeeLastName, Constants.PhoneNumber,
                        Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                           UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                           Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.FounderEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            await GetTokenByRole(Role.Founder);
            var optionPoolId = await TransactionsHelper.CreateOptionPool(token, companyId, DateTime.UtcNow.AddDays(-3), Constants.PoolName,
                Constants.PoolPercentage, Constants.PoolSize, false, shareClassId);

            var optionPlanId = await TransactionsHelper.CreateOptionPlan(token, companyId, Constants.OptionPlanCliff, DateTime.UtcNow.AddDays(-3), GrantType.EMI, Constants.OptionPlanName,
                optionPoolId, Constants.StrikePrice, Constants.VestingDuration, Constants.VestingFrequency, VestingOption.SimpleTime, DateTime.UtcNow);

            //Act
            await TransactionsHelper.CreateGrantedOption(token, companyId, Constants.CliffOpionsGranted, employeeId, optionPlanId, DateTime.UtcNow.AddDays(-3), DateTime.UtcNow.AddDays(+15),
               Constants.NumberOfGrants, Constants.VestingDurationGranted, Constants.vestingFrequencyGranted);

            //Assert
            var getGrantedOption = await GetAsync<IEnumerable<TransactionDto>>($"CapTable/GetAllTransactions/{companyId}");
            TransactionsAssertions.AssertGrantOption(getGrantedOption, employeeId, optionPlanId);
        }

        [TestMethod]
        [TestCategory("Investor")]
        public async Task Test5_CreateGrantedOptionTransaction_ShouldForbidden_WhenLoginAsInAsInvestor()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            //Arrange
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var employeeId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Employee, false,
                        UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.EmployeeLastName, Constants.PhoneNumber,
                        Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);


            var personInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonInvestorLastName, Constants.PhoneNumber, Constants.AddressLine1,
                            Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.InvestorEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            var optionPoolId = await TransactionsHelper.CreateOptionPool(token, companyId, DateTime.UtcNow.AddDays(-3), Constants.PoolName,
                Constants.PoolPercentage, Constants.PoolSize, false, shareClassId);

            var optionPlanId = await TransactionsHelper.CreateOptionPlan(token, companyId, Constants.OptionPlanCliff, DateTime.UtcNow.AddDays(-3), GrantType.EMI, Constants.OptionPlanName,
                optionPoolId, Constants.StrikePrice, Constants.VestingDuration, Constants.VestingFrequency, VestingOption.SimpleTime, DateTime.UtcNow);

            //Act
            await GetTokenByRole(Role.Investor);
            var createGrantoptions = new GrantCreateRequest()
            {
                CompanyId = companyId,
                Cliff = Constants.CliffOpionsGranted,
                EmployeeId = employeeId.ToString(),
                OptionPlanId = optionPlanId,
                ExpiryDate = DateTime.UtcNow.AddDays(-3),
                GrantDate = DateTime.UtcNow.AddDays(+15),
                NumberOfGrants = Constants.NumberOfGrants,
                VestingDuration = Constants.VestingDurationGranted,
                VestingFrequency = Constants.vestingFrequencyGranted
            };

            var grantedOptions = await DI.Container.GetService<IRestClient>().Post(createGrantoptions, "OptionPool/CreateGrant", token);

            //Assert
            grantedOptions.ReasonPhrase.Should().Be("Forbidden");
        }
    }
}