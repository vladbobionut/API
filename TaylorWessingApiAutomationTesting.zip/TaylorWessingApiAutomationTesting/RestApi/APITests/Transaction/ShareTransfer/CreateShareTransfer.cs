﻿using FluentAssertions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Outpace.Assertions;
using Outpace.Helpers;
using Outpace.Models.Enum;
using RestApi.FrameworkConfiguration;
using RestApi.Helpers;
using RestApi.Interfaces;
using RestApi.Models.Company;
using RestApi.Models.Enum;
using RestApi.Models.Transaction;

namespace Outpace.APITests.Transaction.ShareTransfer
{
    [TestClass]
    public class CreateShareTransfer : BaseTestClass
    {
        [TestMethod]
        [TestCategory("PlatformAdmin")]
        public async Task Test1_CreateShareTransferTransaction_ShouldSucceed_WhenLoginAsPlatformAdmin()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            //Arrange
            var email = FakeEmailAddress.GetFakeEmailAddress();

            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                            Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, email, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var personInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonInvestorLastName, Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 21), ReasonPhraseType.Created);

            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            //Act
            await TransactionsHelper.CreateShareTransfer(token, companyId, Constants.DateShareTansfer, Constants.EventName,
                  Constants.NumberOfShares, personFounderId, shareClassId, personInvestorId);

            //Assert
            var getShareTransfer = await GetAsync<IEnumerable<TransactionDto>>($"CapTable/GetAllTransactions/{companyId}");
            TransactionsAssertions.AssertShareTransfer(getShareTransfer, companyId, shareClassId, personFounderId, personInvestorId);
        }

        [TestMethod]
        [TestCategory("Lawyer")]
        public async Task Test2_CreateShareTransferTransaction_ShouldSucceed_WhenLoginAsLawyer()
        {
            await GetTokenByRole(Role.Lawyer);
            //Arrange
            var email = FakeEmailAddress.GetFakeEmailAddress();

            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                            Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, email, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var personInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonInvestorLastName, Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 21), ReasonPhraseType.Created);

            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            //Act
            await TransactionsHelper.CreateShareTransfer(token, companyId, Constants.DateShareTansfer, Constants.EventName,
                  Constants.NumberOfShares, personFounderId, shareClassId, personInvestorId);

            //Assert
            var getShareTransfer = await GetAsync<IEnumerable<TransactionDto>>($"CapTable/GetAllTransactions/{companyId}");
            TransactionsAssertions.AssertShareTransfer(getShareTransfer, companyId, shareClassId, personFounderId, personInvestorId);
        }

        [TestMethod]
        [TestCategory("InstitutionAdmin")]
        public async Task Test3_CreateShareTransferTransaction_ShouldSucceed_WhenLoginAsInstitutionAdmin()
        {
            await GetTokenByRole(Role.InstitutionAdmin);
            //Arrange
            var email = FakeEmailAddress.GetFakeEmailAddress();

            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                            Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, email, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var personInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonInvestorLastName, Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 21), ReasonPhraseType.Created);

            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            //Act
            await TransactionsHelper.CreateShareTransfer(token, companyId, Constants.DateShareTansfer, Constants.EventName,
                  Constants.NumberOfShares, personFounderId, shareClassId, personInvestorId);

            //Assert
            var getShareTransfer = await GetAsync<IEnumerable<TransactionDto>>($"CapTable/GetAllTransactions/{companyId}");
            TransactionsAssertions.AssertShareTransfer(getShareTransfer, companyId, shareClassId, personFounderId, personInvestorId);
        }

        [TestMethod]
        [TestCategory("Founder")]
        public async Task Test4_CreateShareTransferTransaction_ShouldSucceed_WhenLoginAsFounder()
        {
            await GetTokenByRole(Role.InstitutionAdmin);
            //Arrange
            var email = FakeEmailAddress.GetFakeEmailAddress();

            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                            Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.FounderEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var personInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonInvestorLastName, Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 21), ReasonPhraseType.Created);

            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            await GetTokenByRole(Role.Founder);
            //Act
            await TransactionsHelper.CreateShareTransfer(token, companyId, Constants.DateShareTansfer, Constants.EventName,
                  Constants.NumberOfShares, personFounderId, shareClassId, personInvestorId);

            //Assert
            var getShareTransfer = await GetAsync<IEnumerable<TransactionDto>>($"CapTable/GetAllTransactions/{companyId}");
            TransactionsAssertions.AssertShareTransfer(getShareTransfer, companyId, shareClassId, personFounderId, personInvestorId);
        }

        [TestMethod]
        [TestCategory("Investor")]
        public async Task Test5_CreateShareTransferTransaction_ShouldReceiveForbidden_WhenLoginAsInvestor()
        {
            await GetTokenByRole(Role.InstitutionAdmin);
            //Arrange
            var email = FakeEmailAddress.GetFakeEmailAddress();

            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                            Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.FounderEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var personInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonInvestorLastName, Constants.PhoneNumber, Constants.AddressLine1,
                            Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.InvestorEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            await GetTokenByRole(Role.Investor);
            //Act
            var modelShareTransfer = new CreateShareTransferRequest()
            {
                CompanyId = companyId,
                Date = Constants.DateShareTansfer,
                EventName = Constants.EventName,
                NumberOfShares = Constants.NumberOfShares,
                ReceiverStakeholderId = personFounderId,
                ShareClassId = shareClassId,
                TransfererStakeholderId = personFounderId
            };
            var shareTransfer = await DI.Container.GetService<IRestClient>().Post(modelShareTransfer, "CapTable/CreateShareTransfer", token);
            //Assert
            shareTransfer.ReasonPhrase.Should().Be("Forbidden");
        }
    }
}