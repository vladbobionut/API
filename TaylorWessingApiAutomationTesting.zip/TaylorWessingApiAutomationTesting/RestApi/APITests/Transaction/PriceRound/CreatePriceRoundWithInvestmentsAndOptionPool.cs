﻿using FluentAssertions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Outpace.Assertions;
using Outpace.Helpers;
using Outpace.Models.Enum;
using RestApi.FrameworkConfiguration;
using RestApi.Helpers;
using RestApi.Interfaces;
using RestApi.Models.Company;
using RestApi.Models.Enum;
using RestApi.Models.Transaction;

namespace Outpace.APITests.Transaction.PriceRound
{
    [TestClass]
    public class CreatePriceRoundWithInvestmentsAndOptionPool : BaseTestClass
    {
        [TestMethod]
        [TestCategory("PlatformAdmin")]
        public async Task Test1_CreatePriceRoundWithInvestmentAndOptionPool_ShouldSucceed_WhneLoginAsPlatformAdmin()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            //Arrange
            var email = FakeEmailAddress.GetFakeEmailAddress();

            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var personInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonInvestorLastName, Constants.PhoneNumber, Constants.AddressLine1,
                            Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 21), ReasonPhraseType.Created);

            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                            Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, email, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            var investments = TransactionsHelper.CreateInvestmentForIncorporationWithOneStakeholder(DateTime.UtcNow.AddDays(-3), Constants.InvestmentAmount, InvestmentType.StandardShareIssuance,
                 shareClassId, Constants.ShareQuantity, personFounderId);

            await TransactionsHelper.CreateIncorporation(token, companyId, Constants.CloseDate, Constants.IncorporationName, TransactionType.Incorporation,
                Constants.PricePerShare, investments, new List<OptionPoolCreateRequest> { });

            //Act
            var investmentsPriceRound = TransactionsHelper.CreateInvestmentForPriceRoundWithOneStakeholder(DateTime.UtcNow, Constants.CommitedAmount, Constants.InvestmentAmount, InvestmentType.StandardShareIssuance, false,
               Constants.PriceRoundPricePerShare, shareClassId, Constants.ShareQuantity, personInvestorId);

            var optionPool = TransactionsHelper.CreateOptionPoolForPriceRound(companyId, Constants.PoolName, shareClassId, Constants.PoolPercentage, Constants.NewPoolSize, false);

            await TransactionsHelper.CreatePriceRound(token, companyId, DateTime.UtcNow.AddDays(+10), Constants.PriceRoundName, TransactionType.FundingRound,
                Constants.PriceRoundPreMoenyEvaluation, Constants.PriceRoundIssuedShareCapiatal, investmentsPriceRound, optionPool);

            //Assert
            var getTransactions = await GetAsync<IEnumerable<TransactionDto>>($"CapTable/GetAllTransactions/{companyId}");
            TransactionsAssertions.AssertPriceRoundTransactionWithOneInvestmentAndOptionPool(getTransactions, companyId, shareClassId);
        }

        [TestMethod]
        [TestCategory("Lawyer")]
        public async Task Test2_CreatePriceRoundWithInvestmentAndOptionPool_ShouldSucceed_WhneLoginAsLawyer()
        {
            await GetTokenByRole(Role.Lawyer);
            //Arrange
            var email = FakeEmailAddress.GetFakeEmailAddress();

            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var personInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonInvestorLastName, Constants.PhoneNumber, Constants.AddressLine1,
                            Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 21), ReasonPhraseType.Created);

            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                            Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, email, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            var investments = TransactionsHelper.CreateInvestmentForIncorporationWithOneStakeholder(DateTime.UtcNow.AddDays(-3), Constants.InvestmentAmount, InvestmentType.StandardShareIssuance,
                 shareClassId, Constants.ShareQuantity, personFounderId);

            await TransactionsHelper.CreateIncorporation(token, companyId, Constants.CloseDate, Constants.IncorporationName, TransactionType.Incorporation,
                Constants.PricePerShare, investments, new List<OptionPoolCreateRequest> { });

            //Act
            var investmentsPriceRound = TransactionsHelper.CreateInvestmentForPriceRoundWithOneStakeholder(DateTime.UtcNow, Constants.CommitedAmount, Constants.InvestmentAmount, InvestmentType.StandardShareIssuance, false,
               Constants.PriceRoundPricePerShare, shareClassId, Constants.ShareQuantity, personInvestorId);

            var optionPool = TransactionsHelper.CreateOptionPoolForPriceRound(companyId, Constants.PoolName, shareClassId, Constants.PoolPercentage, Constants.NewPoolSize, false);

            await TransactionsHelper.CreatePriceRound(token, companyId, DateTime.UtcNow.AddDays(+10), Constants.PriceRoundName, TransactionType.FundingRound,
                Constants.PriceRoundPreMoenyEvaluation, Constants.PriceRoundIssuedShareCapiatal, investmentsPriceRound, optionPool);

            //Assert
            var getTransactions = await GetAsync<IEnumerable<TransactionDto>>($"CapTable/GetAllTransactions/{companyId}");
            TransactionsAssertions.AssertPriceRoundTransactionWithOneInvestmentAndOptionPool(getTransactions, companyId, shareClassId);
        }

        [TestMethod]
        [TestCategory("InstitutionAdmin")]
        public async Task Test3_CreatePriceRoundWithInvestmentAndOptionPool_ShouldSucceed_WhneLoginAsInstitutionAdmin()
        {
            await GetTokenByRole(Role.Lawyer);
            //Arrange
            var email = FakeEmailAddress.GetFakeEmailAddress();

            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var personInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonInvestorLastName, Constants.PhoneNumber, Constants.AddressLine1,
                            Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 21), ReasonPhraseType.Created);

            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                            Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, email, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            var investments = TransactionsHelper.CreateInvestmentForIncorporationWithOneStakeholder(DateTime.UtcNow.AddDays(-3), Constants.InvestmentAmount, InvestmentType.StandardShareIssuance,
                 shareClassId, Constants.ShareQuantity, personFounderId);

            await TransactionsHelper.CreateIncorporation(token, companyId, Constants.CloseDate, Constants.IncorporationName, TransactionType.Incorporation,
                Constants.PricePerShare, investments, new List<OptionPoolCreateRequest> { });

            //Act
            var investmentsPriceRound = TransactionsHelper.CreateInvestmentForPriceRoundWithOneStakeholder(DateTime.UtcNow, Constants.CommitedAmount, Constants.InvestmentAmount, InvestmentType.StandardShareIssuance, false,
               Constants.PriceRoundPricePerShare, shareClassId, Constants.ShareQuantity, personInvestorId);

            var optionPool = TransactionsHelper.CreateOptionPoolForPriceRound(companyId, Constants.PoolName, shareClassId, Constants.PoolPercentage, Constants.NewPoolSize, false);

            await TransactionsHelper.CreatePriceRound(token, companyId, DateTime.UtcNow.AddDays(+10), Constants.PriceRoundName, TransactionType.FundingRound,
                Constants.PriceRoundPreMoenyEvaluation, Constants.PriceRoundIssuedShareCapiatal, investmentsPriceRound, optionPool);

            //Assert
            var getTransactions = await GetAsync<IEnumerable<TransactionDto>>($"CapTable/GetAllTransactions/{companyId}");
            TransactionsAssertions.AssertPriceRoundTransactionWithOneInvestmentAndOptionPool(getTransactions, companyId, shareClassId);
        }

        [TestMethod]
        [TestCategory("Founder")]
        public async Task Test4_CreatePriceRoundWithInvestmentAndOptionPool_ShouldSucceed_WhneLoginAsFounder()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            //Arrange
            var email = FakeEmailAddress.GetFakeEmailAddress();

            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var personInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonInvestorLastName, Constants.PhoneNumber, Constants.AddressLine1,
                            Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 21), ReasonPhraseType.Created);

            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                              UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                              Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.FounderEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            await GetTokenByRole(Role.Founder);
            var investments = TransactionsHelper.CreateInvestmentForIncorporationWithOneStakeholder(DateTime.UtcNow.AddDays(-3), Constants.InvestmentAmount, InvestmentType.StandardShareIssuance,
                 shareClassId, Constants.ShareQuantity, personFounderId);

            await TransactionsHelper.CreateIncorporation(token, companyId, Constants.CloseDate, Constants.IncorporationName, TransactionType.Incorporation,
                Constants.PricePerShare, investments, new List<OptionPoolCreateRequest> { });

            //Act
            var investmentsPriceRound = TransactionsHelper.CreateInvestmentForPriceRoundWithOneStakeholder(DateTime.UtcNow, Constants.CommitedAmount, Constants.InvestmentAmount, InvestmentType.StandardShareIssuance, false,
               Constants.PriceRoundPricePerShare, shareClassId, Constants.ShareQuantity, personInvestorId);

            var optionPool = TransactionsHelper.CreateOptionPoolForPriceRound(companyId, Constants.PoolName, shareClassId, Constants.PoolPercentage, Constants.NewPoolSize, false);

            await TransactionsHelper.CreatePriceRound(token, companyId, DateTime.UtcNow.AddDays(+10), Constants.PriceRoundName, TransactionType.FundingRound,
                Constants.PriceRoundPreMoenyEvaluation, Constants.PriceRoundIssuedShareCapiatal, investmentsPriceRound, optionPool);

            //Assert
            var getTransactions = await GetAsync<IEnumerable<TransactionDto>>($"CapTable/GetAllTransactions/{companyId}");
            TransactionsAssertions.AssertPriceRoundTransactionWithOneInvestmentAndOptionPool(getTransactions, companyId, shareClassId);
        }

        [TestMethod]
        [TestCategory("Investor")]
        public async Task Test5_CreatePriceRoundWithInvestmentAndOptionPool_ShouldForbidden_WhneLoginAsInvestor()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            //Arrange
            var email = FakeEmailAddress.GetFakeEmailAddress();

            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var personInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonInvestorLastName, Constants.PhoneNumber, Constants.AddressLine1,
                            Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.InvestorEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                              UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                              Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.FounderEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            var investments = TransactionsHelper.CreateInvestmentForIncorporationWithOneStakeholder(DateTime.UtcNow.AddDays(-3), Constants.InvestmentAmount, InvestmentType.StandardShareIssuance,
                 shareClassId, Constants.ShareQuantity, personFounderId);

            await TransactionsHelper.CreateIncorporation(token, companyId, Constants.CloseDate, Constants.IncorporationName, TransactionType.Incorporation,
                Constants.PricePerShare, investments, new List<OptionPoolCreateRequest> { });

            //Act
            await GetTokenByRole(Role.Investor);
            var optionPool = new List<OptionPoolCreateRequest>();
            optionPool.Add(new OptionPoolCreateRequest()
            {
                CompanyId = companyId,
                PoolName = Constants.PoolName,
                ShareClassId = shareClassId,
                PoolPercentage = Constants.PoolPercentage,
                PoolSize = Constants.NewPoolSize,
                ReservedShares = false
            });

            investments.Add(new InvestmentCreateRequest()
            {
                ClosedDate = DateTime.UtcNow,
                CommitedAmount = Constants.CommitedAmount,
                InvestmentAmount = Constants.InvestmentAmount,
                InvestmentType = InvestmentType.StandardShareIssuance,
                LeadInvestor = false,
                PricePerShare = Constants.PriceRoundPricePerShare,
                ShareClassId = shareClassId,
                ShareQuantity = Constants.ShareQuantity,
                UserId = personInvestorId
            });

            var priceRoundCreateRequest = new TransactionRequest()
            {

                CompanyId = companyId,
                ClosedDate = DateTime.UtcNow.AddDays(+10),
                Name = Constants.PriceRoundName,
                TransactionType = TransactionType.FundingRound,
                IssuedShareCapital = Constants.PriceRoundIssuedShareCapiatal,
                PreMoneyValuation = Constants.PriceRoundPreMoenyEvaluation,
                Investments = investments,
                OptionPools = optionPool
            };

            var priceRound = await DI.Container.GetService<IRestClient>().Post(priceRoundCreateRequest, "CapTable/CreateTransaction", token);

            //Assert
            priceRound.ReasonPhrase.Should().Be("Forbidden");
        }
    }
}