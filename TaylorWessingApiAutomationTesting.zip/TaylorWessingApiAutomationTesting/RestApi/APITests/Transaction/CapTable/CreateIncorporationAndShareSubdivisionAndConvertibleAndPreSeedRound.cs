﻿using Contracts.Catalog.CapTable.Transactions;
using FluentAssertions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Outpace.Assertions;
using Outpace.Assertions.CapTable;
using Outpace.Helpers;
using Outpace.Models.Enum;
using Outpace.Models.Transaction;
using RestApi.FrameworkConfiguration;
using RestApi.Helpers;
using RestApi.Interfaces;
using RestApi.Models.CapTable;
using RestApi.Models.Company;
using RestApi.Models.Enum;
using RestApi.Models.Transaction;

namespace Outpace.APITests.Transaction.CapTable
{
    [TestClass]
    public class CreateIncorporationAndShareSubdivisionAndConvertibleAndPreSeedRound : BaseTestClass
    {
        [TestMethod]
        [TestCategory("PlatformAdmin")]
        public async Task Test1_CreateIncorporationAndShareSubdivisionAndConvertibleAndPreSeedRound_ShouldSucceed_WhenLoginAsPlatformAdmin()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            //create company
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //create 4 founders and 2 investors
            var firstFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                            Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var secondFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, "Marinel", "Rus", Constants.PhoneNumber,
                Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var thirdFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, "Denis", "Muresan", Constants.PhoneNumber,
                Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var forthFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, "Mihai", "Nesu", Constants.PhoneNumber,
                Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var firstInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                UserCreationType.NoOnBoarding, "Cosmin", "Prunean", Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 21), ReasonPhraseType.Created);

            var secondInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                UserCreationType.NoOnBoarding, "Gugustiuc", "Marinel", Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 21), ReasonPhraseType.Created);

            // create ordinary share class
            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            //Create incorporation transaction
            var investments = TransactionsHelper.CreateIncorporationWithFourStakeholder(DateTime.UtcNow.AddDays(-3), 1, InvestmentType.StandardShareIssuance,
               shareClassId, 1, firstFounderId, DateTime.UtcNow.AddDays(-3), 1, InvestmentType.StandardShareIssuance, shareClassId, 1, secondFounderId,
               DateTime.UtcNow.AddDays(-3), 1, InvestmentType.StandardShareIssuance, shareClassId, 1, thirdFounderId, DateTime.UtcNow.AddDays(-3), 1,
               InvestmentType.StandardShareIssuance, shareClassId, 1, forthFounderId);

            await TransactionsHelper.CreateIncorporation(token, companyId, Constants.CloseDate, Constants.IncorporationName, TransactionType.Incorporation,
                Constants.PricePerShare, investments, new List<OptionPoolCreateRequest> { });

            //Get and assert nominal value per share
            await TransactionsAssertions.GetAndAssertNominalValuePerShare(token, companyId, "1.000000000000000");

            //Get and Assert Cap table values from Home page after incorporation
            var getStartupHomePageDetails = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetails, Constants.HomePageTotalInvested, Constants.HomePageLatestTransaction, 4);

            //Get and Assert Cap table after incorporation            
            var getCapTableValues = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableOptionPoolAssertions.GetAndAssertCapTableAfterAnIncorporationForMultipleTransactions(getCapTableValues);

            // create a share subdivision transaction
            await TransactionsHelper.CreateShareSubdivision(token, companyId, DateTime.UtcNow.AddDays(-2), 100000);

            //Get and assert nominal value per share
            await TransactionsAssertions.GetAndAssertNominalValuePerShare(token, companyId, "0.000010000000000");

            //Get and Assert Cap table values from Home page after Subdivision
            var getStartupHomePageDetailsAfterSubdivision = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetailsAfterSubdivision, Constants.HomePageTotalInvested, Constants.HomePageLatestTransaction, 4);

            //Get and Assert Cap table after subdivision            
            var getCapTableValuesAfterSubdivision = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableSubDivisionAssertions.GetAndAssertCapTableAfterAnIncorporationAndSubDivisionTransaction(getCapTableValuesAfterSubdivision);

            //create a convertible transaction
            var investmentsConvertible = TransactionsHelper.CreateInvestmentForConvertibleWithOneStakeholder(firstInvestorId, 100000);
            var convertibleBasis = TransactionsHelper.CreateConversionBasis();

            await TransactionsHelper.CreateConvertible(token, companyId, 0, 500000, false, 20, DateTime.UtcNow.AddDays(-1), DateTime.UtcNow.AddDays(-1), "SAFE 1",
                false, investmentsConvertible, new List<ConvertibleClauseType> { }, convertibleBasis);

            //Get and Assert Cap table values from Home page after convertible
            var getStartupHomePageDetailsAfterConvertible = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetailsAfterConvertible, 100000, 100000, 5);

            //Get and Assert Cap table after convertible          
            var getCapTableValuesAfterConvetible = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableConvertibleAssertions.GetAndAssertCapTableAfterAnIncorporationShareSubdivisionConvertible(getCapTableValuesAfterConvetible);

            //create price round with two investments
            var investmentsPriceRound = TransactionsHelper.CreateInvestmentForPriceRoundWithLeadInvestor(DateTime.UtcNow, 500000, 500000, InvestmentType.StandardShareIssuance, true,
                 25, shareClassId, 20000, firstInvestorId, DateTime.UtcNow, 100000, 100000, InvestmentType.StandardShareIssuance, false,
                 25, shareClassId, 4000, secondInvestorId);

            await TransactionsHelper.CreatePriceRound(token, companyId, DateTime.UtcNow, "PriceRound", TransactionType.FundingRound,
                10000000, 400000, investmentsPriceRound, new List<OptionPoolCreateRequest> { });

            //Get cap table id for Price Round
            var capTableIdForAllTransactions = await GetAsync<IEnumerable<TransactionSummaryListDto>>($"CapTable/GetTransactionsForDropDown/{companyId}");
            var capTableId = capTableIdForAllTransactions.FirstOrDefault().CapTableId;

            //Get and Assert Cap table values from Home page after PriceRound          
            var getStartupHomePageDetailsAfterPriceRound = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetailsAfterPriceRound, 700000, 600000, 6);

            //Get and Assert Cap table after PriceRound       
            var getCapTableValuesAfterPriceRound = await GetAsync<CapTableResponse>($"CapTable/GetTransactionDetailsByCaptableId/{companyId}/{capTableId}");
            CapTablePriceRoundAssertions.GetAndAssertCapTableAfterPriceRound(getCapTableValuesAfterPriceRound);
        }

        [TestMethod]
        [TestCategory("Lawyer")]
        public async Task Test2_CreateIncorporationAndShareSubdivisionAndConvertibleAndPreSeedRound_ShouldSucceed_WhenLoginAsLawyer()
        {
            await GetTokenByRole(Role.Lawyer);
            //create company
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //create 4 founders and 2 investors
            var firstFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                            Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var secondFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, "Marinel", "Rus", Constants.PhoneNumber,
                Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var thirdFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, "Denis", "Muresan", Constants.PhoneNumber,
                Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var forthFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, "Mihai", "Nesu", Constants.PhoneNumber,
                Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var firstInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                UserCreationType.NoOnBoarding, "Cosmin", "Prunean", Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 21), ReasonPhraseType.Created);

            var secondInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                UserCreationType.NoOnBoarding, "Gugustiuc", "Marinel", Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 21), ReasonPhraseType.Created);

            // create ordinary share class
            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            //Create incorporation transaction
            var investments = TransactionsHelper.CreateIncorporationWithFourStakeholder(DateTime.UtcNow.AddDays(-3), 1, InvestmentType.StandardShareIssuance,
               shareClassId, 1, firstFounderId, DateTime.UtcNow.AddDays(-3), 1, InvestmentType.StandardShareIssuance, shareClassId, 1, secondFounderId,
               DateTime.UtcNow.AddDays(-3), 1, InvestmentType.StandardShareIssuance, shareClassId, 1, thirdFounderId, DateTime.UtcNow.AddDays(-3), 1,
               InvestmentType.StandardShareIssuance, shareClassId, 1, forthFounderId);

            await TransactionsHelper.CreateIncorporation(token, companyId, Constants.CloseDate, Constants.IncorporationName, TransactionType.Incorporation,
                Constants.PricePerShare, investments, new List<OptionPoolCreateRequest> { });

            //Get and assert nominal value per share
            await TransactionsAssertions.GetAndAssertNominalValuePerShare(token, companyId, "1.000000000000000");

            //Get and Assert Cap table values from Home page after incorporation
            var getStartupHomePageDetails = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetails, Constants.HomePageTotalInvested, Constants.HomePageLatestTransaction, 4);

            //Get and Assert Cap table after incorporation            
            var getCapTableValues = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableOptionPoolAssertions.GetAndAssertCapTableAfterAnIncorporationForMultipleTransactions(getCapTableValues);

            // create a share subdivision transaction
            await TransactionsHelper.CreateShareSubdivision(token, companyId, DateTime.UtcNow.AddDays(-2), 100000);

            //Get and assert nominal value per share
            await TransactionsAssertions.GetAndAssertNominalValuePerShare(token, companyId, "0.000010000000000");

            //Get and Assert Cap table values from Home page after Subdivision
            var getStartupHomePageDetailsAfterSubdivision = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetailsAfterSubdivision, Constants.HomePageTotalInvested, Constants.HomePageLatestTransaction, 4);

            //Get and Assert Cap table after subdivision            
            var getCapTableValuesAfterSubdivision = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableSubDivisionAssertions.GetAndAssertCapTableAfterAnIncorporationAndSubDivisionTransaction(getCapTableValuesAfterSubdivision);

            //create a convertible transaction
            var investmentsConvertible = TransactionsHelper.CreateInvestmentForConvertibleWithOneStakeholder(firstInvestorId, 100000);
            var convertibleBasis = TransactionsHelper.CreateConversionBasis();

            await TransactionsHelper.CreateConvertible(token, companyId, 0, 500000, false, 20, DateTime.UtcNow.AddDays(-1), DateTime.UtcNow.AddDays(-1), "SAFE 1",
                false, investmentsConvertible, new List<ConvertibleClauseType> { }, convertibleBasis);

            //Get and Assert Cap table values from Home page after convertible
            var getStartupHomePageDetailsAfterConvertible = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetailsAfterConvertible, 100000, 100000, 5);

            //Get and Assert Cap table after convertible          
            var getCapTableValuesAfterConvetible = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableConvertibleAssertions.GetAndAssertCapTableAfterAnIncorporationShareSubdivisionConvertible(getCapTableValuesAfterConvetible);

            //create price round with two investments
            var investmentsPriceRound = TransactionsHelper.CreateInvestmentForPriceRoundWithLeadInvestor(DateTime.UtcNow, 500000, 500000, InvestmentType.StandardShareIssuance, true,
                 25, shareClassId, 20000, firstInvestorId, DateTime.UtcNow, 100000, 100000, InvestmentType.StandardShareIssuance, false,
                 25, shareClassId, 4000, secondInvestorId);

            await TransactionsHelper.CreatePriceRound(token, companyId, DateTime.UtcNow, "PriceRound", TransactionType.FundingRound,
                10000000, 400000, investmentsPriceRound, new List<OptionPoolCreateRequest> { });

            //Get cap table id for Price Round
            var capTableIdForAllTransactions = await GetAsync<IEnumerable<TransactionSummaryListDto>>($"CapTable/GetTransactionsForDropDown/{companyId}");
            var capTableId = capTableIdForAllTransactions.FirstOrDefault().CapTableId;

            //Get and Assert Cap table values from Home page after PriceRound          
            var getStartupHomePageDetailsAfterPriceRound = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetailsAfterPriceRound, 700000, 600000, 6);

            //Get and Assert Cap table after PriceRound       
            var getCapTableValuesAfterPriceRound = await GetAsync<CapTableResponse>($"CapTable/GetTransactionDetailsByCaptableId/{companyId}/{capTableId}");
            CapTablePriceRoundAssertions.GetAndAssertCapTableAfterPriceRound(getCapTableValuesAfterPriceRound);
        }

        [TestMethod]
        [TestCategory("InstitutionAdmin")]
        public async Task Test3_CreateIncorporationAndShareSubdivisionAndConvertibleAndPreSeedRound_ShouldSucceed_WhenLoginAsInstitutionAdmin()
        {
            await GetTokenByRole(Role.InstitutionAdmin);
            //create company
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //create 4 founders and 2 investors
            var firstFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                            Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var secondFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, "Marinel", "Rus", Constants.PhoneNumber,
                Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var thirdFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, "Denis", "Muresan", Constants.PhoneNumber,
                Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var forthFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, "Mihai", "Nesu", Constants.PhoneNumber,
                Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var firstInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                UserCreationType.NoOnBoarding, "Cosmin", "Prunean", Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 21), ReasonPhraseType.Created);

            var secondInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                UserCreationType.NoOnBoarding, "Gugustiuc", "Marinel", Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 21), ReasonPhraseType.Created);

            // create ordinary share class
            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            //Create incorporation transaction
            var investments = TransactionsHelper.CreateIncorporationWithFourStakeholder(DateTime.UtcNow.AddDays(-3), 1, InvestmentType.StandardShareIssuance,
               shareClassId, 1, firstFounderId, DateTime.UtcNow.AddDays(-3), 1, InvestmentType.StandardShareIssuance, shareClassId, 1, secondFounderId,
               DateTime.UtcNow.AddDays(-3), 1, InvestmentType.StandardShareIssuance, shareClassId, 1, thirdFounderId, DateTime.UtcNow.AddDays(-3), 1,
               InvestmentType.StandardShareIssuance, shareClassId, 1, forthFounderId);

            await TransactionsHelper.CreateIncorporation(token, companyId, Constants.CloseDate, Constants.IncorporationName, TransactionType.Incorporation,
                Constants.PricePerShare, investments, new List<OptionPoolCreateRequest> { });

            //Get and assert nominal value per share
            await TransactionsAssertions.GetAndAssertNominalValuePerShare(token, companyId, "1.000000000000000");

            //Get and Assert Cap table values from Home page after incorporation
            var getStartupHomePageDetails = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetails, Constants.HomePageTotalInvested, Constants.HomePageLatestTransaction, 4);

            //Get and Assert Cap table after incorporation            
            var getCapTableValues = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableOptionPoolAssertions.GetAndAssertCapTableAfterAnIncorporationForMultipleTransactions(getCapTableValues);

            // create a share subdivision transaction
            await TransactionsHelper.CreateShareSubdivision(token, companyId, DateTime.UtcNow.AddDays(-2), 100000);

            //Get and assert nominal value per share
            await TransactionsAssertions.GetAndAssertNominalValuePerShare(token, companyId, "0.000010000000000");

            //Get and Assert Cap table values from Home page after Subdivision
            var getStartupHomePageDetailsAfterSubdivision = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetailsAfterSubdivision, Constants.HomePageTotalInvested, Constants.HomePageLatestTransaction, 4);

            //Get and Assert Cap table after subdivision            
            var getCapTableValuesAfterSubdivision = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableSubDivisionAssertions.GetAndAssertCapTableAfterAnIncorporationAndSubDivisionTransaction(getCapTableValuesAfterSubdivision);

            //create a convertible transaction
            var investmentsConvertible = TransactionsHelper.CreateInvestmentForConvertibleWithOneStakeholder(firstInvestorId, 100000);
            var convertibleBasis = TransactionsHelper.CreateConversionBasis();

            await TransactionsHelper.CreateConvertible(token, companyId, 0, 500000, false, 20, DateTime.UtcNow.AddDays(-1), DateTime.UtcNow.AddDays(-1), "SAFE 1",
                false, investmentsConvertible, new List<ConvertibleClauseType> { }, convertibleBasis);

            //Get and Assert Cap table values from Home page after convertible
            var getStartupHomePageDetailsAfterConvertible = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetailsAfterConvertible, 100000, 100000, 5);

            //Get and Assert Cap table after convertible          
            var getCapTableValuesAfterConvetible = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableConvertibleAssertions.GetAndAssertCapTableAfterAnIncorporationShareSubdivisionConvertible(getCapTableValuesAfterConvetible);

            //create price round with two investments
            var investmentsPriceRound = TransactionsHelper.CreateInvestmentForPriceRoundWithLeadInvestor(DateTime.UtcNow, 500000, 500000, InvestmentType.StandardShareIssuance, true,
                 25, shareClassId, 20000, firstInvestorId, DateTime.UtcNow, 100000, 100000, InvestmentType.StandardShareIssuance, false,
                 25, shareClassId, 4000, secondInvestorId);

            await TransactionsHelper.CreatePriceRound(token, companyId, DateTime.UtcNow, "PriceRound", TransactionType.FundingRound,
                10000000, 400000, investmentsPriceRound, new List<OptionPoolCreateRequest> { });

            //Get cap table id for Price Round
            var capTableIdForAllTransactions = await GetAsync<IEnumerable<TransactionSummaryListDto>>($"CapTable/GetTransactionsForDropDown/{companyId}");
            var capTableId = capTableIdForAllTransactions.FirstOrDefault().CapTableId;

            //Get and Assert Cap table values from Home page after PriceRound          
            var getStartupHomePageDetailsAfterPriceRound = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetailsAfterPriceRound, 700000, 600000, 6);

            //Get and Assert Cap table after PriceRound       
            var getCapTableValuesAfterPriceRound = await GetAsync<CapTableResponse>($"CapTable/GetTransactionDetailsByCaptableId/{companyId}/{capTableId}");
            CapTablePriceRoundAssertions.GetAndAssertCapTableAfterPriceRound(getCapTableValuesAfterPriceRound);
        }

        [TestMethod]
        [TestCategory("Founder")]
        public async Task Test4_CreateIncorporationAndShareSubdivisionAndConvertibleAndPreSeedRound_ShouldSucceed_WhenLoginAsFounder()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            //create company
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //create 4 founders and 2 investors
            var firstFounderId =await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                            Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.FounderEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var secondFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, "Marinel", "Rus", Constants.PhoneNumber,
                Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var thirdFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, "Denis", "Muresan", Constants.PhoneNumber,
                Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var forthFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, "Mihai", "Nesu", Constants.PhoneNumber,
                Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var firstInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                UserCreationType.NoOnBoarding, "Cosmin", "Prunean", Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 21), ReasonPhraseType.Created);

            var secondInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                UserCreationType.NoOnBoarding, "Gugustiuc", "Marinel", Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 21), ReasonPhraseType.Created);

            // create ordinary share class
            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            await GetTokenByRole(Role.Founder);
            //Create incorporation transaction
            var investments = TransactionsHelper.CreateIncorporationWithFourStakeholder(DateTime.UtcNow.AddDays(-3), 1, InvestmentType.StandardShareIssuance,
               shareClassId, 1, firstFounderId, DateTime.UtcNow.AddDays(-3), 1, InvestmentType.StandardShareIssuance, shareClassId, 1, secondFounderId,
               DateTime.UtcNow.AddDays(-3), 1, InvestmentType.StandardShareIssuance, shareClassId, 1, thirdFounderId, DateTime.UtcNow.AddDays(-3), 1,
               InvestmentType.StandardShareIssuance, shareClassId, 1, forthFounderId);

            await TransactionsHelper.CreateIncorporation(token, companyId, Constants.CloseDate, Constants.IncorporationName, TransactionType.Incorporation,
                Constants.PricePerShare, investments, new List<OptionPoolCreateRequest> { });

            //Get and assert nominal value per share
            await TransactionsAssertions.GetAndAssertNominalValuePerShare(token, companyId, "1.000000000000000");

            //Get and Assert Cap table values from Home page after incorporation
            var getStartupHomePageDetails = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetails, Constants.HomePageTotalInvested, Constants.HomePageLatestTransaction, 4);

            //Get and Assert Cap table after incorporation            
            var getCapTableValues = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableOptionPoolAssertions.GetAndAssertCapTableAfterAnIncorporationForMultipleTransactionsForFounder(getCapTableValues);

            // create a share subdivision transaction
            await TransactionsHelper.CreateShareSubdivision(token, companyId, DateTime.UtcNow.AddDays(-2), 100000);

            //Get and assert nominal value per share
            await TransactionsAssertions.GetAndAssertNominalValuePerShare(token, companyId, "0.000010000000000");

            //Get and Assert Cap table values from Home page after Subdivision
            var getStartupHomePageDetailsAfterSubdivision = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetailsAfterSubdivision, Constants.HomePageTotalInvested, Constants.HomePageLatestTransaction, 4);

            //Get and Assert Cap table after subdivision            
            var getCapTableValuesAfterSubdivision = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableSubDivisionAssertions.GetAndAssertCapTableAfterAnIncorporationAndSubDivissionTransactionForFounder(getCapTableValuesAfterSubdivision);

            //create a convertible transaction
            var investmentsConvertible = TransactionsHelper.CreateInvestmentForConvertibleWithOneStakeholder(firstInvestorId, 100000);
            var convertibleBasis = TransactionsHelper.CreateConversionBasis();

            await TransactionsHelper.CreateConvertible(token, companyId, 0, 500000, false, 20, DateTime.UtcNow.AddDays(-1), DateTime.UtcNow.AddDays(-1), "SAFE 1",
                false, investmentsConvertible, new List<ConvertibleClauseType> { }, convertibleBasis);

            //Get and Assert Cap table values from Home page after convertible
            var getStartupHomePageDetailsAfterConvertible = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetailsAfterConvertible, 100000, 100000, 5);

            //Get and Assert Cap table after convertible          
            var getCapTableValuesAfterConvetible = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableConvertibleAssertions.GetAndAssertCapTableAfterAnIncorporationAndConvertibleForFounders(getCapTableValuesAfterConvetible);

            //create price round with two investments
            var investmentsPriceRound = TransactionsHelper.CreateInvestmentForPriceRoundWithLeadInvestor(DateTime.UtcNow, 500000, 500000, InvestmentType.StandardShareIssuance, true,
                 25, shareClassId, 20000, firstInvestorId, DateTime.UtcNow, 100000, 100000, InvestmentType.StandardShareIssuance, false,
                 25, shareClassId, 4000, secondInvestorId);

            await TransactionsHelper.CreatePriceRound(token, companyId, DateTime.UtcNow, "PriceRound", TransactionType.FundingRound,
                10000000, 400000, investmentsPriceRound, new List<OptionPoolCreateRequest> { });

            //Get cap table id for Price Round
            var capTableIdForAllTransactions = await GetAsync<IEnumerable<TransactionSummaryListDto>>($"CapTable/GetTransactionsForDropDown/{companyId}");
            var capTableId = capTableIdForAllTransactions.FirstOrDefault().CapTableId;

            //Get and Assert Cap table values from Home page after PriceRound          
            var getStartupHomePageDetailsAfterPriceRound = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetailsAfterPriceRound, 700000, 600000, 6);

            //Get and Assert Cap table after PriceRound       
            var getCapTableValuesAfterPriceRound = await GetAsync<CapTableResponse>($"CapTable/GetTransactionDetailsByCaptableId/{companyId}/{capTableId}");
            CapTablePriceRoundAssertions.GetAndAssertCapTableAfterPriceRoundForFounder(getCapTableValuesAfterPriceRound);
        }

        [TestMethod]
        [TestCategory("Investor")]
        public async Task Test5_CreateIncorporationAndShareSubdivisionAndConvertibleAndPreSeedRound_ShouldForbidden_WhenLoginAsInvestor()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            //create company
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //create 4 founders and 2 investors
            var firstFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                            Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.FounderEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var secondFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, "Marinel", "Rus", Constants.PhoneNumber,
                Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var thirdFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, "Denis", "Muresan", Constants.PhoneNumber,
                Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var forthFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, "Mihai", "Nesu", Constants.PhoneNumber,
                Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var firstInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                UserCreationType.NoOnBoarding, "Cosmin", "Prunean", Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 21), ReasonPhraseType.Created);

            var secondInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                UserCreationType.NoOnBoarding, "Gugustiuc", "Marinel", Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 21), ReasonPhraseType.Created);

            // create ordinary share class
            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            //Create incorporation transaction
            var investments = TransactionsHelper.CreateIncorporationWithFourStakeholder(DateTime.UtcNow.AddDays(-3), 1, InvestmentType.StandardShareIssuance,
               shareClassId, 1, firstFounderId, DateTime.UtcNow.AddDays(-3), 1, InvestmentType.StandardShareIssuance, shareClassId, 1, secondFounderId,
               DateTime.UtcNow.AddDays(-3), 1, InvestmentType.StandardShareIssuance, shareClassId, 1, thirdFounderId, DateTime.UtcNow.AddDays(-3), 1,
               InvestmentType.StandardShareIssuance, shareClassId, 1, forthFounderId);

            await TransactionsHelper.CreateIncorporation(token, companyId, Constants.CloseDate, Constants.IncorporationName, TransactionType.Incorporation,
                Constants.PricePerShare, investments, new List<OptionPoolCreateRequest> { });

            //Get and assert nominal value per share
            await TransactionsAssertions.GetAndAssertNominalValuePerShare(token, companyId, "1.000000000000000");

            // create a share subdivision transaction
            await TransactionsHelper.CreateShareSubdivision(token, companyId, DateTime.UtcNow.AddDays(-2), 100000);

            //Get and assert nominal value per share
            await TransactionsAssertions.GetAndAssertNominalValuePerShare(token, companyId, "0.000010000000000");

            //create a convertible transaction
            var investmentsConvertible = TransactionsHelper.CreateInvestmentForConvertibleWithOneStakeholder(firstInvestorId, 100000);
            var convertibleBasis = TransactionsHelper.CreateConversionBasis();

            await TransactionsHelper.CreateConvertible(token, companyId, 0, 500000, false, 20, DateTime.UtcNow.AddDays(-1), DateTime.UtcNow.AddDays(-1), "SAFE 1",
                false, investmentsConvertible, new List<ConvertibleClauseType> { }, convertibleBasis);


            //create price round with two investments
            await GetTokenByRole(Role.Investor);

            investments.Add(new InvestmentCreateRequest()
            {
                ClosedDate = DateTime.UtcNow,
                CommitedAmount = 500000,
                InvestmentAmount = 500000,
                InvestmentType = InvestmentType.StandardShareIssuance,
                LeadInvestor = true,
                PricePerShare = 25,
                ShareClassId = shareClassId,
                ShareQuantity = 20000,
                UserId = firstInvestorId
            });

            investments.Add(new InvestmentCreateRequest()
            {
                ClosedDate = DateTime.UtcNow,
                CommitedAmount = 100000,
                InvestmentAmount = 100000,
                InvestmentType = InvestmentType.StandardShareIssuance,
                LeadInvestor = false,
                PricePerShare = 25,
                ShareClassId = shareClassId,
                ShareQuantity = 4000,
                UserId = secondInvestorId
            });

            var priceRoundCreateRequest = new TransactionRequest()
            {

                CompanyId = companyId,
                ClosedDate = DateTime.UtcNow,
                Name = "PriceRound",
                TransactionType = TransactionType.FundingRound,
                IssuedShareCapital = 10000000,
                PreMoneyValuation = 400000,
                Investments = investments,
                OptionPools = new List<OptionPoolCreateRequest> { }
            };

            var priceRound = await DI.Container.GetService<IRestClient>().Post(priceRoundCreateRequest, "CapTable/CreateTransaction", token);
            priceRound.ReasonPhrase.Should().Be("Forbidden");
        }
    }
}