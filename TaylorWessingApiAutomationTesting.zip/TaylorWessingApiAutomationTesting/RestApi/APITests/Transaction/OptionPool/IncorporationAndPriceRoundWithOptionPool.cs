﻿using Contracts.Catalog.CapTable.Transactions;
using FluentAssertions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Outpace.Assertions;
using Outpace.Helpers;
using Outpace.Models.Enum;
using RestApi.FrameworkConfiguration;
using RestApi.Helpers;
using RestApi.Interfaces;
using RestApi.Models.CapTable;
using RestApi.Models.Company;
using RestApi.Models.Enum;
using RestApi.Models.Transaction;

namespace Outpace.APITests.Transaction.OptionPool
{
    [TestClass]
    public class IncorporationAndPriceRoundWithOptionPool : BaseTestClass
    {
        [TestMethod]
        [TestCategory("PlatformAdmin")]
        public async Task Test1_CreateOptionPoolInPriceRoundTransaction_ShouldDisplayeCorrectValuesInCapTable_WhenLoginAsPlatformAdmin()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            //Create company
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //Create person founder
            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            //Create person investor
            var email = FakeEmailAddress.GetFakeEmailAddress();
            var personInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonInvestorLastName, Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, true, email, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            //Create Ordinary shareclass 
            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            //Create incorporation transaction
            var investments = TransactionsHelper.CreateInvestmentForIncorporationWithOneStakeholder(DateTime.UtcNow.AddDays(-3), 1, InvestmentType.StandardShareIssuance,
               shareClassId, 1000000, personFounderId);

            await TransactionsHelper.CreateIncorporation(token, companyId, Constants.CloseDate, Constants.IncorporationName, TransactionType.Incorporation,
                Constants.PricePerShare, investments, new List<OptionPoolCreateRequest> { });

            //Get and assert nominal value per share
            await TransactionsAssertions.GetAndAssertNominalValuePerShare(token, companyId, Constants.NominalValuePerShare);

            //Get and Assert Cap table values from Home page after incorporation
            var getStartupHomePageDetails = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetails, Constants.HomePageTotalInvested, Constants.HomePageLatestTransaction,
                Constants.HomePageStakeholderCount);

            //Get and Assert Cap table after incorporation            
            var getCapTableValues = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableOptionPoolAssertions.GetAndAssertCapTableAfterAnIncorporation(getCapTableValues);

            //Get Share Register documents
            var getResponseShareRegister = await GetAsync<ShareRegisterResponce>($"CapTable/GetShareRegisterCompanyId/{companyId}?skip=0&take=10");
            var investmentPersonFounderId = ShareRegisterAssertions.AssertShareRegisterForFounder(getResponseShareRegister, Constants.AddressLine1, "Ordinary Share Class",
                "FounderP Person", 1000000M);

            //download share certificate for person investor
            var getDownloadFounderCertificate = await DI.Container.GetService<IRestClient>().Get($"CapTable/DownloadCertificate/{investmentPersonFounderId}", token);
            getDownloadFounderCertificate.ReasonPhrase.Should().Be("OK");

            //create Price Round with one investment and 1 option pool
            var investmentsPriceRound = TransactionsHelper.CreateInvestmentForPriceRoundWithOneStakeholder(DateTime.UtcNow.AddDays(+91), 1000000, 1000000, InvestmentType.StandardShareIssuance, false,
                                   200, shareClassId, 500, personInvestorId);

            var optionPool = TransactionsHelper.CreateOptionPoolForPriceRound(companyId, Constants.PoolName, shareClassId, Constants.PoolPercentage, 1166, false);

            await TransactionsHelper.CreatePriceRound(token, companyId, DateTime.UtcNow.AddDays(+10), Constants.PriceRoundName, TransactionType.FundingRound,
                Constants.PriceRoundPreMoenyEvaluation, Constants.PriceRoundIssuedShareCapiatal, investmentsPriceRound, optionPool);

            //Get and Assert Cap table values from Home page after incorporation and option pool
            getStartupHomePageDetails = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetails, Constants.HomePageTotalInvested, Constants.HomePageLatestTransaction,
                Constants.HomePageStakeholderCount, Constants.HomePageFullyGrantedShares, 0.12M);

            //Get and Assert Cap table after incorporation and price round with option pool           
            getCapTableValues = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableOptionPoolAssertions.GetAndAssertCapTableAfterIncorporationAndPriceRoundWithOptionPool(getCapTableValues);
        }

        [TestMethod]
        [TestCategory("Lawyer")]
        public async Task Test2_CreateOptionPoolInPriceRoundTransaction_ShouldDisplayeCorrectValuesInCapTable_WhenLoginAsLawyer()
        {
            await GetTokenByRole(Role.Lawyer);
            //Create company
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //Create person founder
            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            //Create person investor
            var email = FakeEmailAddress.GetFakeEmailAddress();
            var personInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonInvestorLastName, Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, true, email, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            //Create Ordinary shareclass 
            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            //Create incorporation transaction
            var investments = TransactionsHelper.CreateInvestmentForIncorporationWithOneStakeholder(DateTime.UtcNow.AddDays(-3), 1, InvestmentType.StandardShareIssuance,
               shareClassId, 1000000, personFounderId);

            await TransactionsHelper.CreateIncorporation(token, companyId, Constants.CloseDate, Constants.IncorporationName, TransactionType.Incorporation,
                Constants.PricePerShare, investments, new List<OptionPoolCreateRequest> { });

            //Get and assert nominal value per share
            await TransactionsAssertions.GetAndAssertNominalValuePerShare(token, companyId, Constants.NominalValuePerShare);

            //Get and Assert Cap table values from Home page after incorporation
            var getStartupHomePageDetails = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetails, Constants.HomePageTotalInvested, Constants.HomePageLatestTransaction,
                Constants.HomePageStakeholderCount);

            //Get and Assert Cap table after incorporation            
            var getCapTableValues = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableOptionPoolAssertions.GetAndAssertCapTableAfterAnIncorporation(getCapTableValues);

            //Get Share Register documents
            var getResponseShareRegister = await GetAsync<ShareRegisterResponce>($"CapTable/GetShareRegisterCompanyId/{companyId}?skip=0&take=10");
            var investmentPersonFounderId = ShareRegisterAssertions.AssertShareRegisterForFounder(getResponseShareRegister, Constants.AddressLine1, "Ordinary Share Class",
                "FounderP Person", 1000000M);

            //download share certificate for person investor
            var getDownloadFounderCertificate = await DI.Container.GetService<IRestClient>().Get($"CapTable/DownloadCertificate/{investmentPersonFounderId}", token);
            getDownloadFounderCertificate.ReasonPhrase.Should().Be("OK");

            //create Price Round with one investment and 1 option pool
            var investmentsPriceRound = TransactionsHelper.CreateInvestmentForPriceRoundWithOneStakeholder(DateTime.UtcNow.AddDays(+91), 1000000, 1000000, InvestmentType.StandardShareIssuance, false,
                                   200, shareClassId, 500, personInvestorId);

            var optionPool = TransactionsHelper.CreateOptionPoolForPriceRound(companyId, Constants.PoolName, shareClassId, Constants.PoolPercentage, 1166, false);

            await TransactionsHelper.CreatePriceRound(token, companyId, DateTime.UtcNow.AddDays(+10), Constants.PriceRoundName, TransactionType.FundingRound,
                Constants.PriceRoundPreMoenyEvaluation, Constants.PriceRoundIssuedShareCapiatal, investmentsPriceRound, optionPool);

            //Get and Assert Cap table values from Home page after incorporation and option pool
            getStartupHomePageDetails = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetails, Constants.HomePageTotalInvested, Constants.HomePageLatestTransaction,
                Constants.HomePageStakeholderCount, Constants.HomePageFullyGrantedShares, 0.12M);

            //Get and Assert Cap table after incorporation and price round with option pool           
            getCapTableValues = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableOptionPoolAssertions.GetAndAssertCapTableAfterIncorporationAndPriceRoundWithOptionPool(getCapTableValues);
        }

        [TestMethod]
        [TestCategory("InstitutionAdmin")]
        public async Task Test3_CreateOptionPoolInPriceRoundTransaction_ShouldDisplayeCorrectValuesInCapTable_WhenLoginAsInstitutionAdmin()
        {
            await GetTokenByRole(Role.InstitutionAdmin);
            //Create company
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //Create person founder
            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            //Create person investor
            var email = FakeEmailAddress.GetFakeEmailAddress();
            var personInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonInvestorLastName, Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, true, email, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            //Create Ordinary shareclass 
            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            //Create incorporation transaction
            var investments = TransactionsHelper.CreateInvestmentForIncorporationWithOneStakeholder(DateTime.UtcNow.AddDays(-3), 1, InvestmentType.StandardShareIssuance,
               shareClassId, 1000000, personFounderId);

            await TransactionsHelper.CreateIncorporation(token, companyId, Constants.CloseDate, Constants.IncorporationName, TransactionType.Incorporation,
                Constants.PricePerShare, investments, new List<OptionPoolCreateRequest> { });

            //Get and assert nominal value per share
            await TransactionsAssertions.GetAndAssertNominalValuePerShare(token, companyId, Constants.NominalValuePerShare);

            //Get and Assert Cap table values from Home page after incorporation
            var getStartupHomePageDetails = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetails, Constants.HomePageTotalInvested, Constants.HomePageLatestTransaction,
                Constants.HomePageStakeholderCount);

            //Get and Assert Cap table after incorporation            
            var getCapTableValues = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableOptionPoolAssertions.GetAndAssertCapTableAfterAnIncorporation(getCapTableValues);

            //Get Share Register documents
            var getResponseShareRegister = await GetAsync<ShareRegisterResponce>($"CapTable/GetShareRegisterCompanyId/{companyId}?skip=0&take=10");
            var investmentPersonFounderId = ShareRegisterAssertions.AssertShareRegisterForFounder(getResponseShareRegister, Constants.AddressLine1, "Ordinary Share Class",
                "FounderP Person", 1000000M);

            //download share certificate for person investor
            var getDownloadFounderCertificate = await DI.Container.GetService<IRestClient>().Get($"CapTable/DownloadCertificate/{investmentPersonFounderId}", token);
            getDownloadFounderCertificate.ReasonPhrase.Should().Be("OK");

            //create Price Round with one investment and 1 option pool
            var investmentsPriceRound = TransactionsHelper.CreateInvestmentForPriceRoundWithOneStakeholder(DateTime.UtcNow.AddDays(+91), 1000000, 1000000, InvestmentType.StandardShareIssuance, false,
                                   200, shareClassId, 500, personInvestorId);

            var optionPool = TransactionsHelper.CreateOptionPoolForPriceRound(companyId, Constants.PoolName, shareClassId, Constants.PoolPercentage, 1166, false);

            await TransactionsHelper.CreatePriceRound(token, companyId, DateTime.UtcNow.AddDays(+10), Constants.PriceRoundName, TransactionType.FundingRound,
                Constants.PriceRoundPreMoenyEvaluation, Constants.PriceRoundIssuedShareCapiatal, investmentsPriceRound, optionPool);

            //Get and Assert Cap table values from Home page after incorporation and option pool
            getStartupHomePageDetails = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetails, Constants.HomePageTotalInvested, Constants.HomePageLatestTransaction,
                Constants.HomePageStakeholderCount, Constants.HomePageFullyGrantedShares, 0.12M);

            //Get and Assert Cap table after incorporation and price round with option pool           
            getCapTableValues = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableOptionPoolAssertions.GetAndAssertCapTableAfterIncorporationAndPriceRoundWithOptionPool(getCapTableValues);
        }

        [TestMethod]
        [TestCategory("Founder")]
        public async Task Test4_CreateOptionPoolInPriceRoundTransaction_ShouldDisplayeCorrectValuesInCapTable_WhenLoginAsFounder()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            //Create company
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //Create person founder
            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                              UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                              Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.FounderEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            //Create person investor
            var email = FakeEmailAddress.GetFakeEmailAddress();
            var personInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonInvestorLastName, Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, true, email, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            //Create Ordinary shareclass 
            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            await GetTokenByRole(Role.Founder);
            //Create incorporation transaction
            var investments = TransactionsHelper.CreateInvestmentForIncorporationWithOneStakeholder(DateTime.UtcNow.AddDays(-3), 1, InvestmentType.StandardShareIssuance,
               shareClassId, 1000000, personFounderId);

            await TransactionsHelper.CreateIncorporation(token, companyId, Constants.CloseDate, Constants.IncorporationName, TransactionType.Incorporation,
                Constants.PricePerShare, investments, new List<OptionPoolCreateRequest> { });

            //Get and assert nominal value per share
            await TransactionsAssertions.GetAndAssertNominalValuePerShare(token, companyId, Constants.NominalValuePerShare);

            //Get and Assert Cap table values from Home page after incorporation
            var getStartupHomePageDetails = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetails, Constants.HomePageTotalInvested, Constants.HomePageLatestTransaction,
                Constants.HomePageStakeholderCount);

            //Get and Assert Cap table after incorporation            
            var getCapTableValues = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableOptionPoolAssertions.GetAndAssertCapTableAfterAnIncorporationAndOptionPoolinPriceRoundForFounder(getCapTableValues);

            //Get Share Register documents
            var getResponseShareRegister = await GetAsync<ShareRegisterResponce>($"CapTable/GetShareRegisterCompanyId/{companyId}?skip=0&take=10");
            var investmentPersonFounderId = ShareRegisterAssertions.AssertShareRegisterForFounder(getResponseShareRegister, "", "Ordinary Share Class",
                "PersonFaunder Automatio", 1000000M);

            //download share certificate for person investor
            var getDownloadFounderCertificate = await DI.Container.GetService<IRestClient>().Get($"CapTable/DownloadCertificate/{investmentPersonFounderId}", token);
            getDownloadFounderCertificate.ReasonPhrase.Should().Be("OK");

            //create Price Round with one investment and 1 option pool
            var investmentsPriceRound = TransactionsHelper.CreateInvestmentForPriceRoundWithOneStakeholder(DateTime.UtcNow.AddDays(+91), 1000000, 1000000, InvestmentType.StandardShareIssuance, false,
                                   200, shareClassId, 500, personInvestorId);

            var optionPool = TransactionsHelper.CreateOptionPoolForPriceRound(companyId, Constants.PoolName, shareClassId, Constants.PoolPercentage, 1166, false);

            await TransactionsHelper.CreatePriceRound(token, companyId, DateTime.UtcNow.AddDays(+10), Constants.PriceRoundName, TransactionType.FundingRound,
                Constants.PriceRoundPreMoenyEvaluation, Constants.PriceRoundIssuedShareCapiatal, investmentsPriceRound, optionPool);

            //Get and Assert Cap table values from Home page after incorporation and option pool
            getStartupHomePageDetails = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetails, Constants.HomePageTotalInvested, Constants.HomePageLatestTransaction,
                Constants.HomePageStakeholderCount, Constants.HomePageFullyGrantedShares, 0.12M);

            //Get and Assert Cap table after incorporation and price round with option pool           
            getCapTableValues = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableOptionPoolAssertions.GetAndAssertCapTableAfterIncorporationAndPriceRoundWithOptionPoolForFounder(getCapTableValues);
        }

        [TestMethod]
        [TestCategory("Investor")]
        public async Task Test5_CreateOptionPoolInPriceRoundTransaction_ShouldDisplayeForbidden_WhenLoginAsInvestor()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            //Create company
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //Create person founder
            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                              UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                              Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.FounderEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            //Create person investor
            var personInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonInvestorLastName, Constants.PhoneNumber, Constants.AddressLine1,
                            Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.InvestorEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            //Create Ordinary shareclass 
            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            //Create incorporation transaction
            var investments = TransactionsHelper.CreateInvestmentForIncorporationWithOneStakeholder(DateTime.UtcNow.AddDays(-3), 1, InvestmentType.StandardShareIssuance,
               shareClassId, 1000000, personFounderId);

            await TransactionsHelper.CreateIncorporation(token, companyId, Constants.CloseDate, Constants.IncorporationName, TransactionType.Incorporation,
                Constants.PricePerShare, investments, new List<OptionPoolCreateRequest> { });

            await GetTokenByRole(Role.Investor);
            //create Price Round with one investment and 1 option pool

            var optionPool = new List<OptionPoolCreateRequest>();
            optionPool.Add(new OptionPoolCreateRequest()
            {
                CompanyId = companyId,
                PoolName = Constants.PoolName,
                ShareClassId = shareClassId,
                PoolPercentage = Constants.PoolPercentage,
                PoolSize = 1166,
                ReservedShares = false
            });

            investments.Add(new InvestmentCreateRequest()
            {
                ClosedDate = DateTime.UtcNow.AddDays(+91),
                CommitedAmount = 1000000,
                InvestmentAmount = 1000000,
                InvestmentType = InvestmentType.StandardShareIssuance,
                LeadInvestor = false,
                PricePerShare = 200,
                ShareClassId = shareClassId,
                ShareQuantity = 500,
                UserId = personInvestorId
            });

            var incorporationCreateRequest = new TransactionRequest()
            {

                CompanyId = companyId,
                ClosedDate = DateTime.UtcNow.AddDays(+10),
                Name = Constants.PriceRoundName,
                TransactionType = TransactionType.FundingRound,
                IssuedShareCapital = Constants.PriceRoundIssuedShareCapiatal,
                PreMoneyValuation = Constants.PriceRoundPreMoenyEvaluation,
                Investments = investments,
                OptionPools = optionPool
            };

            var incorporation = await DI.Container.GetService<IRestClient>().Post(incorporationCreateRequest, "CapTable/CreateTransaction", token);
            incorporation.ReasonPhrase.Should().Be("Forbidden");
        }
    }
}