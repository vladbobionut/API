﻿using FluentAssertions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Outpace.Assertions;
using Outpace.Helpers;
using Outpace.Models.Enum;
using RestApi.FrameworkConfiguration;
using RestApi.Helpers;
using RestApi.Interfaces;
using RestApi.Models.Company;
using RestApi.Models.Enum;
using RestApi.Models.Transaction;

namespace Outpace.APITests.Transaction.OptionPool
{
    [TestClass]
    public class CreateOptionPool : BaseTestClass
    {
        [TestMethod]
        [TestCategory("PlatformAdmin")]
        public async Task Test1_CreateOptionPoolTransaction_ShouldSucceed_WhenLoginAsPlatformAdmin()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            //Arrange
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            //Act
            var optionPoolId = await TransactionsHelper.CreateOptionPool(token, companyId, DateTime.UtcNow.AddDays(-3), Constants.PoolName,
                Constants.PoolPercentage, Constants.PoolSize, false, shareClassId);

            //Assert
            var getOptionPool = await GetAsync<IEnumerable<TransactionDto>>($"CapTable/GetAllTransactions/{companyId}");
            TransactionsAssertions.AssertOptionPool(getOptionPool, companyId, optionPoolId, shareClassId);
        }

        [TestMethod]
        [TestCategory("Lawyer")]
        public async Task Test2_CreateOptionPoolTransaction_ShouldSucceed_WhneLoginAsLawyer()
        {
            await GetTokenByRole(Role.Lawyer);
            //Arrange
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            //Act
            var optionPoolId = await TransactionsHelper.CreateOptionPool(token, companyId, DateTime.UtcNow.AddDays(-3), Constants.PoolName,
                Constants.PoolPercentage, Constants.PoolSize, false, shareClassId);

            //Assert
            var getOptionPool = await GetAsync<IEnumerable<TransactionDto>>($"CapTable/GetAllTransactions/{companyId}");
            TransactionsAssertions.AssertOptionPool(getOptionPool, companyId, optionPoolId, shareClassId);
        }

        [TestMethod]
        [TestCategory("InstitutionAdmin")]
        public async Task Test3_CreateOptionPoolTransaction_ShouldSucceed_WhenLoginAsInstitutionAdmin()
        {
            await GetTokenByRole(Role.InstitutionAdmin);
            //Arrange
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            //Act
            var optionPoolId = await TransactionsHelper.CreateOptionPool(token, companyId, DateTime.UtcNow.AddDays(-3), Constants.PoolName,
                Constants.PoolPercentage, Constants.PoolSize, false, shareClassId);

            //Assert
            var getOptionPool = await GetAsync<IEnumerable<TransactionDto>>($"CapTable/GetAllTransactions/{companyId}");
            TransactionsAssertions.AssertOptionPool(getOptionPool, companyId, optionPoolId, shareClassId);
        }

        [TestMethod]
        [TestCategory("Founder")]
        public async Task Test4_CreateOptionPoolTransaction_ShouldSucceed_WhenLoginAsFounder()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            //Arrange
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                              UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                              Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.FounderEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            await GetTokenByRole(Role.Founder);
            //Act
            var optionPoolId = await TransactionsHelper.CreateOptionPool(token, companyId, DateTime.UtcNow.AddDays(-3), Constants.PoolName,
                Constants.PoolPercentage, Constants.PoolSize, false, shareClassId);

            //Assert
            var getOptionPool = await GetAsync<IEnumerable<TransactionDto>>($"CapTable/GetAllTransactions/{companyId}");
            TransactionsAssertions.AssertOptionPool(getOptionPool, companyId, optionPoolId, shareClassId);
        }

        [TestMethod]
        [TestCategory("Investor")]
        public async Task Test5_CreateOptionPoolTransaction_ShouldReturnForbidden_WhenLoginAsInvestor()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            //Arrange
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            var personInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonInvestorLastName, Constants.PhoneNumber, Constants.AddressLine1,
                            Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.InvestorEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            await GetTokenByRole(Role.Investor);
            //Act
            var createOptionPool = new OptionPoolCreateRequest()
            {
                CompanyId = companyId,
                Date = DateTime.UtcNow.AddDays(-3),
                PoolName = Constants.PoolName,
                PoolPercentage = Constants.PoolPercentage,
                PoolSize = Constants.PoolSize,
                ReservedShares = false,
                ShareClassId = shareClassId
            };
            var optionPool = await DI.Container.GetService<IRestClient>().Post(createOptionPool, "OptionPool/Create", token);
            optionPool.ReasonPhrase.Should().Be("Forbidden");
        }
    }
}