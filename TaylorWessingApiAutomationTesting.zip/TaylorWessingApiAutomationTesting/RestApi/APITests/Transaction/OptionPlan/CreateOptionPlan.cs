﻿using FluentAssertions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Outpace.Assertions;
using Outpace.Helpers;
using Outpace.Models.Enum;
using Outpace.Models.Transaction;
using RestApi.FrameworkConfiguration;
using RestApi.Helpers;
using RestApi.Interfaces;
using RestApi.Models.Company;
using RestApi.Models.Enum;
using RestApi.Models.Transaction;

namespace Outpace.APITests.Transaction.OptionPlan
{
    [TestClass]
    public class CreateOptionPlan : BaseTestClass
    {
        [TestMethod]
        [TestCategory("PlatformAdmin")]
        public async Task Test1_CreateOptionPlanTransaction_ShouldSucceed_WhneLoginAsPlatformAdmin()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            //Arrange
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            var optionPoolId = await TransactionsHelper.CreateOptionPool(token, companyId, DateTime.UtcNow.AddDays(-3), Constants.PoolName,
                Constants.PoolPercentage, Constants.PoolSize, false, shareClassId);

            //Act
            var optionPlanId = await TransactionsHelper.CreateOptionPlan(token, companyId, Constants.OptionPlanCliff, DateTime.UtcNow.AddDays(-3), GrantType.EMI, Constants.OptionPlanName,
                optionPoolId, Constants.StrikePrice, Constants.VestingDuration, Constants.VestingFrequency, VestingOption.SimpleTime, DateTime.UtcNow);

            //Assert
            var getOptionPlan = await GetAsync<IEnumerable<TransactionDto>>($"CapTable/GetAllTransactions/{companyId}");
            TransactionsAssertions.AsseertOptionPlan(getOptionPlan, companyId);
        }

        [TestMethod]
        [TestCategory("Lawyer")]
        public async Task Test2_CreateOptionPlanTransaction_ShouldSucceed_WhneLoginAsLawyer()
        {
            await GetTokenByRole(Role.Lawyer);
            //Arrange
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            var optionPoolId = await TransactionsHelper.CreateOptionPool(token, companyId, DateTime.UtcNow.AddDays(-3), Constants.PoolName,
                Constants.PoolPercentage, Constants.PoolSize, false, shareClassId);

            //Act
            var optionPlanId = await TransactionsHelper.CreateOptionPlan(token, companyId, Constants.OptionPlanCliff, DateTime.UtcNow.AddDays(-3), GrantType.EMI, Constants.OptionPlanName,
                optionPoolId, Constants.StrikePrice, Constants.VestingDuration, Constants.VestingFrequency, VestingOption.SimpleTime, DateTime.UtcNow);

            //Assert
            var getOptionPlan = await GetAsync<IEnumerable<TransactionDto>>($"CapTable/GetAllTransactions/{companyId}");
            TransactionsAssertions.AsseertOptionPlan(getOptionPlan, companyId);
        }

        [TestMethod]
        [TestCategory("InstitutionAdmin")]
        public async Task Test3_CreateOptionPlanTransaction_ShouldSucceed_WhneLoginAsInstitutionAdmin()
        {
            await GetTokenByRole(Role.InstitutionAdmin);
            //Arrange
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            var optionPoolId = await TransactionsHelper.CreateOptionPool(token, companyId, DateTime.UtcNow.AddDays(-3), Constants.PoolName,
                Constants.PoolPercentage, Constants.PoolSize, false, shareClassId);

            //Act
            var optionPlanId = await TransactionsHelper.CreateOptionPlan(token, companyId, Constants.OptionPlanCliff, DateTime.UtcNow.AddDays(-3), GrantType.EMI, Constants.OptionPlanName,
                optionPoolId, Constants.StrikePrice, Constants.VestingDuration, Constants.VestingFrequency, VestingOption.SimpleTime, DateTime.UtcNow);

            //Assert
            var getOptionPlan = await GetAsync<IEnumerable<TransactionDto>>($"CapTable/GetAllTransactions/{companyId}");
            TransactionsAssertions.AsseertOptionPlan(getOptionPlan, companyId);
        }

        [TestMethod]
        [TestCategory("Founder")]
        public async Task Test4_CreateOptionPlanTransaction_ShouldSucceed_WhneLoginAsFounder()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            //Arrange
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                  UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                  Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.FounderEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            await GetTokenByRole(Role.Founder);
            var optionPoolId = await TransactionsHelper.CreateOptionPool(token, companyId, DateTime.UtcNow.AddDays(-3), Constants.PoolName,
                Constants.PoolPercentage, Constants.PoolSize, false, shareClassId);

            //Act
            var optionPlanId = await TransactionsHelper.CreateOptionPlan(token, companyId, Constants.OptionPlanCliff, DateTime.UtcNow.AddDays(-3), GrantType.EMI, Constants.OptionPlanName,
                optionPoolId, Constants.StrikePrice, Constants.VestingDuration, Constants.VestingFrequency, VestingOption.SimpleTime, DateTime.UtcNow);

            //Assert
            var getOptionPlan = await GetAsync<IEnumerable<TransactionDto>>($"CapTable/GetAllTransactions/{companyId}");
            TransactionsAssertions.AsseertOptionPlan(getOptionPlan, companyId);
        }

        [TestMethod]
        [TestCategory("Investor")]
        public async Task Test5_CreateOptionPlanTransaction_ShouldSucceed_WhneLoginAsInvestor()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            //Arrange
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            var personInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonInvestorLastName, Constants.PhoneNumber, Constants.AddressLine1,
                            Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.InvestorEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            await GetTokenByRole(Role.Investor);
            //Act
            var createOptionPool = new OptionPoolCreateRequest()
            {
                CompanyId = companyId,
                Date = DateTime.UtcNow.AddDays(-3),
                PoolName = Constants.PoolName,
                PoolPercentage = Constants.PoolPercentage,
                PoolSize = Constants.PoolSize,
                ReservedShares = false,
                ShareClassId = shareClassId
            };

            var optionPool = await DI.Container.GetService<IRestClient>().Post(createOptionPool, "OptionPool/Create", token);
            optionPool.ReasonPhrase.Should().Be("Forbidden");
        }
    }
}