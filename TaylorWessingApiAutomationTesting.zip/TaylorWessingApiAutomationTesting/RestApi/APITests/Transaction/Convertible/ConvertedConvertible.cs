﻿using Contracts.Catalog.CapTable.Transactions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Outpace.Assertions;
using Outpace.Assertions.CapTable;
using Outpace.Helpers;
using Outpace.Models.Enum;
using Outpace.Models.Transaction;
using RestApi.Helpers;
using RestApi.Models.CapTable;
using RestApi.Models.Company;
using RestApi.Models.Enum;
using RestApi.Models.Transaction;


namespace Outpace.APITests.Transaction.Convertible
{
    [TestClass]
    public class ConvertedConvertible : BaseTestClass
    {
        [TestMethod]
        [TestCategory("PlatformAdmin")]
        public async Task Test1_CreatePriceRoundWithConvertedConvertible_ShouldSucceed_WhneLoginAsPlatformAdmin()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            //create company
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //create 4 founders and 1 investor
            var firstFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                            Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var secondFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, "Marinel", "Rus", Constants.PhoneNumber,
                Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var thirdFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, "Denis", "Muresan", Constants.PhoneNumber,
                Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var forthFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, "Mihai", "Nesu", Constants.PhoneNumber,
                Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var firstInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                UserCreationType.NoOnBoarding, "Cosmin", "Prunean", Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 21), ReasonPhraseType.Created);

            // create ordinary share class
            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            //Create incorporation transaction
            var investments = TransactionsHelper.CreateIncorporationWithFourStakeholder(DateTime.UtcNow.AddDays(-3), 1, InvestmentType.StandardShareIssuance,
               shareClassId, 1, firstFounderId, DateTime.UtcNow.AddDays(-3), 1, InvestmentType.StandardShareIssuance, shareClassId, 1, secondFounderId,
               DateTime.UtcNow.AddDays(-3), 1, InvestmentType.StandardShareIssuance, shareClassId, 1, thirdFounderId, DateTime.UtcNow.AddDays(-3), 1,
               InvestmentType.StandardShareIssuance, shareClassId, 1, forthFounderId);

            await TransactionsHelper.CreateIncorporation(token, companyId, Constants.CloseDate, Constants.IncorporationName, TransactionType.Incorporation,
                Constants.PricePerShare, investments, new List<OptionPoolCreateRequest> { });

            //Get and assert nominal value per share
            await TransactionsAssertions.GetAndAssertNominalValuePerShare(token, companyId, "1.000000000000000");

            //Get and Assert Cap table values from Home page after incorporation
            var getStartupHomePageDetails = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetails, Constants.HomePageTotalInvested, Constants.HomePageLatestTransaction, 4);

            //Get and Assert Cap table after incorporation            
            var getCapTableValues = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableOptionPoolAssertions.GetAndAssertCapTableAfterAnIncorporationForMultipleTransactions(getCapTableValues);

            //create a convertible transaction
            var investmentsConvertible = TransactionsHelper.CreateInvestmentForConvertibleWithOneStakeholder(firstInvestorId, 100000);
            var convertibleBasis = TransactionsHelper.CreateConversionBasis();

            await TransactionsHelper.CreateConvertible(token, companyId, 0, 500000, false, 20, DateTime.UtcNow.AddDays(-3), DateTime.UtcNow.AddDays(-1), "SAFE 1",
                false, investmentsConvertible, new List<ConvertibleClauseType> { }, convertibleBasis);

            //get Convertible Id
            var getAllTransaction = await GetAsync<IEnumerable<TransactionDto>>($"CapTable/GetAllTransactions/{companyId}");
            var convertible = getAllTransaction.Where(x => x.TransactionType == TransactionType.ConvertibleLoan).First().ConvertibleLoans.First();

            //Get and Assert Cap table values from Home page after convertible
            var getStartupHomePageDetailsAfterConvertible = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetailsAfterConvertible, 100000, 100000, 5);

            //Get and Assert Cap table after convertible          
            var getCapTableValuesAfterConvetible = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableConvertibleAssertions.GetAndAssertCapTableAfterAnIncorporationAndConvertible(getCapTableValuesAfterConvetible);

            //create a price round with 1 investor and converted converible included
            var investmentsPriceRound = TransactionsHelper.CreateInvestmentForTransactionsWithOneStakeholder(DateTime.UtcNow.AddDays(-3), 50000, 50000, InvestmentType.StandardShareIssuance,
                 shareClassId, 40000, firstInvestorId);

            var investmentsForConvertible = TransactionsHelper.ConvertibleInvestments(convertible.ConvertibleInvestments.First().Id, 109999, (decimal)99999.27, shareClassId, 0, (decimal)0.90909256, false);

            var converibles = TransactionsHelper.CreateConvertiblesForPriceRound(convertible.Id, 500000, 0,
                    new List<ConversionBaseType> { ConversionBaseType.IssuedShareCapital, ConversionBaseType.NewInvestorShares, ConversionBaseType.ConversionShares, ConversionBaseType.ESOPIncrease },
                    new List<ConvertibleClauseType> { }, investmentsForConvertible);

            await TransactionsHelper.CreatePriceRoundWithInvestmnetConvertibleAndOptionPool(token, companyId, DateTime.UtcNow.AddDays(-1), Constants.PriceRoundName, TransactionType.FundingRound,
           Constants.PriceRoundPreMoenyEvaluation, 400000, investmentsPriceRound, new List<OptionPoolCreateRequest> { }, converibles);

            //Get cap table id for Price Round
            var capTableIdForAllTransactions = await GetAsync<IEnumerable<TransactionSummaryListDto>>($"CapTable/GetTransactionsForDropDown/{companyId}");
            var capTableId = capTableIdForAllTransactions.FirstOrDefault().CapTableId;

            //Get and Assert Cap table values from Home page after PriceRound          
            var getStartupHomePageDetailsAfterPriceRound = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetailsAfterPriceRound, (decimal)149999.27, (decimal) 149999.27, 5);

            //Get and Assert Cap table after PriceRound       
            var getCapTableValuesAfterPriceRound = await GetAsync<CapTableResponse>($"CapTable/GetTransactionDetailsByCaptableId/{companyId}/{capTableId}");
            CapTableConvertibleAssertions.GetAndAssertCapTableForPriceRoundWithConvertedConvertible(getCapTableValuesAfterPriceRound);
        }

        [TestMethod]
        [TestCategory("Lawyer")]
        public async Task Test2_CreatePriceRoundWithConvertedConvertible_ShouldSucceed_WhneLoginAsLawyer()
        {
            await GetTokenByRole(Role.Lawyer);
            //create company
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //create 4 founders and 1 investor
            var firstFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                            Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var secondFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, "Marinel", "Rus", Constants.PhoneNumber,
                Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var thirdFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, "Denis", "Muresan", Constants.PhoneNumber,
                Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var forthFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, "Mihai", "Nesu", Constants.PhoneNumber,
                Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var firstInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                UserCreationType.NoOnBoarding, "Cosmin", "Prunean", Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 21), ReasonPhraseType.Created);

            // create ordinary share class
            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            //Create incorporation transaction
            var investments = TransactionsHelper.CreateIncorporationWithFourStakeholder(DateTime.UtcNow.AddDays(-3), 1, InvestmentType.StandardShareIssuance,
               shareClassId, 1, firstFounderId, DateTime.UtcNow.AddDays(-3), 1, InvestmentType.StandardShareIssuance, shareClassId, 1, secondFounderId,
               DateTime.UtcNow.AddDays(-3), 1, InvestmentType.StandardShareIssuance, shareClassId, 1, thirdFounderId, DateTime.UtcNow.AddDays(-3), 1,
               InvestmentType.StandardShareIssuance, shareClassId, 1, forthFounderId);

            await TransactionsHelper.CreateIncorporation(token, companyId, Constants.CloseDate, Constants.IncorporationName, TransactionType.Incorporation,
                Constants.PricePerShare, investments, new List<OptionPoolCreateRequest> { });

            //Get and assert nominal value per share
            await TransactionsAssertions.GetAndAssertNominalValuePerShare(token, companyId, "1.000000000000000");

            //Get and Assert Cap table values from Home page after incorporation
            var getStartupHomePageDetails = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetails, Constants.HomePageTotalInvested, Constants.HomePageLatestTransaction, 4);

            //Get and Assert Cap table after incorporation            
            var getCapTableValues = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableOptionPoolAssertions.GetAndAssertCapTableAfterAnIncorporationForMultipleTransactions(getCapTableValues);

            //create a convertible transaction
            var investmentsConvertible = TransactionsHelper.CreateInvestmentForConvertibleWithOneStakeholder(firstInvestorId, 100000);
            var convertibleBasis = TransactionsHelper.CreateConversionBasis();

            await TransactionsHelper.CreateConvertible(token, companyId, 0, 500000, false, 20, DateTime.UtcNow.AddDays(-3), DateTime.UtcNow.AddDays(-1), "SAFE 1",
                false, investmentsConvertible, new List<ConvertibleClauseType> { }, convertibleBasis);

            //get Convertible Id
            var getAllTransaction = await GetAsync<IEnumerable<TransactionDto>>($"CapTable/GetAllTransactions/{companyId}");
            var convertible = getAllTransaction.Where(x => x.TransactionType == TransactionType.ConvertibleLoan).First().ConvertibleLoans.First();

            //Get and Assert Cap table values from Home page after convertible
            var getStartupHomePageDetailsAfterConvertible = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetailsAfterConvertible, 100000, 100000, 5);

            //Get and Assert Cap table after convertible          
            var getCapTableValuesAfterConvetible = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableConvertibleAssertions.GetAndAssertCapTableAfterAnIncorporationAndConvertible(getCapTableValuesAfterConvetible);

            //create a price round with 1 investor and converted converible included
            var investmentsPriceRound = TransactionsHelper.CreateInvestmentForTransactionsWithOneStakeholder(DateTime.UtcNow.AddDays(-3), 50000, 50000, InvestmentType.StandardShareIssuance,
                 shareClassId, 40000, firstInvestorId);

            var investmentsForConvertible = TransactionsHelper.ConvertibleInvestments(convertible.ConvertibleInvestments.First().Id, 109999, (decimal)99999.27, shareClassId, 0, (decimal)0.90909256, false);

            var converibles = TransactionsHelper.CreateConvertiblesForPriceRound(convertible.Id, 500000, 0,
                    new List<ConversionBaseType> { ConversionBaseType.IssuedShareCapital, ConversionBaseType.NewInvestorShares, ConversionBaseType.ConversionShares, ConversionBaseType.ESOPIncrease },
                    new List<ConvertibleClauseType> { }, investmentsForConvertible);

            await TransactionsHelper.CreatePriceRoundWithInvestmnetConvertibleAndOptionPool(token, companyId, DateTime.UtcNow.AddDays(-1), Constants.PriceRoundName, TransactionType.FundingRound,
           Constants.PriceRoundPreMoenyEvaluation, 400000, investmentsPriceRound, new List<OptionPoolCreateRequest> { }, converibles);

            //Get cap table id for Price Round
            var capTableIdForAllTransactions = await GetAsync<IEnumerable<TransactionSummaryListDto>>($"CapTable/GetTransactionsForDropDown/{companyId}");
            var capTableId = capTableIdForAllTransactions.FirstOrDefault().CapTableId;

            //Get and Assert Cap table values from Home page after PriceRound          
            var getStartupHomePageDetailsAfterPriceRound = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetailsAfterPriceRound, (decimal)149999.27, (decimal)149999.27, 5);

            //Get and Assert Cap table after PriceRound       
            var getCapTableValuesAfterPriceRound = await GetAsync<CapTableResponse>($"CapTable/GetTransactionDetailsByCaptableId/{companyId}/{capTableId}");
            CapTableConvertibleAssertions.GetAndAssertCapTableForPriceRoundWithConvertedConvertible(getCapTableValuesAfterPriceRound);
        }

        [TestMethod]
        [TestCategory("InstitutionAdmin")]
        public async Task Test3_CreatePriceRoundWithConvertedConvertible_ShouldSucceed_WhneLoginAsInstitutionAdmin()
        {
            await GetTokenByRole(Role.InstitutionAdmin);
            //create company
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //create 4 founders and 1 investor
            var firstFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                            Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var secondFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, "Marinel", "Rus", Constants.PhoneNumber,
                Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var thirdFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, "Denis", "Muresan", Constants.PhoneNumber,
                Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var forthFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, "Mihai", "Nesu", Constants.PhoneNumber,
                Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var firstInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                UserCreationType.NoOnBoarding, "Cosmin", "Prunean", Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 21), ReasonPhraseType.Created);

            // create ordinary share class
            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            //Create incorporation transaction
            var investments = TransactionsHelper.CreateIncorporationWithFourStakeholder(DateTime.UtcNow.AddDays(-3), 1, InvestmentType.StandardShareIssuance,
               shareClassId, 1, firstFounderId, DateTime.UtcNow.AddDays(-3), 1, InvestmentType.StandardShareIssuance, shareClassId, 1, secondFounderId,
               DateTime.UtcNow.AddDays(-3), 1, InvestmentType.StandardShareIssuance, shareClassId, 1, thirdFounderId, DateTime.UtcNow.AddDays(-3), 1,
               InvestmentType.StandardShareIssuance, shareClassId, 1, forthFounderId);

            await TransactionsHelper.CreateIncorporation(token, companyId, Constants.CloseDate, Constants.IncorporationName, TransactionType.Incorporation,
                Constants.PricePerShare, investments, new List<OptionPoolCreateRequest> { });

            //Get and assert nominal value per share
            await TransactionsAssertions.GetAndAssertNominalValuePerShare(token, companyId, "1.000000000000000");

            //Get and Assert Cap table values from Home page after incorporation
            var getStartupHomePageDetails = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetails, Constants.HomePageTotalInvested, Constants.HomePageLatestTransaction, 4);

            //Get and Assert Cap table after incorporation            
            var getCapTableValues = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableOptionPoolAssertions.GetAndAssertCapTableAfterAnIncorporationForMultipleTransactions(getCapTableValues);

            //create a convertible transaction
            var investmentsConvertible = TransactionsHelper.CreateInvestmentForConvertibleWithOneStakeholder(firstInvestorId, 100000);
            var convertibleBasis = TransactionsHelper.CreateConversionBasis();

            await TransactionsHelper.CreateConvertible(token, companyId, 0, 500000, false, 20, DateTime.UtcNow.AddDays(-3), DateTime.UtcNow.AddDays(-1), "SAFE 1",
                false, investmentsConvertible, new List<ConvertibleClauseType> { }, convertibleBasis);

            //get Convertible Id
            var getAllTransaction = await GetAsync<IEnumerable<TransactionDto>>($"CapTable/GetAllTransactions/{companyId}");
            var convertible = getAllTransaction.Where(x => x.TransactionType == TransactionType.ConvertibleLoan).First().ConvertibleLoans.First();

            //Get and Assert Cap table values from Home page after convertible
            var getStartupHomePageDetailsAfterConvertible = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetailsAfterConvertible, 100000, 100000, 5);

            //Get and Assert Cap table after convertible          
            var getCapTableValuesAfterConvetible = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableConvertibleAssertions.GetAndAssertCapTableAfterAnIncorporationAndConvertible(getCapTableValuesAfterConvetible);

            //create a price round with 1 investor and converted converible included
            var investmentsPriceRound = TransactionsHelper.CreateInvestmentForTransactionsWithOneStakeholder(DateTime.UtcNow.AddDays(-3), 50000, 50000, InvestmentType.StandardShareIssuance,
                 shareClassId, 40000, firstInvestorId);

            var investmentsForConvertible = TransactionsHelper.ConvertibleInvestments(convertible.ConvertibleInvestments.First().Id, 109999, (decimal)99999.27, shareClassId, 0, (decimal)0.90909256, false);

            var converibles = TransactionsHelper.CreateConvertiblesForPriceRound(convertible.Id, 500000, 0,
                    new List<ConversionBaseType> { ConversionBaseType.IssuedShareCapital, ConversionBaseType.NewInvestorShares, ConversionBaseType.ConversionShares, ConversionBaseType.ESOPIncrease },
                    new List<ConvertibleClauseType> { }, investmentsForConvertible);

            await TransactionsHelper.CreatePriceRoundWithInvestmnetConvertibleAndOptionPool(token, companyId, DateTime.UtcNow.AddDays(-1), Constants.PriceRoundName, TransactionType.FundingRound,
           Constants.PriceRoundPreMoenyEvaluation, 400000, investmentsPriceRound, new List<OptionPoolCreateRequest> { }, converibles);

            //Get cap table id for Price Round
            var capTableIdForAllTransactions = await GetAsync<IEnumerable<TransactionSummaryListDto>>($"CapTable/GetTransactionsForDropDown/{companyId}");
            var capTableId = capTableIdForAllTransactions.FirstOrDefault().CapTableId;

            //Get and Assert Cap table values from Home page after PriceRound          
            var getStartupHomePageDetailsAfterPriceRound = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetailsAfterPriceRound, (decimal)149999.27, (decimal)149999.27, 5);

            //Get and Assert Cap table after PriceRound       
            var getCapTableValuesAfterPriceRound = await GetAsync<CapTableResponse>($"CapTable/GetTransactionDetailsByCaptableId/{companyId}/{capTableId}");
            CapTableConvertibleAssertions.GetAndAssertCapTableForPriceRoundWithConvertedConvertible(getCapTableValuesAfterPriceRound);
        }

        [TestMethod]
        [TestCategory("Founder")]
        public async Task Test4_CreatePriceRoundWithConvertedConvertible_ShouldSucceed_WhneLoginAsFounder()
        {
            //login as platform admin
            await GetTokenByRole(Role.PlatformAdmin);
            //create company
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //create 4 founders and 1 investor
            var firstFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                            Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var secondFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, "Marinel", "Rus", Constants.PhoneNumber,
                Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var thirdFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, "Denis", "Muresan", Constants.PhoneNumber,
                Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var forthFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                            Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.FounderEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var firstInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                UserCreationType.NoOnBoarding, "Cosmin", "Prunean", Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 21), ReasonPhraseType.Created);

            // create ordinary share class
            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
               false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            //login as Founder
            await GetTokenByRole(Role.Founder);

            //Create incorporation transaction
            var investments = TransactionsHelper.CreateIncorporationWithFourStakeholder(DateTime.UtcNow.AddDays(-3), 1, InvestmentType.StandardShareIssuance,
               shareClassId, 1, firstFounderId, DateTime.UtcNow.AddDays(-3), 1, InvestmentType.StandardShareIssuance, shareClassId, 1, secondFounderId,
               DateTime.UtcNow.AddDays(-3), 1, InvestmentType.StandardShareIssuance, shareClassId, 1, thirdFounderId, DateTime.UtcNow.AddDays(-3), 1,
               InvestmentType.StandardShareIssuance, shareClassId, 1, forthFounderId);

            await TransactionsHelper.CreateIncorporation(token, companyId, Constants.CloseDate, Constants.IncorporationName, TransactionType.Incorporation,
                Constants.PricePerShare, investments, new List<OptionPoolCreateRequest> { });

            //Get and assert nominal value per share
            await TransactionsAssertions.GetAndAssertNominalValuePerShare(token, companyId, "1.000000000000000");

            //Get and Assert Cap table values from Home page after incorporation
            var getStartupHomePageDetails = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetails, Constants.HomePageTotalInvested, Constants.HomePageLatestTransaction, 4);

            //Get and Assert Cap table after incorporation            
            var getCapTableValues = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableIncorporationAssertions.GetAndAssertCapTableAfterAnIncorporationForFounder(getCapTableValues);

            //create a convertible transaction
            var investmentsConvertible = TransactionsHelper.CreateInvestmentForConvertibleWithOneStakeholder(firstInvestorId, 100000);
            var convertibleBasis = TransactionsHelper.CreateConversionBasis();

            await TransactionsHelper.CreateConvertible(token, companyId, 0, 500000, false, 20, DateTime.UtcNow.AddDays(-3), DateTime.UtcNow.AddDays(-1), "SAFE 1",
                false, investmentsConvertible, new List<ConvertibleClauseType> { }, convertibleBasis);

            //get Convertible Id
            var getAllTransaction = await GetAsync<IEnumerable<TransactionDto>>($"CapTable/GetAllTransactions/{companyId}");
            var convertible = getAllTransaction.Where(x => x.TransactionType == TransactionType.ConvertibleLoan).First().ConvertibleLoans.First();

            //Get and Assert Cap table values from Home page after convertible
            var getStartupHomePageDetailsAfterConvertible = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetailsAfterConvertible, 100000, 100000, 5);

            //Get and Assert Cap table after convertible          
            var getCapTableValuesAfterConvetible = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableConvertibleAssertions.GetAndAssertCapTableAfterAnIncorporationAndConvertibleForFounder(getCapTableValuesAfterConvetible);

            //create a price round with 1 investor and converted converible included
            var investmentsPriceRound = TransactionsHelper.CreateInvestmentForTransactionsWithOneStakeholder(DateTime.UtcNow.AddDays(-3), 50000, 50000, InvestmentType.StandardShareIssuance,
                 shareClassId, 40000, firstInvestorId);

            var investmentsForConvertible = TransactionsHelper.ConvertibleInvestments(convertible.ConvertibleInvestments.First().Id, 109999, (decimal)99999.27, shareClassId, 0, (decimal)0.90909256, false);

            var converibles = TransactionsHelper.CreateConvertiblesForPriceRound(convertible.Id, 500000, 0,
                    new List<ConversionBaseType> { ConversionBaseType.IssuedShareCapital, ConversionBaseType.NewInvestorShares, ConversionBaseType.ConversionShares, ConversionBaseType.ESOPIncrease },
                    new List<ConvertibleClauseType> { }, investmentsForConvertible);

            await TransactionsHelper.CreatePriceRoundWithInvestmnetConvertibleAndOptionPool(token, companyId, DateTime.UtcNow.AddDays(-1), Constants.PriceRoundName, TransactionType.FundingRound,
           Constants.PriceRoundPreMoenyEvaluation, 400000, investmentsPriceRound, new List<OptionPoolCreateRequest> { }, converibles);

            //Get cap table id for Price Round
            var capTableIdForAllTransactions = await GetAsync<IEnumerable<TransactionSummaryListDto>>($"CapTable/GetTransactionsForDropDown/{companyId}");
            var capTableId = capTableIdForAllTransactions.FirstOrDefault().CapTableId;

            //Get and Assert Cap table values from Home page after PriceRound          
            var getStartupHomePageDetailsAfterPriceRound = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetailsAfterPriceRound, (decimal)149999.27, (decimal)149999.27, 5);

            //Get and Assert Cap table after PriceRound       
            var getCapTableValuesAfterPriceRound = await GetAsync<CapTableResponse>($"CapTable/GetTransactionDetailsByCaptableId/{companyId}/{capTableId}");
            CapTableConvertibleAssertions.GetAndAssertCapTableForPriceRoundWithConvertedConvertibleForFounders(getCapTableValuesAfterPriceRound);
        }

        [TestMethod]
        [TestCategory("Investor")]
        public async Task Test5_CreatePriceRoundWithConvertedConvertible_ShouldSucceed_WhneLoginAsInvestor()
        {
            //login as platform admin
            await GetTokenByRole(Role.PlatformAdmin);
            //create company
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //create 4 founders and 1 investor
            var firstFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                            Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var secondFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, "Marinel", "Rus", Constants.PhoneNumber,
                Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var thirdFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, "Denis", "Muresan", Constants.PhoneNumber,
                Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var forthFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, "Mihai", "Nesu", Constants.PhoneNumber,
                Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var firstInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonInvestorLastName, Constants.PhoneNumber, Constants.AddressLine1,
                            Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.InvestorEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            // create ordinary share class
            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
               false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            //Create incorporation transaction
            var investments = TransactionsHelper.CreateIncorporationWithFourStakeholder(DateTime.UtcNow.AddDays(-3), 1, InvestmentType.StandardShareIssuance,
               shareClassId, 1, firstFounderId, DateTime.UtcNow.AddDays(-3), 1, InvestmentType.StandardShareIssuance, shareClassId, 1, secondFounderId,
               DateTime.UtcNow.AddDays(-3), 1, InvestmentType.StandardShareIssuance, shareClassId, 1, thirdFounderId, DateTime.UtcNow.AddDays(-3), 1,
               InvestmentType.StandardShareIssuance, shareClassId, 1, forthFounderId);

            await TransactionsHelper.CreateIncorporation(token, companyId, Constants.CloseDate, Constants.IncorporationName, TransactionType.Incorporation,
                Constants.PricePerShare, investments, new List<OptionPoolCreateRequest> { });

            //Get and assert nominal value per share
            await TransactionsAssertions.GetAndAssertNominalValuePerShare(token, companyId, "1.000000000000000");

            //create a convertible transaction
            var investmentsConvertible = TransactionsHelper.CreateInvestmentForConvertibleWithOneStakeholder(firstInvestorId, 100000);
            var convertibleBasis = TransactionsHelper.CreateConversionBasis();

            await TransactionsHelper.CreateConvertible(token, companyId, 0, 500000, false, 20, DateTime.UtcNow.AddDays(-3), DateTime.UtcNow.AddDays(-1), "SAFE 1",
                false, investmentsConvertible, new List<ConvertibleClauseType> { }, convertibleBasis);

            //get Convertible Id
            var getAllTransaction = await GetAsync<IEnumerable<TransactionDto>>($"CapTable/GetAllTransactions/{companyId}");
            var convertible = getAllTransaction.Where(x => x.TransactionType == TransactionType.ConvertibleLoan).First().ConvertibleLoans.First();

            //create a price round with 1 investor and converted converible included
            var investmentsPriceRound = TransactionsHelper.CreateInvestmentForTransactionsWithOneStakeholder(DateTime.UtcNow.AddDays(-1), 50000, 50000, InvestmentType.StandardShareIssuance,
                 shareClassId, 40000, firstInvestorId);

            var investmentsForConvertible = TransactionsHelper.ConvertibleInvestments(convertible.ConvertibleInvestments.First().Id, 109999, (decimal)99999.27, shareClassId, 0, (decimal)0.90909256, false);

            var converibles = TransactionsHelper.CreateConvertiblesForPriceRound(convertible.Id, 500000, 0,
                    new List<ConversionBaseType> { ConversionBaseType.IssuedShareCapital, ConversionBaseType.NewInvestorShares, ConversionBaseType.ConversionShares, ConversionBaseType.ESOPIncrease },
                    new List<ConvertibleClauseType> { }, investmentsForConvertible);

            await TransactionsHelper.CreatePriceRoundWithInvestmnetConvertibleAndOptionPool(token, companyId, DateTime.UtcNow.AddDays(-2), Constants.PriceRoundName, TransactionType.FundingRound,
           Constants.PriceRoundPreMoenyEvaluation, 400000, investmentsPriceRound, new List<OptionPoolCreateRequest> { }, converibles);

            await GetTokenByRole(Role.Investor);

            //var getCapTableValuesInvestorReport = await GetAsync<CapTableResponse>($"api/Company/GetAll?Count=true&Orderby=createdDate%20desc");
        }
    }
}