﻿using Contracts.Catalog.CapTable.Transactions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Outpace.Assertions;
using Outpace.Assertions.CapTable;
using Outpace.Helpers;
using Outpace.Models.Enum;
using Outpace.Models.Transaction;
using RestApi.Helpers;
using RestApi.Models.CapTable;
using RestApi.Models.Company;
using RestApi.Models.Enum;
using RestApi.Models.Transaction;

namespace Outpace.APITests.Transaction.Convertible
{
    [TestClass]
    public class IncorporationAndConvertible : BaseTestClass
    {
        [TestMethod]
        [TestCategory("PlatformAdmin")]
        public async Task Test1_CreateConvertibleTransaction_ShouldDisplayeCorrectValuesInCapTable_WhenLoginAsPlatformAdmin()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            //Create company
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //Create person founder
            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            //Create person investor
            var personInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonInvestorLastName, Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            //Create Ordinary shareclass 
            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            //Create incorporation transaction
            var investments = TransactionsHelper.CreateInvestmentForIncorporationWithOneStakeholder(DateTime.UtcNow.AddDays(-3), 1, InvestmentType.StandardShareIssuance,
               shareClassId, 5000000, personFounderId);

            await TransactionsHelper.CreateIncorporation(token, companyId, Constants.CloseDate, Constants.IncorporationName, TransactionType.Incorporation,
                Constants.PricePerShare, investments, new List<OptionPoolCreateRequest> { });

            //Get and Assert Nominal Value per Share
            await TransactionsAssertions.GetAndAssertNominalValuePerShare(token, companyId, "0.000000200000000");

            //Get and Assert Cap table values from Home page after incorporation
            var getStartupHomePageDetails = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetails, Constants.HomePageTotalInvested, Constants.HomePageLatestTransaction, Constants.HomePageStakeholderCount);

            //Get and Assert Cap table after incorporation 
            var getCapTableValues = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableConvertibleAssertions.GetAndAssertCapTableAfterAnIncorporation(getCapTableValues);

            //Get Share Register documents
            var getResponseShareRegister = await GetAsync<ShareRegisterResponce>($"CapTable/GetShareRegisterCompanyId/{companyId}?skip=0&take=10");
            var investmentPersonFounderId = ShareRegisterAssertions.AssertShareRegisterForFounder(getResponseShareRegister, Constants.AddressLine1, "Ordinary Share Class",
                "FounderP Person", 5000000M);

            //Create convertible
            var investmentsConvertible = TransactionsHelper.CreateInvestmentForConvertibleWithOneStakeholder(personInvestorId, 250000);
            var convertibleBasis = TransactionsHelper.CreateConversionBasis();

            await TransactionsHelper.CreateConvertible(token, companyId, 0, 2000000, true, 0, DateTime.UtcNow.AddDays(-1), DateTime.UtcNow.AddDays(-1), "SAFE 1",
                false, investmentsConvertible, new List<ConvertibleClauseType> { }, convertibleBasis);

            //Get and Assert Cap table values from Home page after incorporation and convertible
            getStartupHomePageDetails = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetails, 250000, 250000, 2);

            //Get and Assert Cap table after incorporation and convertible          
            getCapTableValues = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableConvertibleAssertions.GetAndAssertCapTableAfterAnIncorporationAndConvertibleTransaction(getCapTableValues);
        }

        [TestMethod]
        [TestCategory("Lawyer")]
        public async Task Test2_CreateConvertibleTransaction_ShouldDisplayeCorrectValuesInCapTable_WhenLoginAsLawyer()
        {
            await GetTokenByRole(Role.Lawyer);
            //Create company
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //Create person founder
            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            //Create person investor
            var personInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonInvestorLastName, Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            //Create Ordinary shareclass 
            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            //Create incorporation transaction
            var investments = TransactionsHelper.CreateInvestmentForIncorporationWithOneStakeholder(DateTime.UtcNow.AddDays(-3), 1, InvestmentType.StandardShareIssuance,
               shareClassId, 5000000, personFounderId);

            await TransactionsHelper.CreateIncorporation(token, companyId, Constants.CloseDate, Constants.IncorporationName, TransactionType.Incorporation,
                Constants.PricePerShare, investments, new List<OptionPoolCreateRequest> { });

            //Get and Assert Nominal Value per Share
            await TransactionsAssertions.GetAndAssertNominalValuePerShare(token, companyId, "0.000000200000000");

            //Get and Assert Cap table values from Home page after incorporation
            var getStartupHomePageDetails = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetails, Constants.HomePageTotalInvested, Constants.HomePageLatestTransaction, Constants.HomePageStakeholderCount);

            //Get and Assert Cap table after incorporation 
            var getCapTableValues = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableConvertibleAssertions.GetAndAssertCapTableAfterAnIncorporation(getCapTableValues);

            //Get Share Register documents
            var getResponseShareRegister = await GetAsync<ShareRegisterResponce>($"CapTable/GetShareRegisterCompanyId/{companyId}?skip=0&take=10");
            var investmentPersonFounderId = ShareRegisterAssertions.AssertShareRegisterForFounder(getResponseShareRegister, Constants.AddressLine1, "Ordinary Share Class",
                "FounderP Person", 5000000M);

            //Create convertible
            var investmentsConvertible = TransactionsHelper.CreateInvestmentForConvertibleWithOneStakeholder(personInvestorId, 250000);
            var convertibleBasis = TransactionsHelper.CreateConversionBasis();

            await TransactionsHelper.CreateConvertible(token, companyId, 0, 2000000, true, 0, DateTime.UtcNow.AddDays(-1), DateTime.UtcNow.AddDays(-1), "SAFE 1",
                false, investmentsConvertible, new List<ConvertibleClauseType> { }, convertibleBasis);

            //Get and Assert Cap table values from Home page after incorporation and convertible
            getStartupHomePageDetails = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetails, 250000, 250000, 2);

            //Get and Assert Cap table after incorporation and oconvertible           
            getCapTableValues = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableConvertibleAssertions.GetAndAssertCapTableAfterAnIncorporationAndConvertibleTransaction(getCapTableValues);
        }

        [TestMethod]
        [TestCategory("InstitutionAdmin")]
        public async Task Test3_CreateConvertibleTransaction_ShouldDisplayeCorrectValuesInCapTable_WhenLoginAsInstitutionAdmin()
        {
            await GetTokenByRole(Role.InstitutionAdmin);
            //Create company
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //Create person founder
            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            //Create person investor
            var personInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonInvestorLastName, Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            //Create Ordinary shareclass 
            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            //Create incorporation transaction
            var investments = TransactionsHelper.CreateInvestmentForIncorporationWithOneStakeholder(DateTime.UtcNow.AddDays(-3), 1, InvestmentType.StandardShareIssuance,
               shareClassId, 5000000, personFounderId);

            await TransactionsHelper.CreateIncorporation(token, companyId, Constants.CloseDate, Constants.IncorporationName, TransactionType.Incorporation,
                Constants.PricePerShare, investments, new List<OptionPoolCreateRequest> { });

            //Get and Assert Nominal Value per Share
            await TransactionsAssertions.GetAndAssertNominalValuePerShare(token, companyId, "0.000000200000000");

            //Get and Assert Cap table values from Home page after incorporation
            var getStartupHomePageDetails = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetails, Constants.HomePageTotalInvested, Constants.HomePageLatestTransaction, Constants.HomePageStakeholderCount);

            //Get and Assert Cap table after incorporation 
            var getCapTableValues = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableConvertibleAssertions.GetAndAssertCapTableAfterAnIncorporation(getCapTableValues);

            //Get Share Register documents
            var getResponseShareRegister = await GetAsync<ShareRegisterResponce>($"CapTable/GetShareRegisterCompanyId/{companyId}?skip=0&take=10");
            var investmentPersonFounderId = ShareRegisterAssertions.AssertShareRegisterForFounder(getResponseShareRegister, Constants.AddressLine1, "Ordinary Share Class",
                "FounderP Person", 5000000M);

            //Create convertible
            var investmentsConvertible = TransactionsHelper.CreateInvestmentForConvertibleWithOneStakeholder(personInvestorId, 250000);
            var convertibleBasis = TransactionsHelper.CreateConversionBasis();

            await TransactionsHelper.CreateConvertible(token, companyId, 0, 2000000, true, 0, DateTime.UtcNow.AddDays(-1), DateTime.UtcNow.AddDays(-1), "SAFE 1",
                false, investmentsConvertible, new List<ConvertibleClauseType> { }, convertibleBasis);

            //Get and Assert Cap table values from Home page after incorporation and convertible
            getStartupHomePageDetails = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetails, 250000, 250000, 2);

            //Get and Assert Cap table after incorporation and convertible     
            getCapTableValues = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableConvertibleAssertions.GetAndAssertCapTableAfterAnIncorporationAndConvertibleTransaction(getCapTableValues);
        }

        [TestMethod]
        [TestCategory("Founder")]
        public async Task Test4_CreateConvertibleTransaction_ShouldDisplayeCorrectValuesInCapTable_WhenLoginAsFounder()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            //Create company
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //Create person founder
            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                            Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.FounderEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            //Create person investor
            var personInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonInvestorLastName, Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            //Create Ordinary shareclass 
            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            await GetTokenByRole(Role.Founder);

            //Create incorporation transaction
            var investments = TransactionsHelper.CreateInvestmentForIncorporationWithOneStakeholder(DateTime.UtcNow.AddDays(-3), 1, InvestmentType.StandardShareIssuance,
               shareClassId, 5000000, personFounderId);

            await TransactionsHelper.CreateIncorporation(token, companyId, Constants.CloseDate, Constants.IncorporationName, TransactionType.Incorporation,
                Constants.PricePerShare, investments, new List<OptionPoolCreateRequest> { });

            //Get and Assert Nominal Value per Share
            await TransactionsAssertions.GetAndAssertNominalValuePerShare(token, companyId, "0.000000200000000");

            //Get and Assert Cap table values from Home page after incorporation
            var getStartupHomePageDetails = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetails, Constants.HomePageTotalInvested, Constants.HomePageLatestTransaction, Constants.HomePageStakeholderCount);

            //Get and Assert Cap table after incorporation 
            var getCapTableValues = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableIncorporationAssertions.GetAndAssertCapTableAfterAnIncorporation(getCapTableValues);

            //Get Share Register documents
            var getResponseShareRegister = await GetAsync<ShareRegisterResponce>($"CapTable/GetShareRegisterCompanyId/{companyId}?skip=0&take=10");
            var investmentPersonFounderId = ShareRegisterAssertions.AssertShareRegisterForFounder(getResponseShareRegister, "", "Ordinary Share Class",
                "PersonFaunder Automatio", 5000000M);

            //Create convertible
            var investmentsConvertible = TransactionsHelper.CreateInvestmentForConvertibleWithOneStakeholder(personInvestorId, 250000);
            var convertibleBasis = TransactionsHelper.CreateConversionBasis();

            await TransactionsHelper.CreateConvertible(token, companyId, 0, 2000000, true, 0, DateTime.UtcNow.AddDays(-1), DateTime.UtcNow.AddDays(-1), "SAFE 1",
                false, investmentsConvertible, new List<ConvertibleClauseType> { }, convertibleBasis);

            //Get and Assert Cap table values from Home page after incorporation and convertible
            getStartupHomePageDetails = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetails, 250000, 250000, 2);

            //Get and Assert Cap table after incorporation and convertible           
            getCapTableValues = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableConvertibleAssertions.GetAndAssertCapTableAfterAnIncorporationAndConvertibleTransactionForFounder(getCapTableValues);
        }

        [TestMethod]
        [TestCategory("Investor")]
        public async Task Test5_CreateConvertibleTransaction_ShouldDisplayeCorrectValuesInCapTable_WhenLoginAsInvestor()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            //Create company
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //Create person founder
            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                            Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.FounderEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            //Create person investor
            var personInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonInvestorLastName, Constants.PhoneNumber, Constants.AddressLine1,
                            Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.InvestorEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            //Create Ordinary shareclass 
            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            //Create incorporation transaction
            var investments = TransactionsHelper.CreateInvestmentForIncorporationWithOneStakeholder(DateTime.UtcNow.AddDays(-3), 1, InvestmentType.StandardShareIssuance,
               shareClassId, 5000000, personFounderId);

            await TransactionsHelper.CreateIncorporation(token, companyId, Constants.CloseDate, Constants.IncorporationName, TransactionType.Incorporation,
                Constants.PricePerShare, investments, new List<OptionPoolCreateRequest> { });

            //Get and Assert Nominal Value per Share
            await TransactionsAssertions.GetAndAssertNominalValuePerShare(token, companyId, "0.000000200000000");

            //Create convertible
            var investmentsConvertible = TransactionsHelper.CreateInvestmentForConvertibleWithOneStakeholder(personInvestorId, 250000);
            var convertibleBasis = TransactionsHelper.CreateConversionBasis();

            await TransactionsHelper.CreateConvertible(token, companyId, 0, 2000000, true, 0, DateTime.UtcNow.AddDays(-1), DateTime.UtcNow.AddDays(-1), "SAFE 1",
                false, investmentsConvertible, new List<ConvertibleClauseType> { }, convertibleBasis);

            await GetTokenByRole(Role.Investor);
            //var getCapTableValuesInvestorReport = await GetAsync<CapTableResponse>($"api/Company/GetAllInvestorStartupDetails?Count=true&Orderby=createdDate%20desc");
        }
    }
}