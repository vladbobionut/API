﻿using FluentAssertions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Outpace.Assertions;
using Outpace.Helpers;
using Outpace.Models.Enum;
using Outpace.Models.Transaction;
using RestApi.FrameworkConfiguration;
using RestApi.Helpers;
using RestApi.Interfaces;
using RestApi.Models.Company;
using RestApi.Models.Enum;
using RestApi.Models.Transaction;

namespace Outpace.APITests.Transaction.Convertible
{
    [TestClass]
    public class CreateConvertible : BaseTestClass
    {
        [TestMethod]
        [TestCategory("PlatformAdmin")]
        public async Task Test1_CreateConvertibleTransaction_ShouldSucceed_WhenLoginAsPlatformAdmin()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            //Arrange
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            //Act
            var investmentsConvertible = TransactionsHelper.CreateInvestmentForConvertibleWithOneStakeholder(personFounderId, 250000);
            var convertibleBasis = TransactionsHelper.CreateConversionBasis();

            await TransactionsHelper.CreateConvertible(token, companyId, 0, 2000000, true, 0, DateTime.UtcNow.AddDays(-1), DateTime.UtcNow.AddDays(-1), "SAFE 1",
                false, investmentsConvertible, new List<ConvertibleClauseType> { }, convertibleBasis);

            //Assert
            var getConvertible = await GetAsync<IEnumerable<TransactionDto>>($"CapTable/GetAllTransactions/{companyId}");
            await TransactionsAssertions.AssertConvertible(getConvertible, 0.00M, 2000000.00M, "FounderP Person");
        }

        [TestMethod]
        [TestCategory("Lawyer")]
        public async Task Test2_CreateConvertibleTransaction_ShouldSucceed_WhenLoginAsLawyer()
        {
            await GetTokenByRole(Role.Lawyer);
            //Arrange
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            //Act
            var investmentsConvertible = TransactionsHelper.CreateInvestmentForConvertibleWithOneStakeholder(personFounderId, 250000);
            var convertibleBasis = TransactionsHelper.CreateConversionBasis();

            await TransactionsHelper.CreateConvertible(token, companyId, 0, 2000000, true, 0, DateTime.UtcNow.AddDays(-1), DateTime.UtcNow.AddDays(-1), "SAFE 1",
                false, investmentsConvertible, new List<ConvertibleClauseType> { }, convertibleBasis);

            //Assert
            var getConvertible = await GetAsync<IEnumerable<TransactionDto>>($"CapTable/GetAllTransactions/{companyId}");
            await TransactionsAssertions.AssertConvertible(getConvertible, 0.00M, 2000000.00M, "FounderP Person");
        }

        [TestMethod]
        [TestCategory("InstitutionAdmin")]
        public async Task Test3_CreateConvertibleTransaction_ShouldSucceed_WhenLoginAsInstitutionAdmin()
        {
            await GetTokenByRole(Role.InstitutionAdmin);
            //Arrange
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            //Act
            var investmentsConvertible = TransactionsHelper.CreateInvestmentForConvertibleWithOneStakeholder(personFounderId, 250000);
            var convertibleBasis = TransactionsHelper.CreateConversionBasis();

            await TransactionsHelper.CreateConvertible(token, companyId, 0, 2000000, true, 0, DateTime.UtcNow.AddDays(-1), DateTime.UtcNow.AddDays(-1), "SAFE 1",
                false, investmentsConvertible, new List<ConvertibleClauseType> { }, convertibleBasis);

            //Assert
            var getConvertible = await GetAsync<IEnumerable<TransactionDto>>($"CapTable/GetAllTransactions/{companyId}");
            await TransactionsAssertions.AssertConvertible(getConvertible, 0.00M, 2000000.00M, "FounderP Person");
        }

        [TestMethod]
        [TestCategory("Founder")]
        public async Task Test4_CreateConvertibleTransaction_ShouldSucceed_WhenLoginAsFounder()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            //Arrange
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                  UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                  Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.FounderEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            //Act
            await GetTokenByRole(Role.Founder);
            var investmentsConvertible = TransactionsHelper.CreateInvestmentForConvertibleWithOneStakeholder(personFounderId, 250000);
            var convertibleBasis = TransactionsHelper.CreateConversionBasis();

            await TransactionsHelper.CreateConvertible(token, companyId, 0, 2000000, true, 0, DateTime.UtcNow.AddDays(-1), DateTime.UtcNow.AddDays(-1), "SAFE 1",
                false, investmentsConvertible, new List<ConvertibleClauseType> { }, convertibleBasis);

            //Assert
            var getConvertible = await GetAsync<IEnumerable<TransactionDto>>($"CapTable/GetAllTransactions/{companyId}");
            await TransactionsAssertions.AssertConvertible(getConvertible, 0.00M, 2000000.00M, "PersonFaunder Automatio");
        }

        [TestMethod]
        [TestCategory("Investor")]
        public async Task Test5_CreateConvertibleTransaction_ShouldForbidden_WhenLoginAsInvestor()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            //Arrange
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var personInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonInvestorLastName, Constants.PhoneNumber, Constants.AddressLine1,
                            Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.InvestorEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            await GetTokenByRole(Role.Investor);

            var investments = new List<ConvertibleInvestment>();
            investments.Add(new ConvertibleInvestment()
            {
                UserId = personInvestorId,
                AmountCommitted = 250000,
            });

            var convertibleCreateRequest = new CreateConvertibleLoanRequest()
            {

                CompanyId = companyId,
                AnnualInterestPercentage = 0,
                Cap = 2000000,
                Completed = true,
                Discount = 0,
                IssueDate = DateTime.UtcNow.AddDays(-1),
                MaturityDate = DateTime.UtcNow.AddDays(-1),
                Name = "SAFE 1",
                PayBackAtConversion = false,
                ConvertibleInvestments = investments,
                ConvertibleClauses = new List<ConvertibleClauseType> { },
                ConversionBasis = TransactionsHelper.CreateConversionBasis()
            };
            //Act
            var convertible = await DI.Container.GetService<IRestClient>().Post(convertibleCreateRequest, "CapTable/CreateConvertibleLoan", token);

            //Assert
            convertible.ReasonPhrase.Should().Be("Forbidden");
        }
    }
}