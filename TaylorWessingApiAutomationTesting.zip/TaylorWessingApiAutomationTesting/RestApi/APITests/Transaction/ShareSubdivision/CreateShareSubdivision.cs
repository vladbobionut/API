﻿using FluentAssertions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Outpace.Assertions;
using Outpace.Helpers;
using Outpace.Models.Enum;
using RestApi.FrameworkConfiguration;
using RestApi.Helpers;
using RestApi.Interfaces;
using RestApi.Models.Company;
using RestApi.Models.Enum;
using RestApi.Models.Transaction;

namespace Outpace.APITests.Transaction.ShareSubdivision
{
    [TestClass]
    public class CreateShareSubdivision :BaseTestClass
    {
        [TestMethod]
        [TestCategory("PlatformAdmin")]
        public async Task Test1_CreateShareSubdivision_ShouldSucceed_WhneLoginAsPlatformAdmin()
        {
            //Arrange
            await GetTokenByRole(Role.PlatformAdmin);

            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //Act
            await TransactionsHelper.CreateShareSubdivision(token, companyId, Constants.DateNow, Constants.SplitFactor);

            //Assert
            var getSubDivision = await GetAsync<IEnumerable<TransactionDto>>($"CapTable/GetAllTransactions/{companyId}");
            TransactionsAssertions.AssertSubDivision(getSubDivision, companyId);
        }

        [TestMethod]
        [TestCategory("Lawyer")]
        public async Task Test2_CreateShareSubdivision_ShouldSucceed_WhneLoginAsLawyer()
        {
            //Arrange
            await GetTokenByRole(Role.Lawyer);

            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //Act
            await TransactionsHelper.CreateShareSubdivision(token, companyId, Constants.DateNow, Constants.SplitFactor);

            //Assert
            var getSubDivision = await GetAsync<IEnumerable<TransactionDto>>($"CapTable/GetAllTransactions/{companyId}");
            TransactionsAssertions.AssertSubDivision(getSubDivision, companyId);
        }

        [TestMethod]
        [TestCategory("InstitutionAdmin")]
        public async Task Test3_CreateShareSubdivision_ShouldSucceed_WhneLoginAsInstitutionAdmin()
        {
            //Arrange
            await GetTokenByRole(Role.InstitutionAdmin);

            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //Act
            await TransactionsHelper.CreateShareSubdivision(token, companyId, Constants.DateNow, Constants.SplitFactor);

            //Assert
            var getSubDivision = await GetAsync<IEnumerable<TransactionDto>>($"CapTable/GetAllTransactions/{companyId}");
            TransactionsAssertions.AssertSubDivision(getSubDivision, companyId);
        }

        [TestMethod]
        [TestCategory("Founder")]
        public async Task Test4_CreateShareSubdivision_ShouldSucceed_WhneLoginAsFounder()
        {
            //Arrange
            await GetTokenByRole(Role.PlatformAdmin);

            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.FounderEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            //Act
            await GetTokenByRole(Role.Founder);
            await TransactionsHelper.CreateShareSubdivision(token, companyId, Constants.DateNow, Constants.SplitFactor);

            //Assert
            var getSubDivision = await GetAsync<IEnumerable<TransactionDto>>($"CapTable/GetAllTransactions/{companyId}");
            TransactionsAssertions.AssertSubDivision(getSubDivision, companyId);
        }

        [TestMethod]
        [TestCategory("Investor")]
        public async Task Test5_CreateShareSubdivision_ShouldFailWithForbidden_WhneLoginAsInvestor()
        {
            //Arrange
            await GetTokenByRole(Role.PlatformAdmin);

            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var personInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonInvestorLastName, Constants.PhoneNumber, Constants.AddressLine1,
                            Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.InvestorEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            //Act
            await GetTokenByRole(Role.Investor);
            var modelShareSubDivision = new ShareSubDivision()
            {
                CompanyId = companyId,
                Date = Constants.DateNow,
                SplitFactor = Constants.SplitFactor
            };
            var shareSubdivision = await DI.Container.GetService<IRestClient>().Post(modelShareSubDivision, "CapTable/CreateShareSubDivision", token);

            //Assert
            shareSubdivision.ReasonPhrase.Should().Be("Forbidden");
        }
    }
}