﻿using Contracts.Catalog.CapTable.Transactions;
using FluentAssertions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Outpace.Assertions;
using Outpace.Assertions.CapTable;
using Outpace.Helpers;
using Outpace.Models.Enum;
using RestApi.FrameworkConfiguration;
using RestApi.Helpers;
using RestApi.Interfaces;
using RestApi.Models.Company;
using RestApi.Models.Enum;
using RestApi.Models.Transaction;

namespace Outpace.APITests.Transaction.ShareSubdivision
{
    [TestClass]
    public class IncorporationAndShareSubdivisionAndShareTransfer : BaseTestClass
    {
        [TestMethod]
        [TestCategory("PlatformAdmin")]
        public async Task Test1_CreateIncorporationSubDivisionAndShareTransferTransactions_ShouldDisplayeCorrectValuesInCapTable_WhenLoginAsPlatformAdmin()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            //Create company
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //Create person founder
            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            //Create Ordinary shareclass 
            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            //Create incorporation transaction
            var investments = TransactionsHelper.CreateInvestmentForIncorporationWithOneStakeholder(DateTime.UtcNow.AddDays(-3), 0, InvestmentType.StandardShareIssuance,
               shareClassId, 1, personFounderId);

            await TransactionsHelper.CreateIncorporation(token, companyId, Constants.CloseDate, Constants.IncorporationName, TransactionType.Incorporation,
                1, investments, new List<OptionPoolCreateRequest> { });

            //Get and Assert Cap table values from Home page after incorporation
            var getStartupHomePageDetails = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetails, Constants.HomePageTotalInvested, Constants.HomePageLatestTransaction,
                Constants.HomePageStakeholderCount);

            //Get and Assert Cap table after incorporation            
            var getCapTableValues = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableSubDivisionAssertions.GetAndAssertCapTableAfterAnIncorporationTransaction(getCapTableValues);

            //Create second founder
            var secondFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                        UserCreationType.NoOnBoarding, "Marinel", "Rus", Constants.PhoneNumber,
                        Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            //Create a share subdivision transaction
            await TransactionsHelper.CreateShareSubdivision(token, companyId, DateTime.UtcNow.AddDays(-2), 100);

            //Get and Assert Cap table values from Home page after incorporation
            var getStartupHomePageDetailsAfterSubdivision = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetailsAfterSubdivision, Constants.HomePageTotalInvested, Constants.HomePageLatestTransaction,
                Constants.HomePageStakeholderCount);

            //Get and Assert Cap table after SubDivison Transaction           
            var getCapTableValuesAfterSubDivision = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableSubDivisionAssertions.GetAndAssertCapTableAfterSubDivisionTransaction(getCapTableValuesAfterSubDivision);

            //Create a Share Transfer
            await TransactionsHelper.CreateShareTransfer(token, companyId, DateTime.UtcNow.AddDays(-1), Constants.EventName,
                  50, secondFounderId, shareClassId, personFounderId);

            //Get and Assert Cap table values from Home page after Share Transfer
            var getStartupHomePageDetailsAfterShareTransfer = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetailsAfterShareTransfer, Constants.HomePageTotalInvested, Constants.HomePageLatestTransaction,
                2);

            //Get and Assert Cap table after Share Transfer          
            var getCapTableValuesAfterShareTransfer = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableShareTransferAssertions.GetAndAssertCapTableAfterShareTransfer(getCapTableValuesAfterShareTransfer);

            //Create second share subdivision transaction
            await TransactionsHelper.CreateShareSubdivision(token, companyId, DateTime.UtcNow, 10000);

            //Get and Assert Cap table values from Home page after Share Transfer
            var getStartupHomePageDetailsAfterSecondShareSubdivision = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetailsAfterSecondShareSubdivision, Constants.HomePageTotalInvested, Constants.HomePageLatestTransaction,
                2);

            //Get and Assert Cap table after second SubDivison Transaction           
            var getCapTableValuesAfterSecondSubDivision = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableSubDivisionAssertions.GetAndAssertCapTableAfterSecondSubDivisionTransaction(getCapTableValuesAfterSecondSubDivision);
        }

        [TestMethod]
        [TestCategory("Lawyer")]
        public async Task Test2_CreateIncorporationSubDivisionAndShareTransferTransactions_ShouldDisplayeCorrectValuesInCapTable_WhenLoginAsLawyer()
        {
            await GetTokenByRole(Role.Lawyer);
            //Create company
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //Create person founder
            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            //Create Ordinary shareclass 
            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            //Create incorporation transaction
            var investments = TransactionsHelper.CreateInvestmentForIncorporationWithOneStakeholder(DateTime.UtcNow.AddDays(-3), 0, InvestmentType.StandardShareIssuance,
               shareClassId, 1, personFounderId);

            await TransactionsHelper.CreateIncorporation(token, companyId, Constants.CloseDate, Constants.IncorporationName, TransactionType.Incorporation,
                1, investments, new List<OptionPoolCreateRequest> { });

            //Get and Assert Cap table values from Home page after incorporation
            var getStartupHomePageDetails = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetails, Constants.HomePageTotalInvested, Constants.HomePageLatestTransaction,
                Constants.HomePageStakeholderCount);

            //Get and Assert Cap table after incorporation            
            var getCapTableValues = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableSubDivisionAssertions.GetAndAssertCapTableAfterAnIncorporationTransaction(getCapTableValues);

            //Create second founder
            var secondFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                        UserCreationType.NoOnBoarding, "Marinel", "Rus", Constants.PhoneNumber,
                        Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            //Create a share subdivision transaction
            await TransactionsHelper.CreateShareSubdivision(token, companyId, DateTime.UtcNow.AddDays(-2), 100);

            //Get and Assert Cap table values from Home page after incorporation
            var getStartupHomePageDetailsAfterSubdivision = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetailsAfterSubdivision, Constants.HomePageTotalInvested, Constants.HomePageLatestTransaction,
                Constants.HomePageStakeholderCount);

            //Get and Assert Cap table after SubDivison Transaction           
            var getCapTableValuesAfterSubDivision = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableSubDivisionAssertions.GetAndAssertCapTableAfterSubDivisionTransaction(getCapTableValuesAfterSubDivision);

            //Create a Share Transfer
            await TransactionsHelper.CreateShareTransfer(token, companyId, DateTime.UtcNow.AddDays(-1), Constants.EventName,
                  50, secondFounderId, shareClassId, personFounderId);

            //Get and Assert Cap table values from Home page after Share Transfer
            var getStartupHomePageDetailsAfterShareTransfer = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetailsAfterShareTransfer, Constants.HomePageTotalInvested, Constants.HomePageLatestTransaction,
                2);

            //Get and Assert Cap table after Share Transfer          
            var getCapTableValuesAfterShareTransfer = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableShareTransferAssertions.GetAndAssertCapTableAfterShareTransfer(getCapTableValuesAfterShareTransfer);

            //Create second share subdivision transaction
            await TransactionsHelper.CreateShareSubdivision(token, companyId, DateTime.UtcNow, 10000);

            //Get and Assert Cap table values from Home page after Share Transfer
            var getStartupHomePageDetailsAfterSecondShareSubdivision = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetailsAfterSecondShareSubdivision, Constants.HomePageTotalInvested, Constants.HomePageLatestTransaction,
                2);

            //Get and Assert Cap table after second SubDivison Transaction           
            var getCapTableValuesAfterSecondSubDivision = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableSubDivisionAssertions.GetAndAssertCapTableAfterSecondSubDivisionTransaction(getCapTableValuesAfterSecondSubDivision);
        }

        [TestMethod]
        [TestCategory("InstitutionAdmin")]
        public async Task Test3_CreateIncorporationSubDivisionAndShareTransferTransactions_ShouldDisplayeCorrectValuesInCapTable_WhenLoginAsInstitutionAdmin()
        {
            await GetTokenByRole(Role.InstitutionAdmin);
            //Create company
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //Create person founder
            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            //Create Ordinary shareclass 
            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            //Create incorporation transaction
            var investments = TransactionsHelper.CreateInvestmentForIncorporationWithOneStakeholder(DateTime.UtcNow.AddDays(-3), 0, InvestmentType.StandardShareIssuance,
               shareClassId, 1, personFounderId);

            await TransactionsHelper.CreateIncorporation(token, companyId, Constants.CloseDate, Constants.IncorporationName, TransactionType.Incorporation,
                1, investments, new List<OptionPoolCreateRequest> { });

            //Get and Assert Cap table values from Home page after incorporation
            var getStartupHomePageDetails = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetails, Constants.HomePageTotalInvested, Constants.HomePageLatestTransaction,
                Constants.HomePageStakeholderCount);

            //Get and Assert Cap table after incorporation            
            var getCapTableValues = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableSubDivisionAssertions.GetAndAssertCapTableAfterAnIncorporationTransaction(getCapTableValues);

            //Create second founder
            var secondFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                        UserCreationType.NoOnBoarding, "Marinel", "Rus", Constants.PhoneNumber,
                        Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            //Create a share subdivision transaction
            await TransactionsHelper.CreateShareSubdivision(token, companyId, DateTime.UtcNow.AddDays(-2), 100);

            //Get and Assert Cap table values from Home page after incorporation
            var getStartupHomePageDetailsAfterSubdivision = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetailsAfterSubdivision, Constants.HomePageTotalInvested, Constants.HomePageLatestTransaction,
                Constants.HomePageStakeholderCount);

            //Get and Assert Cap table after SubDivison Transaction           
            var getCapTableValuesAfterSubDivision = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableSubDivisionAssertions.GetAndAssertCapTableAfterSubDivisionTransaction(getCapTableValuesAfterSubDivision);

            //Create a Share Transfer
            await TransactionsHelper.CreateShareTransfer(token, companyId, DateTime.UtcNow.AddDays(-1), Constants.EventName,
                  50, secondFounderId, shareClassId, personFounderId);

            //Get and Assert Cap table values from Home page after Share Transfer
            var getStartupHomePageDetailsAfterShareTransfer = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetailsAfterShareTransfer, Constants.HomePageTotalInvested, Constants.HomePageLatestTransaction,
                2);

            //Get and Assert Cap table after Share Transfer          
            var getCapTableValuesAfterShareTransfer = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableShareTransferAssertions.GetAndAssertCapTableAfterShareTransfer(getCapTableValuesAfterShareTransfer);

            //Create second share subdivision transaction
            await TransactionsHelper.CreateShareSubdivision(token, companyId, DateTime.UtcNow, 10000);

            //Get and Assert Cap table values from Home page after Share Transfer
            var getStartupHomePageDetailsAfterSecondShareSubdivision = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetailsAfterSecondShareSubdivision, Constants.HomePageTotalInvested, Constants.HomePageLatestTransaction,
                2);

            //Get and Assert Cap table after second SubDivison Transaction           
            var getCapTableValuesAfterSecondSubDivision = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableSubDivisionAssertions.GetAndAssertCapTableAfterSecondSubDivisionTransaction(getCapTableValuesAfterSecondSubDivision);
        }

        [TestMethod]
        [TestCategory("Founder")]
        public async Task Test4_CreateIncorporationSubDivisionAndShareTransferTransactions_ShouldDisplayeCorrectValuesInCapTable_WhenLoginAsFounder()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            //Create company
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //Create person founder
            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                              UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                              Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.FounderEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            //Create Ordinary shareclass 
            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            await GetTokenByRole(Role.Founder);
            //Create incorporation transaction
            var investments = TransactionsHelper.CreateInvestmentForIncorporationWithOneStakeholder(DateTime.UtcNow.AddDays(-3), 0, InvestmentType.StandardShareIssuance,
               shareClassId, 1, personFounderId);

            await TransactionsHelper.CreateIncorporation(token, companyId, Constants.CloseDate, Constants.IncorporationName, TransactionType.Incorporation,
                1, investments, new List<OptionPoolCreateRequest> { });

            //Get and Assert Cap table values from Home page after incorporation
            var getStartupHomePageDetails = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetails, Constants.HomePageTotalInvested, Constants.HomePageLatestTransaction,
                Constants.HomePageStakeholderCount);

            //Get and Assert Cap table after incorporation            
            var getCapTableValues = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableSubDivisionAssertions.GetAndAssertCapTableAfterAnIncorporationTransactionForFaunder(getCapTableValues);

            //Create second founder
            var secondFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                        UserCreationType.NoOnBoarding, "Marinel", "Rus", Constants.PhoneNumber,
                        Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            //Create a share subdivision transaction
            await TransactionsHelper.CreateShareSubdivision(token, companyId, DateTime.UtcNow.AddDays(-2), 100);

            //Get and Assert Cap table values from Home page after incorporation
            var getStartupHomePageDetailsAfterSubdivision = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetailsAfterSubdivision, Constants.HomePageTotalInvested, Constants.HomePageLatestTransaction,
                Constants.HomePageStakeholderCount);

            //Get and Assert Cap table after SubDivison Transaction           
            var getCapTableValuesAfterSubDivision = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableSubDivisionAssertions.GetAndAssertCapTableAfterSubDivisionTransactionForFounder(getCapTableValuesAfterSubDivision);

            //Create a Share Transfer
            await TransactionsHelper.CreateShareTransfer(token, companyId, DateTime.UtcNow.AddDays(-1), Constants.EventName,
                  50, secondFounderId, shareClassId, personFounderId);

            //Get and Assert Cap table values from Home page after Share Transfer
            var getStartupHomePageDetailsAfterShareTransfer = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetailsAfterShareTransfer, Constants.HomePageTotalInvested, Constants.HomePageLatestTransaction,
                2);

            //Get and Assert Cap table after Share Transfer          
            var getCapTableValuesAfterShareTransfer = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableShareTransferAssertions.GetAndAssertCapTableAfterShareTransferForFounder(getCapTableValuesAfterShareTransfer);

            //Create second share subdivision transaction
            await TransactionsHelper.CreateShareSubdivision(token, companyId, DateTime.UtcNow, 10000);

            //Get and Assert Cap table values from Home page after Share Transfer
            var getStartupHomePageDetailsAfterSecondShareSubdivision = await GetAsync<StartupHomePageDetails>($"/api/Company/GetStartupHomePageDetails/{companyId}");
            HomePageAssertions.GetAndAssertCapTableFromHomePage(getStartupHomePageDetailsAfterSecondShareSubdivision, Constants.HomePageTotalInvested, Constants.HomePageLatestTransaction,
                2);

            //Get and Assert Cap table after second SubDivison Transaction           
            var getCapTableValuesAfterSecondSubDivision = await GetAsync<CapTableResponse>($"CapTable/GetCurrentCapTable/{companyId}");
            CapTableSubDivisionAssertions.GetAndAssertCapTableAfterSecondSubDivisionTransactionForFounder(getCapTableValuesAfterSecondSubDivision);
        }

        [TestMethod]
        [TestCategory("Investor")]
        public async Task Test5_CreateIncorporationSubDivisionAndShareTransferTransactions_ShouldDisplayeForbiddene_WhenLoginAsInvestor()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            //Create company
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //Create person founder
            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                              UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                              Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.FounderEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var personInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                               UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonInvestorLastName, Constants.PhoneNumber, Constants.AddressLine1,
                               Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.InvestorEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            //Create Ordinary shareclass 
            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            //Create incorporation transaction
            var investments = TransactionsHelper.CreateInvestmentForIncorporationWithOneStakeholder(DateTime.UtcNow.AddDays(-3), 0, InvestmentType.StandardShareIssuance,
               shareClassId, 1, personFounderId);

            await TransactionsHelper.CreateIncorporation(token, companyId, Constants.CloseDate, Constants.IncorporationName, TransactionType.Incorporation,
                1, investments, new List<OptionPoolCreateRequest> { });

            //Create second founder
            var secondFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                        UserCreationType.NoOnBoarding, "Marinel", "Rus", Constants.PhoneNumber,
                        Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, FakeEmailAddress.GetFakeEmailAddress(), new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            //Create a share subdivision transaction
            await TransactionsHelper.CreateShareSubdivision(token, companyId, DateTime.UtcNow.AddDays(-2), 100);

            //Create a Share Transfer
            await TransactionsHelper.CreateShareTransfer(token, companyId, DateTime.UtcNow.AddDays(-1), Constants.EventName,
                  50, secondFounderId, shareClassId, personFounderId);

            //Create second share subdivision transaction
            await GetTokenByRole(Role.Investor);

            var modelShareSubDivision = new ShareSubDivision()
            {
                CompanyId = companyId,
                Date = DateTime.UtcNow,
                SplitFactor = 10000
            };
            var shareSubdivision = await DI.Container.GetService<IRestClient>().Post(modelShareSubDivision, "CapTable/CreateShareSubDivision", token);
            shareSubdivision.ReasonPhrase.Should().Be("Forbidden");
        }
    }
}