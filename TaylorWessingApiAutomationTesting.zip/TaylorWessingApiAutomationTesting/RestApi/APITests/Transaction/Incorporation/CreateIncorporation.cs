﻿using FluentAssertions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Outpace.Assertions;
using Outpace.Helpers;
using Outpace.Models.Enum;
using RestApi.FrameworkConfiguration;
using RestApi.Helpers;
using RestApi.Interfaces;
using RestApi.Models.Company;
using RestApi.Models.Enum;
using RestApi.Models.Transaction;

namespace Outpace.APITests.Transaction.Incorporation
{
    [TestClass]
    public class CreateIncorporation : BaseTestClass
    {
        [TestMethod]
        [TestCategory("PlatformAdmin")]
        public async Task Test1_CreateIncorporation_ShouldSucceed_WhenLoginAsPlatformAdmin()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            //Arrange
            var email = FakeEmailAddress.GetFakeEmailAddress();

            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                            Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, email, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            //Act
            var investments = TransactionsHelper.CreateInvestmentForIncorporationWithOneStakeholder(DateTime.UtcNow.AddDays(-3), Constants.InvestmentAmount, InvestmentType.StandardShareIssuance,
                shareClassId, Constants.ShareQuantity, personFounderId);

            await TransactionsHelper.CreateIncorporation(token, companyId, Constants.CloseDate, Constants.IncorporationName, TransactionType.Incorporation,
                Constants.PricePerShare, investments, new List<OptionPoolCreateRequest> { });

            //Assert
            var getIncorporation = await GetAsync<IEnumerable<TransactionDto>>($"CapTable/GetAllTransactions/{companyId}");
            TransactionsAssertions.AssertIncorporationTransaction(getIncorporation, companyId, shareClassId);
        }

        [TestMethod]
        [TestCategory("Lawyer")]
        public async Task Test2_CreateIncorporation_ShouldSucceed_WhenLoginAsLawyern()
        {
            await GetTokenByRole(Role.Lawyer);
            //Arrange
            var email = FakeEmailAddress.GetFakeEmailAddress();

            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                            Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, email, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            //Act
            var investments = TransactionsHelper.CreateInvestmentForIncorporationWithOneStakeholder(DateTime.UtcNow.AddDays(-3), Constants.InvestmentAmount, InvestmentType.StandardShareIssuance,
                shareClassId, Constants.ShareQuantity, personFounderId);

            await TransactionsHelper.CreateIncorporation(token, companyId, Constants.CloseDate, Constants.IncorporationName, TransactionType.Incorporation,
                Constants.PricePerShare, investments, new List<OptionPoolCreateRequest> { });

            //Assert
            var getIncorporation = await GetAsync<IEnumerable<TransactionDto>>($"CapTable/GetAllTransactions/{companyId}");
            TransactionsAssertions.AssertIncorporationTransaction(getIncorporation, companyId, shareClassId);
        }

        [TestMethod]
        [TestCategory("InstitutionAdmin")]
        public async Task Test3_CreateIncorporation_ShouldSucceed_WhenLoginAsInstitutionAdmin()
        {
            await GetTokenByRole(Role.InstitutionAdmin);
            //Arrange
            var email = FakeEmailAddress.GetFakeEmailAddress();

            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                            Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, email, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            //Act
            var investments = TransactionsHelper.CreateInvestmentForIncorporationWithOneStakeholder(DateTime.UtcNow.AddDays(-3), Constants.InvestmentAmount, InvestmentType.StandardShareIssuance,
                shareClassId, Constants.ShareQuantity, personFounderId);

            await TransactionsHelper.CreateIncorporation(token, companyId, Constants.CloseDate, Constants.IncorporationName, TransactionType.Incorporation,
                Constants.PricePerShare, investments, new List<OptionPoolCreateRequest> { });

            //Assert
            var getIncorporation = await GetAsync<IEnumerable<TransactionDto>>($"CapTable/GetAllTransactions/{companyId}");
            TransactionsAssertions.AssertIncorporationTransaction(getIncorporation, companyId, shareClassId);
        }

        [TestMethod]
        [TestCategory("Founder")]
        public async Task Test4_CreateIncorporation_ShouldSucceed_WhenLoginAsFounder()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            //Arrange
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                  UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                  Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.FounderEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            //Act
            await GetTokenByRole(Role.Founder);
            var investments = TransactionsHelper.CreateInvestmentForIncorporationWithOneStakeholder(DateTime.UtcNow.AddDays(-3), Constants.InvestmentAmount, InvestmentType.StandardShareIssuance,
                shareClassId, Constants.ShareQuantity, personFounderId);

            await TransactionsHelper.CreateIncorporation(token, companyId, Constants.CloseDate, Constants.IncorporationName, TransactionType.Incorporation,
                Constants.PricePerShare, investments, new List<OptionPoolCreateRequest> { });

            //Assert
            var getIncorporation = await GetAsync<IEnumerable<TransactionDto>>($"CapTable/GetAllTransactions/{companyId}");
            TransactionsAssertions.AssertIncorporationTransaction(getIncorporation, companyId, shareClassId);
        }

        [TestMethod]
        [TestCategory("Investor")]
        public async Task Test5_CreateIncorporation_ShouldForbidden_WhenLoginAsInvestor()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            //Arrange
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                  UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                  Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.FounderEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var personInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonInvestorLastName, Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.InvestorEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            var shareClassId = await ShareClassHelper.CreateShareClass(token, companyId, false, false, 0, false, false, 0, 0, 0, 0, false,
                false, 0, Constants.ShareClassName, 1, AntiDilutionType.WeightedAverageBroad, ReasonPhraseType.OK);

            //Act;
            await GetTokenByRole(Role.Investor);
            var investments = new List<InvestmentCreateRequest>();
            investments.Add(new InvestmentCreateRequest()
            {
                ClosedDate = DateTime.UtcNow.AddDays(-3),
                InvestmentAmount = Constants.InvestmentAmount,
                InvestmentType = InvestmentType.StandardShareIssuance,
                ShareClassId = shareClassId,
                ShareQuantity = Constants.ShareQuantity,
                UserId = personFounderId
            });

            var incorporationCreateRequest = new TransactionRequest()
            {

                CompanyId = companyId,
                ClosedDate = Constants.CloseDate,
                Name = Constants.IncorporationName,
                TransactionType = TransactionType.Incorporation,
                PricePerShare = Constants.PricePerShare,
                Investments = investments,
                OptionPools = new List<OptionPoolCreateRequest> { }
            };

            var incorporation = await DI.Container.GetService<IRestClient>().Post(incorporationCreateRequest, "CapTable/CreateTransaction", token);
            incorporation.ReasonPhrase.Should().Be("Forbidden");
        }
    }
}