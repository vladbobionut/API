﻿using FluentAssertions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Outpace.APITests;
using Outpace.Models.Enum;
using RestApi.FrameworkConfiguration;
using RestApi.Interfaces;
using RestApi.Models;
using RestApi.Models.Company;
using RestApi.Models.Enum;
using System.Net;
using System.Text.Json;

namespace RestApi.APITests.Company.NegativeFlows
{
    [TestClass]
    public class AddCompanyNegativeFlows : BaseTestClass
    {

        [TestMethod]
        [TestCategory("P1")]
        public async Task CreateStartupCompany_ShouldReturnErrorMessage_When_UsingEmptyStrings()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            //Arange
            var model = new CompanyCreateRequest()
            {
                Currency = string.Empty,
                City = string.Empty,
                Postcode = string.Empty,
                Jurisdiction = Jurisdiction.EnglandAndWales,
                AddressLine1 = string.Empty,
            };

            //Act
            var response = await DI.Container.GetService<IRestClient>().Post(model, "company/create", token);

            //Assert
            response.StatusCode.Should().Be(HttpStatusCode.BadRequest);
            string validationErrorMessage = await response.Content.ReadAsStringAsync();
            ErrorDetails errorDetails = JsonSerializer.Deserialize<ErrorDetails>(validationErrorMessage, new JsonSerializerOptions() { PropertyNameCaseInsensitive = true });
            errorDetails.Code.Should().Equals(400);
            errorDetails.Message.Should().Contain("Invalid request");
            errorDetails.Errors.Should().HaveCount(3);
            errorDetails.Errors.Contains("CompanyType is required");
            errorDetails.Errors.Contains("The CompanyName field is required.");
            errorDetails.Errors.Contains("Country is required");
        }

        [TestMethod]
        [TestCategory("P1")]
        public async Task CreateInstitutionCompany_ShouldReturnErrorMessage_When_UsingEmptyStrings()
        {
            //Arange
            await GetTokenByRole(Role.PlatformAdmin);
            var model = new CompanyCreateRequest()
            {
                CompanyType = CompanyType.Institution,
                Currency = string.Empty,
                City = string.Empty,
                Postcode = string.Empty,
                Jurisdiction = Jurisdiction.EnglandAndWales,
                AddressLine1 = string.Empty,
            };

            //Act
            var response = await DI.Container.GetService<IRestClient>().Post(model, "company/create", token);

            //Assert
            response.StatusCode.Should().Be(HttpStatusCode.BadRequest);
            string validationErrorMessage = await response.Content.ReadAsStringAsync();
            ErrorDetails errorDetails = JsonSerializer.Deserialize<ErrorDetails>(validationErrorMessage, new JsonSerializerOptions() { PropertyNameCaseInsensitive = true });
            errorDetails.Code.Should().Equals(400);
            errorDetails.Message.Should().Contain("Invalid request");
            errorDetails.Errors.Should().HaveCount(2);
            errorDetails.Errors.Contains("The CompanyName field is required.");
            errorDetails.Errors.Contains("Country is required");
        }
    }
}