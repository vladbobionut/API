﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Outpace.Assertions;
using Outpace.Models.Enum;
using RestApi.FrameworkConfiguration;
using RestApi.Helpers;
using RestApi.Interfaces;
using RestApi.Models.Company;
using RestApi.Models.Enum;
using System.Text.Json;

namespace Outpace.APITests.Company
{
    [TestClass]
    public class CreateInstitution : BaseTestClass
    {
        [TestMethod]
        [TestCategory("PlatformAdmin")]
        public async Task Test1_CreateAnInstitutionCompany_When_UserLoginAsPlatformAdmin()
        {
            await GetTokenByRole(Role.PlatformAdmin);

            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Institution, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var institution = await DI.Container.GetService<IRestClient>().Get($"Company/Get/{companyId}", token);
            string responseInstituion = await institution.Content.ReadAsStringAsync();
            var getResponseCompany = JsonSerializer.Deserialize<CompanyDto>(responseInstituion, new JsonSerializerOptions() { PropertyNameCaseInsensitive = true });
            CompanyAssertions.AssertCompany(getResponseCompany, CompanyType.Institution, Constants.CompanyName, CompanyStructure.LTD, Jurisdiction.EnglandAndWales,
                Constants.AddressLine1, Constants.AddressLine2, Constants.City, Constants.CompaniesHouseNumber); ;
        }

        [TestMethod]
        [TestCategory("Lawyer")]
        public async Task Test2_NotAbleToCreateAnInstitutionCompany_When_UserLoginAsLawyer()
        {
            await GetTokenByRole(Role.Lawyer);
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Institution, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Unauthorized);
        }

        [TestMethod]
        [TestCategory("Founder")]
        public async Task Test3_NotAbleToCreateAnInstitutionCompany_When_UserLoginAsFounder()
        {
            await GetTokenByRole(Role.Founder);
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Institution, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Forbidden);
        }

        [TestMethod]
        [TestCategory("Investor")]
        public async Task Test4_NotAbleToCreateAnInstitutionCompany_When_UserLoginAsInvestor()
        {
            await GetTokenByRole(Role.Investor);
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Institution, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Forbidden);
        }

        [TestMethod]
        [TestCategory("InstitutionAdmin")]
        public async Task Test5_CreateAnInstitutionCompany_When_UserLoginAsInstitutionAdmin()
        {
            await GetTokenByRole(Role.InstitutionAdmin);
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Institution, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);
        }
    }
}