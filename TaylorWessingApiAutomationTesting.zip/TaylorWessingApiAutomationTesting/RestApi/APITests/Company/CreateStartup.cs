﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Outpace.Assertions;
using Outpace.Models.Enum;
using RestApi.FrameworkConfiguration;
using RestApi.Helpers;
using RestApi.Interfaces;
using RestApi.Models.Company;
using RestApi.Models.Enum;
using System.Text.Json;
namespace Outpace.APITests.Company
{
    [TestClass]
    public class CreateStartup : BaseTestClass
    {
        [TestMethod]
        [TestCategory("PlatformAdmin")]
        public async Task Test1_CreateAStartupCompany_When_UserIsPlatformAdmin()
        {
            await GetTokenByRole(Role.PlatformAdmin);

            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var startup = await DI.Container.GetService<IRestClient>().Get($"Company/Get/{companyId}", token);
            string responseStartup = await startup.Content.ReadAsStringAsync();
            var getResponseCompany = JsonSerializer.Deserialize<CompanyDto>(responseStartup, new JsonSerializerOptions() { PropertyNameCaseInsensitive = true });
            CompanyAssertions.AssertCompany(getResponseCompany, CompanyType.Startup, Constants.CompanyName, CompanyStructure.LTD, Jurisdiction.EnglandAndWales,
                Constants.AddressLine1, Constants.AddressLine2, Constants.City, Constants.CompaniesHouseNumber, Constants.Currency, Constants.Postcode);
        }

        [TestMethod]
        [TestCategory("Founder")]
        public async Task Test2_CreateAStartupCompany_When_UserIsFounder()
        {
            await GetTokenByRole(Role.Founder);

            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Forbidden);
        }

        [TestMethod]
        [TestCategory("Investor")]
        public async Task Test3_CreateAStartupCompany_When_UserIsInvestor()
        {
            await GetTokenByRole(Role.Investor);

            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Forbidden);
        }

        [TestMethod]
        [TestCategory("Lawyer")]
        public async Task Test4_CreateAStartupCompany_When_UserIsLawyer()
        {
            await GetTokenByRole(Role.Lawyer);

            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var startup = await DI.Container.GetService<IRestClient>().Get($"Company/Get/{companyId}", token);
            string responseStartup = await startup.Content.ReadAsStringAsync();
            var getResponseCompany = JsonSerializer.Deserialize<CompanyDto>(responseStartup, new JsonSerializerOptions() { PropertyNameCaseInsensitive = true });
            CompanyAssertions.AssertCompany(getResponseCompany, CompanyType.Startup, Constants.CompanyName, CompanyStructure.LTD, Jurisdiction.EnglandAndWales,
                Constants.AddressLine1, Constants.AddressLine2, Constants.City, Constants.CompaniesHouseNumber, Constants.Currency, Constants.Postcode);
        }

        [TestMethod]
        [TestCategory("InstitutionAdmin")]
        public async Task Test4_CreateAStartupCompany_When_UserIsInstitutionAdmin()
        {
            await GetTokenByRole(Role.InstitutionAdmin);

            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            var startup = await DI.Container.GetService<IRestClient>().Get($"Company/Get/{companyId}", token);
            string responseStartup = await startup.Content.ReadAsStringAsync();
            var getResponseCompany = JsonSerializer.Deserialize<CompanyDto>(responseStartup, new JsonSerializerOptions() { PropertyNameCaseInsensitive = true });
            CompanyAssertions.AssertCompany(getResponseCompany, CompanyType.Startup, Constants.CompanyName, CompanyStructure.LTD, Jurisdiction.EnglandAndWales,
                Constants.AddressLine1, Constants.AddressLine2, Constants.City, Constants.CompaniesHouseNumber, Constants.Currency, Constants.Postcode);
        }
    }
}