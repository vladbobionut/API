﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Outpace.Assertions;
using Outpace.Helpers;
using Outpace.Models.Enum;
using RestApi.Helpers;
using RestApi.Models.Company;
using RestApi.Models.CreateUser;
using RestApi.Models.Enum;

namespace Outpace.APITests.Stakeholders
{
    [TestClass]
    public class CreatePersonFounderStakeholder : BaseTestClass
    {
        [TestMethod]
        [TestCategory("PlatformAdmin")]
        public async Task Test1_CreatePersonFounderStakeholders_WhenLoginAsPlatformAdmin()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            //Arrange
            var email = FakeEmailAddress.GetFakeEmailAddress();
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //Act
            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                            Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, email, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            //Assert
            var getFounderResponse = await GetAsync<ApplicationUserDto>($"AppUser/Get/{personFounderId}");
            StakeholderAssertions.AssertStakeholder(getFounderResponse, AccessType.Founder, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, email, new DateTime(2000, 2, 22));
        }

        [TestMethod]
        [TestCategory("Lawyer")]
        public async Task Test2_CreatePersonFounderStakeholders_WhenLoginAsLawyer()
        {
            await GetTokenByRole(Role.Lawyer);
            //Arrange
            var email = FakeEmailAddress.GetFakeEmailAddress();
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //Act
            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                            Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, email, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            //Assert
            var getFounderResponse = await GetAsync<ApplicationUserDto>($"AppUser/Get/{personFounderId}");
            StakeholderAssertions.AssertStakeholder(getFounderResponse, AccessType.Founder, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, email, new DateTime(2000, 2, 22));
        }

        [TestMethod]
        [TestCategory("InstitutionAdmin")]
        public async Task Test3_CreatePersonFounderStakeholders_WhenLoginAsInstitutionAdmin()
        {
            await GetTokenByRole(Role.InstitutionAdmin);
            //Arrange
            var email = FakeEmailAddress.GetFakeEmailAddress();
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //Act
            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                            Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, email, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            //Assert
            var getFounderResponse = await GetAsync<ApplicationUserDto>($"AppUser/Get/{personFounderId}");
            StakeholderAssertions.AssertStakeholder(getFounderResponse, AccessType.Founder, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, email, new DateTime(2000, 2, 22));
        }

        [TestMethod]
        [TestCategory("Founder")]
        public async Task Test4_CreatePersonFounderStakeholders_WhenLoginAsFounder()
        {
            //Arange
            await GetTokenByRole(Role.PlatformAdmin);
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);
            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                            Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.FounderEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);
            await GetTokenByRole(Role.Founder);
            var email = FakeEmailAddress.GetFakeEmailAddress();

            //Act
            personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                            Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, email, new DateTime(2000, 2, 22), ReasonPhraseType.Created);

            //Assert
            var getFounderResponse = await GetAsync<ApplicationUserDto>($"AppUser/Get/{personFounderId}");
            StakeholderAssertions.AssertStakeholder(getFounderResponse, AccessType.Founder, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, email, new DateTime(2000, 2, 22));
        }

        [TestMethod]
        [TestCategory("Investor")]
        public async Task Test5_CreatePersonFounderStakeholders_WhenLoginAsInvestor()
        {
            //Arange
            await GetTokenByRole(Role.PlatformAdmin);
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);
            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                            Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.InvestorEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);
            await GetTokenByRole(Role.Investor);
            var email = FakeEmailAddress.GetFakeEmailAddress();

            //Act
            personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                            Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, email, new DateTime(2000, 2, 22), ReasonPhraseType.Forbidden);
        }
    }
}