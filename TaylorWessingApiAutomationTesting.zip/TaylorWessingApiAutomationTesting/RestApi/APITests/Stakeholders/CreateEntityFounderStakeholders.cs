﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Outpace.Assertions;
using Outpace.Helpers;
using Outpace.Models.Enum;
using RestApi.Helpers;
using RestApi.Models.Company;
using RestApi.Models.CreateUser;
using RestApi.Models.Enum;

namespace Outpace.APITests.Stakeholders
{
    [TestClass]
    public class CreateEntityFounderStakeholders : BaseTestClass
    {
        [TestMethod]
        [TestCategory("PlatformAdmin")]
        public async Task Test1_CreateEntityFounderStakeholders_WhenLogInAsPlatformAdmin()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            //Arrange
            var email = FakeEmailAddress.GetFakeEmailAddress();
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //Act
            var entityFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, true,
                            UserCreationType.NoOnBoarding, Constants.EntityLastName, Constants.EntityFounderFirstName, Constants.PhoneNumber, Constants.AddressLine1, Constants.AddressLine2,
                            Constants.Postcode, Constants.City, true, email, new DateTime(2000, 2, 25), ReasonPhraseType.Created);

            //Assert
            var getEntityFounderResponse = await GetAsync<ApplicationUserDto>($"AppUser/Get/{entityFounderId}");
            StakeholderAssertions.AssertStakeholder(getEntityFounderResponse, AccessType.Founder, Constants.EntityLastName, Constants.EntityFounderFirstName, Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, email, new DateTime(2000, 2, 25));
        }

        [TestMethod]
        [TestCategory("Lawyer")]
        public async Task Test2_CreateEntityFounderStakeholders_WhenLogInAsLawyer()
        {
            await GetTokenByRole(Role.Lawyer);
            //Arrange
            var email = FakeEmailAddress.GetFakeEmailAddress();
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //Act
            var entityFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, true,
                            UserCreationType.NoOnBoarding, Constants.EntityLastName, Constants.EntityFounderFirstName, Constants.PhoneNumber, Constants.AddressLine1, Constants.AddressLine2,
                            Constants.Postcode, Constants.City, true, email, new DateTime(2000, 2, 25), ReasonPhraseType.Created);

            //Assert
            var getEntityFounderResponse = await GetAsync<ApplicationUserDto>($"AppUser/Get/{entityFounderId}");
            StakeholderAssertions.AssertStakeholder(getEntityFounderResponse, AccessType.Founder, Constants.EntityLastName, Constants.EntityFounderFirstName, Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, email, new DateTime(2000, 2, 25));
        }

        [TestMethod]
        [TestCategory("InstitutionAdmin")]
        public async Task Test3_CreateEntityFounderStakeholders_WhenLogInAsInstitutionAdmin()
        {
            await GetTokenByRole(Role.InstitutionAdmin);
            //Arrange
            var email = FakeEmailAddress.GetFakeEmailAddress();
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //Act
            var entityFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, true,
                            UserCreationType.NoOnBoarding, Constants.EntityLastName, Constants.EntityFounderFirstName, Constants.PhoneNumber, Constants.AddressLine1, Constants.AddressLine2,
                            Constants.Postcode, Constants.City, true, email, new DateTime(2000, 2, 25), ReasonPhraseType.Created);

            //Assert
            var getEntityFounderResponse = await GetAsync<ApplicationUserDto>($"AppUser/Get/{entityFounderId}");
            StakeholderAssertions.AssertStakeholder(getEntityFounderResponse, AccessType.Founder, Constants.EntityLastName, Constants.EntityFounderFirstName, Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, email, new DateTime(2000, 2, 25));
        }

        [TestMethod]
        [TestCategory("Founder")]
        public async Task Test4_CreateEntityFounderStakeholders_WhenLogInAsFounder()
        {
            //Arrange
            await GetTokenByRole(Role.PlatformAdmin);
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);
            var personFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, false,
                            UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonFounderLastName, Constants.PhoneNumber,
                            Constants.AddressLine1, Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.FounderEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);
            await GetTokenByRole(Role.Founder);
            var email = FakeEmailAddress.GetFakeEmailAddress();

            //Act
            var entityFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, true,
                            UserCreationType.NoOnBoarding, Constants.EntityLastName, Constants.EntityFounderFirstName, Constants.PhoneNumber, Constants.AddressLine1, Constants.AddressLine2,
                            Constants.Postcode, Constants.City, true, email, new DateTime(2000, 2, 25), ReasonPhraseType.Created);

            //Assert
            var getEntityFounderResponse = await GetAsync<ApplicationUserDto>($"AppUser/Get/{entityFounderId}");
            StakeholderAssertions.AssertStakeholder(getEntityFounderResponse, AccessType.Founder, Constants.EntityLastName, Constants.EntityFounderFirstName, Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, email, new DateTime(2000, 2, 25));
        }

        [TestMethod]
        [TestCategory("Investor")]
        public async Task Test5_CreateEntityFounderStakeholders_WhenLogInAsInvestor()
        {
            //Arrange
            await GetTokenByRole(Role.PlatformAdmin);
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);
            var personInvestorId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Investor, false,
                              UserCreationType.NoOnBoarding, Constants.PersonStakeholderFirstName, Constants.PersonInvestorLastName, Constants.PhoneNumber, Constants.AddressLine1,
                              Constants.AddressLine2, Constants.Postcode, Constants.City, true, Constants.InvestorEmail, new DateTime(2000, 2, 22), ReasonPhraseType.Created);
            await GetTokenByRole(Role.Founder);
            var email = FakeEmailAddress.GetFakeEmailAddress();

            //Act
            var entityFounderId = await StakeholderHelper.CreateStakeholder(token, companyId, AccessType.Founder, true,
                            UserCreationType.NoOnBoarding, Constants.EntityLastName, Constants.EntityFounderFirstName, Constants.PhoneNumber, Constants.AddressLine1, Constants.AddressLine2,
                            Constants.Postcode, Constants.City, true, email, new DateTime(2000, 2, 25), ReasonPhraseType.Created);

            //Assert
            var getEntityFounderResponse = await GetAsync<ApplicationUserDto>($"AppUser/Get/{entityFounderId}");
            StakeholderAssertions.AssertStakeholder(getEntityFounderResponse, AccessType.Founder, Constants.EntityLastName, Constants.EntityFounderFirstName, Constants.PhoneNumber, Constants.AddressLine1,
                Constants.AddressLine2, Constants.Postcode, Constants.City, email, new DateTime(2000, 2, 25));
        }
    }
}