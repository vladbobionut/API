﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Outpace.Models.Enum;
using FluentAssertions;
using RestApi.FrameworkConfiguration;

namespace Outpace.APITests.AdminPannel
{
    [TestClass]
    public class Login : BaseTestClass
    {
        [TestMethod]
        [TestCategory("PlatformAdmin")]
        public async Task Test1_ShouldLoginWithUserNameAndPassword_ForPlatformAdmin()
        {
            User user = GetUserInfo(Role.PlatformAdmin);

            await GetTokenWithUserNameAndPassword(user.UserName, user.Password);
            token.Should().NotBe(string.Empty);
        }

        [TestMethod]
        [TestCategory("Lawyer")]
        public async Task Test2_ShouldLoginWithUserNameAndPassword_ForLawyer()
        {
            User user = GetUserInfo(Role.Lawyer);

            await GetTokenWithUserNameAndPassword(user.UserName, user.Password);
            token.Should().NotBe(string.Empty);
        }

        [TestMethod]
        [TestCategory("InstitutionAdmin")]
        public async Task Test3_ShouldLoginWithUserNameAndPassword_ForInstitutionAdmin()
        {
            User user = GetUserInfo(Role.InstitutionAdmin);

            await GetTokenWithUserNameAndPassword(user.UserName, user.Password);
            token.Should().NotBe(string.Empty);
        }

        [TestMethod]
        [TestCategory("Founder")]
        public async Task Test4_ShouldLoginWithUserNameAndPassword_ForFounder()
        {
            User user = GetUserInfo(Role.Founder);

            await GetTokenWithUserNameAndPassword(user.UserName, user.Password);
            token.Should().NotBe(string.Empty);
        }

        [TestMethod]
        [TestCategory("Investor")]
        public async Task Test5_ShouldLoginWithUserNameAndPassword_ForInvestor()
        {
            User user = GetUserInfo(Role.Investor);

            await GetTokenWithUserNameAndPassword(user.UserName, user.Password);
            token.Should().NotBe(string.Empty);
        }

        [TestMethod]
        [TestCategory("AllRoles")]
        public async Task Test6_ShouldNotLoginWithOutUserNameAndPassword()
        {
            Func<Task> asyncAction = async () => await GetTokenWithUserNameAndPassword("", "");


            var exception = await Assert.ThrowsExceptionAsync<Exception>(asyncAction);
            Assert.IsTrue(exception.Message.Contains("The Email field is required."));
            Assert.IsTrue(exception.Message.Contains("The Email field is not a valid e-mail address."));
            Assert.IsTrue(exception.Message.Contains("The Password field is required."));
        }

        [TestMethod]
        [TestCategory("AllRoles")]
        public async Task Test7_ShouldNotLoginWithNoUserNameAndCorrectPassword_ForAllRoles()
        {
            Func<Task> asyncAction = async () => await GetTokenWithUserNameAndPassword("", "Pa$$w0rd");

            var exception = await Assert.ThrowsExceptionAsync<Exception>(asyncAction);
            Assert.IsTrue(exception.Message.Contains("The Email field is required."));
            Assert.IsTrue(exception.Message.Contains("The Email field is not a valid e-mail address."));
        }

        [TestMethod]
        [TestCategory("AllRoles")]
        public async Task Test8_ShouldNotLoginWithUserNameAndNoPassword_ForAllRoles()
        {
            User user = GetUserInfo(Role.PlatformAdmin);

            Func<Task> asyncAction = async () => await GetTokenWithUserNameAndPassword(user.UserName, "");

            var exception = await Assert.ThrowsExceptionAsync<Exception>(asyncAction);
            Assert.IsTrue(exception.Message.Contains("The Password field is required."));
        }

        [TestMethod]
        [TestCategory("AllRoles")]
        [Ignore("TW-2343")]
        public async Task Test9_ShouldNotLoginWithUserNameAndWrongPassword_ForAllRoles()
        {
            User userPlatformAdmin = GetUserInfo(Role.PlatformAdmin);

            Func<Task> asyncAction = async () => await GetTokenWithUserNameAndPassword(userPlatformAdmin.UserName, "SimpleTest");

            var exception = await Assert.ThrowsExceptionAsync<Exception>(asyncAction);
            Assert.IsTrue(exception.Message.Contains("Invalid Email or Password"));
        }
    }
}