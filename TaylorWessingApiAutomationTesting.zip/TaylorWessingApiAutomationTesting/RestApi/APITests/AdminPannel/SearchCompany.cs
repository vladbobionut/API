﻿using FluentAssertions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Outpace.Models.Enum;
using RestApi.Helpers;
using RestApi.Models;
using RestApi.Models.Company;
using RestApi.Models.Enum;

namespace Outpace.APITests.AdminPannel
{
    [TestClass]
    public class SearchCompany : BaseTestClass
    {
        [TestMethod]
        [TestCategory("PlatformAdmin")]
        public async Task Test1_SearchByStartupCompanyName_When_LoginAsPlatformAdmin()
        {
            //create startup company
            await GetTokenByRole(Role.PlatformAdmin);
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created, "CompanyStartupSearch");

            // Search company and assert by Id
            var getSerchCompany = await GetAsync<PagedResponse<CompanyDto>>($"Company/GetAll?Count=true&Orderby=createdDate%20desc&Filter=contains(toLower(CompanyName),%20%27companystartupsearch%27)");
            getSerchCompany.Items.FirstOrDefault().Id.Should().Be(companyId);
        }

        [TestMethod]
        [TestCategory("PlatformAdmin")]
        public async Task Test2_SearchByInstitutionName_When_LoginAsPlatformAdmin()
        {
            //create institution company
            await GetTokenByRole(Role.PlatformAdmin);
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Institution, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created, "CompanyInstitutionSearch");

            // Search company and assert by Id
            var getSerchCompany = await GetAsync<PagedResponse<CompanyDto>>($"Company/GetAll?Count=true&Orderby=createdDate%20desc&Filter=contains(toLower(CompanyName),%20%27companyinstitutionsearch%27)");
            getSerchCompany.Items.FirstOrDefault().Id.Should().Be(companyId);
        }
    }
}