﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Outpace.Assertions;
using Outpace.Helpers;
using Outpace.Models.Enum;
using Outpace.Models.Users;
using RestApi.Helpers;
using RestApi.Models.Enum;


namespace Outpace.APITests.AdminPannel.CreateUser
{
    [TestClass]
    public class CreatePlatformAdminUser : BaseTestClass
    {
        [TestMethod]
        [TestCategory("PlatformAdmin")]
        public async Task Test1_CreatePlatformAdminUser_When_LoginAsPlatformAdmin()
        {
            //create user
            await GetTokenByRole(Role.PlatformAdmin);
            var email = FakeEmailAddress.GetFakeEmailAddress();
            var userId = await UserHelper.CreateUser(token, email, Constants.PaFirstName, Constants.PaLastName, new List<AccessType> { AccessType.PlatformAdmin }, UserCreationType.RegisteredByAdmin, new List<Guid> { }, ReasonPhraseType.Created);

            // assert user creation (Platform Admin)
            var getUser = await GetAsync<ApplicationUserDto>($"AppUser/Get/{userId}");
            CreateUserAssertions.AssertUserCreation(email, getUser, Constants.AddressLine1, Constants.AddressLine2, Constants.City,
                Constants.Postcode, Constants.PaFirstName, Constants.PaLastName, "PlatformAdmin");
        }

        [TestMethod]
        [TestCategory("Lawyer")]
        public async Task Test2_NotAbleToCreatePlatformAdminUser_When_LoginAsLawyer()
        {
            await GetTokenByRole(Role.Lawyer);
            var email = FakeEmailAddress.GetFakeEmailAddress();
            var userId = await UserHelper.CreateUser(token, email, Constants.PaFirstName, Constants.PaLastName, new List<AccessType> { AccessType.PlatformAdmin }, UserCreationType.RegisteredByAdmin, new List<Guid> { }, ReasonPhraseType.Unauthorized);
        }

        [TestMethod]
        [TestCategory("InstitutionAdmin")]
        public async Task Test3_NotAbleToCreatePlatformAdminUser_When_LoginAsInstitutionAdmin()
        {
            await GetTokenByRole(Role.InstitutionAdmin);
            var email = FakeEmailAddress.GetFakeEmailAddress();
            var userId = await UserHelper.CreateUser(token, email, Constants.PaFirstName, Constants.PaLastName, new List<AccessType> { AccessType.PlatformAdmin }, UserCreationType.RegisteredByAdmin, new List<Guid> { }, ReasonPhraseType.Unauthorized);
        }

        [TestMethod]
        [TestCategory("Founder")]
        public async Task Test4_NotAbleToCreatePlatformAdminUser_When_LoginAsFounder()
        {
            await GetTokenByRole(Role.Founder);
            var email = FakeEmailAddress.GetFakeEmailAddress();
            var userId = await UserHelper.CreateUser(token, email, Constants.PaFirstName, Constants.PaLastName, new List<AccessType> { AccessType.PlatformAdmin }, UserCreationType.RegisteredByAdmin, new List<Guid> { }, ReasonPhraseType.Unauthorized);
        }

        [TestMethod]
        [TestCategory("Investor")]
        public async Task Test5_NotAbleToCreatePlatformAdminUser_When_LoginAsInvestor()
        {
            await GetTokenByRole(Role.Investor);
            var email = FakeEmailAddress.GetFakeEmailAddress();
            var userId = await UserHelper.CreateUser(token, email, Constants.PaFirstName, Constants.PaLastName, new List<AccessType> { AccessType.PlatformAdmin }, UserCreationType.RegisteredByAdmin, new List<Guid> { }, ReasonPhraseType.Forbidden);
        }
    }
}