﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Outpace.Assertions;
using Outpace.Helpers;
using Outpace.Models.Enum;
using Outpace.Models.Users;
using RestApi.Helpers;
using RestApi.Models.Company;
using RestApi.Models.Enum;

namespace Outpace.APITests.AdminPannel.CreateUser
{
    [TestClass]
    public class CreateLawyerUser : BaseTestClass
    {
        [TestMethod]
        [TestCategory("PlatformAdmin")]
        public async Task Test1_CreateTWLawyerUser_When_LoginAsPlatformAdmin()
        {
            //create startup company
            await GetTokenByRole(Role.PlatformAdmin);
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //create TWLawyer user
            var email = FakeEmailAddress.GetFakeEmailAddress();
            var userId = await UserHelper.CreateUser(token, email, Constants.LawyerFirstName, Constants.LawyerLastName, new List<AccessType> { AccessType.TWLawyer }, UserCreationType.RegisteredByAdmin, new List<Guid> { companyId }, ReasonPhraseType.Created);

            // assert user creation (TW Lawyer)
            var getUser = await GetAsync<ApplicationUserDto>($"AppUser/Get/{userId}");
            CreateUserAssertions.AssertUserCreation(email, getUser, Constants.AddressLine1, Constants.AddressLine2, Constants.City,
                Constants.Postcode, Constants.LawyerFirstName, Constants.LawyerLastName, "TWLawyer", companyId.ToString());
        }

        [TestMethod]
        [TestCategory("Lawyer")]
        [Ignore("TW-2320")]
        public async Task Test2_CreateTWLawyerUser_When_LoginAsLawyer()
        {
            await GetTokenByRole(Role.Lawyer);
            //create startup company
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //create TWLawyer user
            var email = FakeEmailAddress.GetFakeEmailAddress();
            var userId = await UserHelper.CreateUser(token, email, Constants.LawyerFirstName, Constants.LawyerLastName, new List<AccessType> { AccessType.TWLawyer }, UserCreationType.RegisteredByAdmin, new List<Guid> { }, ReasonPhraseType.Forbidden);
        }

        [TestMethod]
        [TestCategory("InstitutionAdmin")]
        [Ignore("TW-2320")]
        public async Task Test3_CreateTWLawyerUser_When_LoginAsInstitutionAdmin()
        {
            await GetTokenByRole(Role.InstitutionAdmin);
            //create startup company
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //create TWLawyer user
            var email = FakeEmailAddress.GetFakeEmailAddress();
            var userId = await UserHelper.CreateUser(token, email, Constants.LawyerFirstName, Constants.LawyerLastName, new List<AccessType> { AccessType.TWLawyer }, UserCreationType.RegisteredByAdmin, new List<Guid> { }, ReasonPhraseType.Forbidden);
        }


        [TestMethod]
        [TestCategory("Founder")]
        [Ignore("TW-2320")]
        public async Task Test4_CreateTWLawyerUser_ShouldForbidden_WhenLoginAsFounder()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            //create startup company
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //create TWLawyer user
            await GetTokenByRole(Role.Founder);
            var email = FakeEmailAddress.GetFakeEmailAddress();
            var userId = await UserHelper.CreateUser(token, email, Constants.LawyerFirstName, Constants.LawyerLastName, new List<AccessType> { AccessType.TWLawyer }, UserCreationType.RegisteredByAdmin, new List<Guid> { }, ReasonPhraseType.Forbidden);
        }

        [TestMethod]
        [TestCategory("Investor")]
        public async Task Test5_CreateTWLawyerUser_ShouldForbidden_WhenLoginAsInvestor()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            //create startup company
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Startup, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //create TWLawyer user
            await GetTokenByRole(Role.Investor);
            var email = FakeEmailAddress.GetFakeEmailAddress();
            var userId = await UserHelper.CreateUser(token, email, Constants.LawyerFirstName, Constants.LawyerLastName, new List<AccessType> { AccessType.TWLawyer }, UserCreationType.RegisteredByAdmin, new List<Guid> { }, ReasonPhraseType.Forbidden);
        }
    }
}