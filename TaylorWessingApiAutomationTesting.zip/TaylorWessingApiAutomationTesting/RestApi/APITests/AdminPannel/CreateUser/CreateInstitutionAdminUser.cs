﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Outpace.Assertions;
using Outpace.Helpers;
using Outpace.Models.Enum;
using Outpace.Models.Users;
using RestApi.Helpers;
using RestApi.Models.Company;
using RestApi.Models.Enum;

namespace Outpace.APITests.AdminPannel.CreateUser
{
    [TestClass]
    public class CreateInstitutionAdminUser : BaseTestClass
    {
        [TestMethod]
        [TestCategory("PlatformAdmin")]

        public async Task Test1_CreateInstitutionAdminUser_When_WhenLoginAsPlatformAdmin()
        {
            //create institution company
            await GetTokenByRole(Role.PlatformAdmin);
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Institution, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //create InstitutinAmin user
            var email = FakeEmailAddress.GetFakeEmailAddress();
            var userId = await UserHelper.CreateUser(token, email, Constants.IAFirstName, Constants.IALastName, new List<AccessType> { AccessType.InstitutionAdmin }, UserCreationType.RegisteredByAdmin, new List<Guid> { companyId }, ReasonPhraseType.Created);

            // assert user creation (Institution Admin)
            var getUser = await GetAsync<ApplicationUserDto>($"AppUser/Get/{userId}");
            CreateUserAssertions.AssertUserCreation(email, getUser, Constants.AddressLine1, Constants.AddressLine2, Constants.City,
                Constants.Postcode, Constants.IAFirstName, Constants.IALastName, "InstitutionAdmin", companyId.ToString());
        }

        [TestMethod]
        [TestCategory("Lawyer")]
        [Ignore("TW-2321")]
        public async Task Test2_CreateInstitutionAdminUser_When_WhenLoginAsLawyer()
        {
            //create institution company
            await GetTokenByRole(Role.PlatformAdmin);
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Institution, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            await GetTokenByRole(Role.Lawyer);
            //create InstitutinAmin user
            var email = FakeEmailAddress.GetFakeEmailAddress();
            var userId = await UserHelper.CreateUser(token, email, Constants.IAFirstName, Constants.IALastName, new List<AccessType> { AccessType.InstitutionAdmin }, UserCreationType.RegisteredByAdmin, new List<Guid> { }, ReasonPhraseType.Forbidden);
        }

        [TestMethod]
        [TestCategory("InstitutionAdmin")]
        [Ignore("TW-2321")]
        public async Task Test3_CreateInstitutionAdminUser_When_WhenLoginAsInstitutionAdmin()
        {
            //create institution company
            await GetTokenByRole(Role.InstitutionAdmin);
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Institution, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            //create InstitutinAmin user
            var email = FakeEmailAddress.GetFakeEmailAddress();
            var userId = await UserHelper.CreateUser(token, email, Constants.IAFirstName, Constants.IALastName, new List<AccessType> { AccessType.InstitutionAdmin }, UserCreationType.RegisteredByAdmin, new List<Guid> { }, ReasonPhraseType.Forbidden);
        }

        [TestMethod]
        [TestCategory("Founder")]
        [Ignore("TW-2321")]
        public async Task Test4_CreateInstitutionAdmin_ShouldReceiveForbidden_WhenLoginAsFounder()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            //create institution company
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Institution, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            await GetTokenByRole(Role.Founder);
            //create InstitutinAmin user
            var email = FakeEmailAddress.GetFakeEmailAddress();
            var userId = await UserHelper.CreateUser(token, email, Constants.IAFirstName, Constants.IALastName, new List<AccessType> { AccessType.InstitutionAdmin }, UserCreationType.RegisteredByAdmin, new List<Guid> { }, ReasonPhraseType.Forbidden);
        }

        [TestMethod]
        [TestCategory("Investor")]
        public async Task Test5_CreateInstitutionAdmin_ShouldReceiveForbidden_WhenLoginAsInvestor()
        {
            await GetTokenByRole(Role.PlatformAdmin);
            //create institution company
            var companyId = await CompanyHelper.CreateStartupCompany(token, CompanyType.Institution, CompanyStructure.LTD, Jurisdiction.EnglandAndWales, ReasonPhraseType.Created);

            await GetTokenByRole(Role.Investor);
            //create InstitutinAmin user
            var email = FakeEmailAddress.GetFakeEmailAddress();
            var userId = await UserHelper.CreateUser(token, email, Constants.IAFirstName, Constants.IALastName, new List<AccessType> { AccessType.InstitutionAdmin }, UserCreationType.RegisteredByAdmin, new List<Guid> { }, ReasonPhraseType.Forbidden);
        }
    }
}