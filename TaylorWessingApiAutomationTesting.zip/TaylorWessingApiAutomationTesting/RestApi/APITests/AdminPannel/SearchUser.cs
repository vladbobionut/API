﻿using FluentAssertions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Outpace.Helpers;
using Outpace.Models.Enum;
using Outpace.Models.Users;
using RestApi.Helpers;
using RestApi.Models;
using RestApi.Models.Enum;

namespace Outpace.APITests.AdminPannel
{
    [TestClass]
    public class SearchUser : BaseTestClass
    {
        [TestMethod]
        [TestCategory("PlatformAdmin")]
        public async Task Test1_SearchByFirstNameForAUser_When_LoginAsPLatformAdmin()
        {
            //create user
            await GetTokenByRole(Role.PlatformAdmin);
            var firstNameUser = StringGenerator.RandomString(10, true);
            var userId = await UserHelper.CreateUser(token, FakeEmailAddress.GetFakeEmailAddress(), firstNameUser, "LastName", new List<AccessType> { AccessType.PlatformAdmin }, UserCreationType.RegisteredByAdmin, new List<Guid> { }, ReasonPhraseType.Created);

            // Search user and assert by Id
            var getSerchUser = await GetAsync<PagedResponse<ApplicationUserDto>>($"AppUser/GetAll?Count=true&Orderby=firstName%20asc&Filter=contains(toLower(email),%20%27{firstNameUser}%27)%20or%20contains(toLower(firstName),%20%27{firstNameUser}%27)%20or%20contains(toLower(lastName),%20%27{firstNameUser}%27)");
            getSerchUser.Items.Where(user => user.Id == userId).Count().Should().Be(1);
        }

        [TestMethod]
        [TestCategory("PlatformAdmin")]
        public async Task Test2_SearchByLastNameForAUser_When_LoginAsPLatformAdmin()
        {
            //create user
            await GetTokenByRole(Role.PlatformAdmin);
            var lastNameUser = StringGenerator.RandomString(10, true);
            var userId = await UserHelper.CreateUser(token, FakeEmailAddress.GetFakeEmailAddress(), "Searching", lastNameUser, new List<AccessType> { AccessType.PlatformAdmin }, UserCreationType.RegisteredByAdmin, new List<Guid> { }, ReasonPhraseType.Created);

            // Search user and assert by Id
            var getSerchUser = await GetAsync<PagedResponse<ApplicationUserDto>>($"AppUser/GetAll?Count=true&Orderby=firstName%20asc&Filter=contains(toLower(email),%20%27{lastNameUser}%27)%20or%20contains(toLower(firstName),%20%27{lastNameUser}%27)%20or%20contains(toLower(lastName),%20%27{lastNameUser}%27)");
            getSerchUser.Items.Where(user => user.Id == userId).Count().Should().Be(1);
        }

        [TestMethod]
        [TestCategory("PlatformAdmin")]
        public async Task Test3_SearchByEmailAddressForAUser_When_LoginAsPLatformAdmin()
        {
            //create user
            await GetTokenByRole(Role.PlatformAdmin);
            var email = FakeEmailAddress.GetFakeEmailAddress().ToLower();
            var userId = await UserHelper.CreateUser(token, email, "Searching", "Greuceanul", new List<AccessType> { AccessType.PlatformAdmin }, UserCreationType.RegisteredByAdmin, new List<Guid> { }, ReasonPhraseType.Created);

            // Search user and assert by Id
            var getSerchUser = await GetAsync<PagedResponse<ApplicationUserDto>>($"AppUser/GetAll?Count=true&Orderby=firstName%20asc&Filter=contains(toLower(email),%20%27{email}%27)%20or%20contains(toLower(firstName),%20%27{email}%27)%20or%20contains(toLower(lastName),%20%27{email}%27)");
            getSerchUser.Items.Where(user => user.Id == userId).Count().Should().Be(1);
        }
    }
}