﻿using FluentAssertions;
using RestApi.Helpers;
using RestApi.Models.CapTable;

namespace Outpace.Assertions
{
    public class ShareRegisterAssertions
    {
        public static Guid AssertShareRegisterForFounder(ShareRegisterResponce getResponseShareRegister,string address, string shareClass,
            string stakeholder, decimal sharesNumber)
        {
            var shareRegister = getResponseShareRegister.Items.FirstOrDefault();
            shareRegister.Address.Should().Be(address); 
            shareRegister.ShareClass.Should().Be(shareClass); 
            shareRegister.Stakeholder.Should().Be(stakeholder); 
            shareRegister.SharesNumber.Should().Be(sharesNumber); 
            var investmentPersonFounderId = shareRegister.InvestmentId;
            return investmentPersonFounderId;
        }
    }
}