﻿using FluentAssertions;
using RestApi.Models.Company;

namespace Outpace.Assertions
{
    public class HomePageAssertions
    {
        public static void GetAndAssertCapTableFromHomePage(StartupHomePageDetails getStartupHomePage, decimal totalInvested, decimal latestTransactionInvestedAmount, int stakeholdersCount,
               int? fullyGrantedShares = null, decimal? poolPercentage=null)
        {
            getStartupHomePage.Should().NotBeNull();
            getStartupHomePage.CapTable.TotalInvested.Should().Be(totalInvested);
            getStartupHomePage.CapTable.LatestTransactionInvestedAmount.Should().Be(latestTransactionInvestedAmount);
            getStartupHomePage.CapTable.StakeholdersCount.Should().Be(stakeholdersCount);
            if (fullyGrantedShares != null && poolPercentage !=null)
            {
                getStartupHomePage.EquityPlans.FullyGrantedShares.Should().Be(fullyGrantedShares);
                getStartupHomePage.EquityPlans.DilutedPercentages["Option Pool"].Should().Be(poolPercentage);
            }
        }
    }
}