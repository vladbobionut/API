﻿using FluentAssertions;
using Outpace.Models.Users;

namespace Outpace.Assertions
{
    public class CreateUserAssertions
    {
        public static void AssertUserCreation(string email, ApplicationUserDto getUser, string address1, string address2, string city,
            string postalCode, string firstName, string LastName, string accessType, string? companyIds=null)
        {
            getUser.Should().NotBeNull();
            getUser.AddressLine1.Should().Be(address1);
            getUser.AddressLine2.Should().Be(address2);
            getUser.City.Should().Be(city);
            getUser.Postcode.Should().Be(postalCode);
            getUser.FirstName.Should().Be(firstName);
            getUser.LastName.Should().Be(LastName);
            getUser.Email.Should().Be(email);
            getUser.AccessTypes.FirstOrDefault().Name.Should().Be(accessType);
            if (companyIds != null)
            {
                getUser.Companies.FirstOrDefault().CompanyId.Should().Be(companyIds);             
            }
        }
    }
}
