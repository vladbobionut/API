﻿using Contracts.Catalog.CapTable.Transactions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Text.Json;

namespace Outpace.Assertions.CapTable
{
    public class CapTablePriceRoundAssertions
    {
        public static string ExpectedResultAfterPriceRound = "{\"postMoneyValuation\":10600000.00,\"stakeHolders\":6,\"issuedShares\":424000,\"invested\":700000.00,\"totalDilutedShares\":424000,\"totalFundings\":[{},{}],\"chartShareholdingDataList\":[{\"name\":\"Founder\",\"sharesPercentage\":94.34,\"investment\":0},{\"name\":\"Investor\",\"sharesPercentage\":5.66,\"investment\":600000.00}],\"tables\":[{\"name\":\"Detailed\",\"headers\":[{\"name\":\"Ordinary Share Class\",\"total\":424000},{\"name\":\"Total (fully diluted)\",\"total\":424000},{\"name\":\"Issued (%)\",\"total\":100.00},{\"name\":\"Fully Diluted (%)\",\"total\":100.00},{\"name\":\"Vote (%)\",\"total\":100.00},{\"name\":\"Investment\",\"total\":700000.00}],\"sections\":[{\"name\":\"Founder\",\"totals\":[400000,400000,94.34,94.34,94.34,0],\"rows\":[{\"name\":\"FounderP Person\",\"values\":[100000,100000,23.58,23.58,23.58,0]},{\"name\":\"Rus Marinel\",\"values\":[100000,100000,23.58,23.58,23.58,0]},{\"name\":\"Muresan Denis\",\"values\":[100000,100000,23.58,23.58,23.58,0]},{\"name\":\"Nesu Mihai\",\"values\":[100000,100000,23.58,23.58,23.58,0]}]},{\"name\":\"Investor\",\"totals\":[24000,24000,5.66,5.66,5.66,600000.00],\"rows\":[{\"name\":\"Prunean Cosmin\",\"values\":[20000,20000,4.72,4.72,4.72,500000.00]},{\"name\":\"Marinel Gugustiuc\",\"values\":[4000,4000,0.94,0.94,0.94,100000.00]}]},{\"name\":\"Convertibles\",\"totals\":[0,0,0,0,0,100000.00],\"rows\":[{\"name\":\"Prunean Cosmin\",\"values\":[0,0,0,0,0,100000.00]}]}]},{\"name\":\"Summary\",\"headers\":[{\"name\":\"Total (fully diluted)\",\"total\":424000},{\"name\":\"Issued (%)\",\"total\":100.00},{\"name\":\"Fully Diluted (%)\",\"total\":100.00},{\"name\":\"Vote (%)\",\"total\":100.00}],\"sections\":[{\"name\":\"Ordinary shares\",\"totals\":[424000,100,100,100],\"rows\":[{\"name\":\"Ordinary\",\"values\":[0,0,0,0]},{\"name\":\"Ordinary Share Class\",\"values\":[424000,100,100,100]}]}]}]}";

        public static void GetAndAssertCapTableAfterPriceRound(CapTableResponse getCapTable)
        {
            var actual = JsonSerializer.Serialize(getCapTable);
            Assert.IsTrue(string.Equals(ExpectedResultAfterPriceRound.ToLower(), actual.ToLower(), StringComparison.OrdinalIgnoreCase));
        }

        public static string ExpectedResultAfterPriceRoundForFounder = "{\"postMoneyValuation\":10600000.00,\"stakeHolders\":6,\"issuedShares\":424000,\"invested\":700000.00,\"totalDilutedShares\":424000,\"totalFundings\":[{},{}],\"chartShareholdingDataList\":[{\"name\":\"Founder\",\"sharesPercentage\":94.34,\"investment\":0},{\"name\":\"Investor\",\"sharesPercentage\":5.66,\"investment\":600000.00}],\"tables\":[{\"name\":\"Detailed\",\"headers\":[{\"name\":\"Ordinary Share Class\",\"total\":424000},{\"name\":\"Total (fully diluted)\",\"total\":424000},{\"name\":\"Issued (%)\",\"total\":100.00},{\"name\":\"Fully Diluted (%)\",\"total\":100.00},{\"name\":\"Vote (%)\",\"total\":100.00},{\"name\":\"Investment\",\"total\":700000.00}],\"sections\":[{\"name\":\"Founder\",\"totals\":[400000,400000,94.34,94.34,94.34,0],\"rows\":[{\"name\":\"PersonFaunder Automatio\",\"values\":[100000,100000,23.58,23.58,23.58,0]},{\"name\":\"Rus Marinel\",\"values\":[100000,100000,23.58,23.58,23.58,0]},{\"name\":\"Muresan Denis\",\"values\":[100000,100000,23.58,23.58,23.58,0]},{\"name\":\"Nesu Mihai\",\"values\":[100000,100000,23.58,23.58,23.58,0]}]},{\"name\":\"Investor\",\"totals\":[24000,24000,5.66,5.66,5.66,600000.00],\"rows\":[{\"name\":\"Prunean Cosmin\",\"values\":[20000,20000,4.72,4.72,4.72,500000.00]},{\"name\":\"Marinel Gugustiuc\",\"values\":[4000,4000,0.94,0.94,0.94,100000.00]}]},{\"name\":\"Convertibles\",\"totals\":[0,0,0,0,0,100000.00],\"rows\":[{\"name\":\"Prunean Cosmin\",\"values\":[0,0,0,0,0,100000.00]}]}]},{\"name\":\"Summary\",\"headers\":[{\"name\":\"Total (fully diluted)\",\"total\":424000},{\"name\":\"Issued (%)\",\"total\":100.00},{\"name\":\"Fully Diluted (%)\",\"total\":100.00},{\"name\":\"Vote (%)\",\"total\":100.00}],\"sections\":[{\"name\":\"Ordinary shares\",\"totals\":[424000,100,100,100],\"rows\":[{\"name\":\"Ordinary\",\"values\":[0,0,0,0]},{\"name\":\"Ordinary Share Class\",\"values\":[424000,100,100,100]}]}]}]}";

        public static void GetAndAssertCapTableAfterPriceRoundForFounder(CapTableResponse getCapTable)
        {
            var actual = JsonSerializer.Serialize(getCapTable);
            Assert.IsTrue(string.Equals(ExpectedResultAfterPriceRoundForFounder.ToLower(), actual.ToLower(), StringComparison.OrdinalIgnoreCase));
        }
    }
}