﻿using Contracts.Catalog.CapTable.Transactions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Text.Json;

namespace Outpace.Assertions.CapTable
{
    public class CapTableIncorporationAssertions
    {
        public static string ExpectedResultAfterIncorporationn = "{\"postMoneyValuation\":0,\"stakeHolders\":4,\"issuedShares\":4,\"invested\":0.00,\"totalDilutedShares\":4,\"totalFundings\":[],\"chartShareholdingDataList\":[{\"name\":\"Founder\",\"sharesPercentage\":100,\"investment\":0},{\"name\":\"Investor\",\"sharesPercentage\":0,\"investment\":0}],\"tables\":[{\"name\":\"Detailed\",\"headers\":[{\"name\":\"Ordinary Share Class\",\"total\":4},{\"name\":\"Total (fully diluted)\",\"total\":4},{\"name\":\"Issued (%)\",\"total\":100.00},{\"name\":\"Fully Diluted (%)\",\"total\":100.00},{\"name\":\"Vote (%)\",\"total\":100.00},{\"name\":\"Investment\",\"total\":0.00}],\"sections\":[{\"name\":\"Founder\",\"totals\":[4,4,100,100,100,0],\"rows\":[{\"name\":\"FounderP Person\",\"values\":[1,1,25.00,25.00,25.00,0]},{\"name\":\"Rus Marinel\",\"values\":[1,1,25.00,25.00,25.00,0]},{\"name\":\"Muresan Denis\",\"values\":[1,1,25.00,25.00,25.00,0]},{\"name\":\"PersonFaunder Automatio\",\"values\":[1,1,25.00,25.00,25.00,0]}]}]},{\"name\":\"Summary\",\"headers\":[{\"name\":\"Total (fully diluted)\",\"total\":4},{\"name\":\"Issued (%)\",\"total\":100.00},{\"name\":\"Fully Diluted (%)\",\"total\":100.00},{\"name\":\"Vote (%)\",\"total\":100.00}],\"sections\":[{\"name\":\"Ordinary shares\",\"totals\":[4,100,100,100],\"rows\":[{\"name\":\"Ordinary\",\"values\":[0,0,0,0]},{\"name\":\"Ordinary Share Class\",\"values\":[4,100,100,100]}]}]}]}";
        public static void GetAndAssertCapTableAfterAnIncorporationForFounder(CapTableResponse getCapTable)
        {
            var actual = JsonSerializer.Serialize(getCapTable);
            Assert.IsTrue(string.Equals(ExpectedResultAfterIncorporationn.ToLower(), actual.ToLower(), StringComparison.OrdinalIgnoreCase));
        }

        public static string ExpectedResulstAfterIncorporation = "{\"postMoneyValuation\":0,\"stakeHolders\":1,\"issuedShares\":5000000,\"invested\":0.00,\"totalDilutedShares\":5000000,\"totalFundings\":[],\"chartShareholdingDataList\":[{\"name\":\"Founder\",\"sharesPercentage\":100,\"investment\":0},{\"name\":\"Investor\",\"sharesPercentage\":0,\"investment\":0}],\"tables\":[{\"name\":\"Detailed\",\"headers\":[{\"name\":\"Ordinary Share Class\",\"total\":5000000},{\"name\":\"Total (fully diluted)\",\"total\":5000000},{\"name\":\"Issued (%)\",\"total\":100.00},{\"name\":\"Fully Diluted (%)\",\"total\":100.00},{\"name\":\"Vote (%)\",\"total\":100.00},{\"name\":\"Investment\",\"total\":0.00}],\"sections\":[{\"name\":\"Founder\",\"totals\":[5000000,5000000,100,100,100,0],\"rows\":[{\"name\":\"PersonFaunder Automatio\",\"values\":[5000000,5000000,100,100,100,0]}]}]},{\"name\":\"Summary\",\"headers\":[{\"name\":\"Total (fully diluted)\",\"total\":5000000},{\"name\":\"Issued (%)\",\"total\":100.00},{\"name\":\"Fully Diluted (%)\",\"total\":100.00},{\"name\":\"Vote (%)\",\"total\":100.00}],\"sections\":[{\"name\":\"Ordinary shares\",\"totals\":[5000000,100,100,100],\"rows\":[{\"name\":\"Ordinary Share Class\",\"values\":[5000000,100,100,100]}]}]}]}";       
        public static void GetAndAssertCapTableAfterAnIncorporation(CapTableResponse getCapTable)
        {
            var actual = JsonSerializer.Serialize(getCapTable);
            Assert.IsTrue(string.Equals(ExpectedResulstAfterIncorporation.ToLower(), actual.ToLower(), StringComparison.OrdinalIgnoreCase));
        }
    }
}