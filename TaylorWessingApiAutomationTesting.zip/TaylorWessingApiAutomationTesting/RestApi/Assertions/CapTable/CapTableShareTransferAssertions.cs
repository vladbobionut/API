﻿using Contracts.Catalog.CapTable.Transactions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Text.Json;

namespace Outpace.Assertions.CapTable
{
    public class CapTableShareTransferAssertions
    {
        public static string ExpectedResultAfterShareTransfer = "{\"postMoneyValuation\":0,\"stakeHolders\":2,\"issuedShares\":100,\"invested\":0.00,\"totalDilutedShares\":100,\"totalFundings\":[],\"chartShareholdingDataList\":[{\"name\":\"Founder\",\"sharesPercentage\":100,\"investment\":0},{\"name\":\"Investor\",\"sharesPercentage\":0,\"investment\":0}],\"tables\":[{\"name\":\"Detailed\",\"headers\":[{\"name\":\"Ordinary Share Class\",\"total\":100},{\"name\":\"Total (fully diluted)\",\"total\":100},{\"name\":\"Issued (%)\",\"total\":100.00},{\"name\":\"Fully Diluted (%)\",\"total\":100.00},{\"name\":\"Vote (%)\",\"total\":100.00},{\"name\":\"Investment\",\"total\":0.00}],\"sections\":[{\"name\":\"Founder\",\"totals\":[100,100,100,100,100,0],\"rows\":[{\"name\":\"FounderP Person\",\"values\":[50,50,50.0,50.0,50.0,0]},{\"name\":\"Rus Marinel\",\"values\":[50,50,50.0,50.0,50.0,0]}]}]},{\"name\":\"Summary\",\"headers\":[{\"name\":\"Total (fully diluted)\",\"total\":100},{\"name\":\"Issued (%)\",\"total\":100.00},{\"name\":\"Fully Diluted (%)\",\"total\":100.00},{\"name\":\"Vote (%)\",\"total\":100.00}],\"sections\":[{\"name\":\"Ordinary shares\",\"totals\":[100,100,100,100],\"rows\":[{\"name\":\"Ordinary\",\"values\":[0,0,0,0]},{\"name\":\"Ordinary Share Class\",\"values\":[100,100,100,100]}]}]}]}";

        public static void GetAndAssertCapTableAfterShareTransfer(CapTableResponse getCapTable)
        {
            var actual = JsonSerializer.Serialize(getCapTable);
            Assert.IsTrue(string.Equals(ExpectedResultAfterShareTransfer.ToLower(), actual.ToLower(), StringComparison.OrdinalIgnoreCase));
        }

        public static string ExpectedResultAfterShareTransferForFounder = "{\"postMoneyValuation\":0,\"stakeHolders\":2,\"issuedShares\":100,\"invested\":0.00,\"totalDilutedShares\":100,\"totalFundings\":[],\"chartShareholdingDataList\":[{\"name\":\"Founder\",\"sharesPercentage\":100,\"investment\":0},{\"name\":\"Investor\",\"sharesPercentage\":0,\"investment\":0}],\"tables\":[{\"name\":\"Detailed\",\"headers\":[{\"name\":\"Ordinary Share Class\",\"total\":100},{\"name\":\"Total (fully diluted)\",\"total\":100},{\"name\":\"Issued (%)\",\"total\":100.00},{\"name\":\"Fully Diluted (%)\",\"total\":100.00},{\"name\":\"Vote (%)\",\"total\":100.00},{\"name\":\"Investment\",\"total\":0.00}],\"sections\":[{\"name\":\"Founder\",\"totals\":[100,100,100,100,100,0],\"rows\":[{\"name\":\"PersonFaunder Automatio\",\"values\":[50,50,50.0,50.0,50.0,0]},{\"name\":\"Rus Marinel\",\"values\":[50,50,50.0,50.0,50.0,0]}]}]},{\"name\":\"Summary\",\"headers\":[{\"name\":\"Total (fully diluted)\",\"total\":100},{\"name\":\"Issued (%)\",\"total\":100.00},{\"name\":\"Fully Diluted (%)\",\"total\":100.00},{\"name\":\"Vote (%)\",\"total\":100.00}],\"sections\":[{\"name\":\"Ordinary shares\",\"totals\":[100,100,100,100],\"rows\":[{\"name\":\"Ordinary Share Class\",\"values\":[100,100,100,100]}]}]}]}";

        public static void GetAndAssertCapTableAfterShareTransferForFounder(CapTableResponse getCapTable)
        {
            var actual = JsonSerializer.Serialize(getCapTable);
            Assert.IsTrue(string.Equals(ExpectedResultAfterShareTransferForFounder.ToLower(), actual.ToLower(), StringComparison.OrdinalIgnoreCase));
        }
    }
}