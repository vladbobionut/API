﻿using FluentAssertions;
using RestApi.Helpers;
using RestApi.Models.Board;

namespace Outpace.Assertions
{
    public class BoardPackAssertions
    {
        public static void AssertUpdatedBoardDetails(IEnumerable<UpdateDetailedBoardResponse>? responseBoardUpdated, Guid boardId)
        {
            var firstAttendes = responseBoardUpdated.FirstOrDefault().Attendees.FirstOrDefault(attendee => attendee.Name == "vlad one");
            firstAttendes.Should().NotBeNull();
            firstAttendes.Name.Should().Be("vlad one");
            firstAttendes.Absent.Should().Be(false);
            firstAttendes.Chairman.Should().Be(false);
            firstAttendes.BoardId.Should().Be(boardId);

            var secondAttendes = responseBoardUpdated.FirstOrDefault().Attendees.FirstOrDefault(attendee => attendee.Name == "vlad doi");
            secondAttendes.Should().NotBeNull();
            secondAttendes.Name.Should().Be("vlad doi");
            secondAttendes.Absent.Should().Be(false);
            secondAttendes.Chairman.Should().Be(true);
            secondAttendes.BoardId.Should().Be(boardId);

            var thirdAttendes = responseBoardUpdated.FirstOrDefault().Attendees.FirstOrDefault(attendee => attendee.Name == "vlad trei");
            thirdAttendes.Should().NotBeNull();
            thirdAttendes.Name.Should().Be("vlad trei");
            thirdAttendes.Absent.Should().Be(true);
            thirdAttendes.Chairman.Should().Be(false);
            thirdAttendes.BoardId.Should().Be(boardId);

            var firstDiscussionPointResponse = responseBoardUpdated.FirstOrDefault().DiscussionPoints.FirstOrDefault(discussionPoints => discussionPoints.Title == Constants.UpdateDiscussionPointTitle);
            firstDiscussionPointResponse.Should().NotBeNull();
            firstDiscussionPointResponse.Title.Should().Be(Constants.UpdateDiscussionPointTitle);
            firstDiscussionPointResponse.Notes.Should().Be(Constants.UpdateDiscussionPointNotes);
            firstDiscussionPointResponse.Link.Should().Be(Constants.UpdateDiscussionPointLink);
            firstDiscussionPointResponse.KeyActions.FirstOrDefault().Name.Should().Be("key action");
            firstDiscussionPointResponse.KeyActions.FirstOrDefault().Assignee.Should().Be("NameAssigne");

            var secondDiscussionPointResponse = responseBoardUpdated.FirstOrDefault().DiscussionPoints.FirstOrDefault(discussionPoints => discussionPoints.Title == "another simple test");
            secondDiscussionPointResponse.Should().NotBeNull();
            secondDiscussionPointResponse.Title.Should().Be("another simple test");
            secondDiscussionPointResponse.Notes.Should().Be("this is another note");
            secondDiscussionPointResponse.Link.Should().Be("www.gsp.ro");
            secondDiscussionPointResponse.KeyActions.FirstOrDefault().Name.Should().Be("Ordinary name");
            secondDiscussionPointResponse.KeyActions.FirstOrDefault().Assignee.Should().Be("TestAssigne");

            var thirdDiscussionPointResponse = responseBoardUpdated.FirstOrDefault().DiscussionPoints.FirstOrDefault(discussionPoints => discussionPoints.Title == "additional key notes");
            thirdDiscussionPointResponse.Should().NotBeNull();
            thirdDiscussionPointResponse.Title.Should().Be(Constants.UpdateThirdBoardDiscussionTitle);
            thirdDiscussionPointResponse.Notes.Should().Be(Constants.UpdateThirdBoardDiscussionNote);
            thirdDiscussionPointResponse.Link.Should().BeNull();
            thirdDiscussionPointResponse.KeyActions.Count().Should().Be(0);
        }

        public static void AssertBoard(CreateBoardRequest boardModel, IEnumerable<BoardModel>? responseBoardModel, Guid firstAttendeesId,
            Guid secondAttendeesId, Guid thirdAttendeesId, Guid firstDiscusionPointId, Guid secondDiscussionPointId)
        {
            responseBoardModel.FirstOrDefault().Venue.Should().Be(boardModel.Venue);
            responseBoardModel.FirstOrDefault().Attendees.Count.Should().Be(3);

            var attendees = responseBoardModel.FirstOrDefault().Attendees.FirstOrDefault(atendee => atendee.Name == Constants.FirstAttendee);
            attendees.Name.Should().Be(Constants.FirstAttendee);
            firstAttendeesId = attendees.Id;

            var secondAttendee = responseBoardModel.FirstOrDefault().Attendees.FirstOrDefault(atendee => atendee.Name == Constants.SecondAttendee);
            secondAttendee.Name.Should().Be(Constants.SecondAttendee);
            secondAttendeesId = secondAttendee.Id;

            var thirdAttendee = responseBoardModel.FirstOrDefault().Attendees.FirstOrDefault(atendee => atendee.Name == Constants.ThirdAttendee);
            thirdAttendee.Name.Should().Be(Constants.ThirdAttendee);
            thirdAttendeesId = thirdAttendee.Id;

            responseBoardModel.FirstOrDefault().DiscussionPoints.Count().Should().Be(2);
            var firstDiscussionPoint = responseBoardModel.FirstOrDefault().DiscussionPoints.FirstOrDefault(discussionPoint => discussionPoint.Title == Constants.FirstDiscussionPointTitle);
            firstDiscussionPoint.Title.Should().Be(Constants.FirstDiscussionPointTitle);
            firstDiscussionPoint.Link.Should().Be(Constants.DiscussionPointFirstLink);
            firstDiscusionPointId = (Guid)firstDiscussionPoint.Id;

            var secondDiscussionPoint = responseBoardModel.FirstOrDefault().DiscussionPoints.FirstOrDefault(discussionPoint => discussionPoint.Title == Constants.SecondDiscussionPointTitle);
            secondDiscussionPoint.Title.Should().Be(Constants.SecondDiscussionPointTitle);
            secondDiscussionPoint.Link.Should().Be(Constants.DiscussionPointSecondLink);
            secondDiscussionPointId = (Guid)secondDiscussionPoint.Id;

            responseBoardModel.FirstOrDefault().Category.Should().Be(Constants.Category);
        }

        public static void AssertUpdateBoard(List<UpdateDiscussionPointRequest> editDiscussionPointModel, UpdateBoardRequest editBoard, IEnumerable<BoardModel>? responseBoardEdit)
        {
            var responseBoard = responseBoardEdit.FirstOrDefault();
            responseBoard.Venue.Should().Be(editBoard.Venue);
            responseBoard.Final.Should().Be(editBoard.Final);
            responseBoard.EventDate.Should().Be(editBoard.EventDate);
            responseBoard.Attendees.FirstOrDefault(attendee => attendee.Name == Constants.EditFirstAttendee).Name.Should().Be(editBoard.Attendees[0]);
            responseBoard.Attendees.FirstOrDefault(attendee => attendee.Name == Constants.EditSecondAttendee).Name.Should().Be(editBoard.Attendees[1]);
            responseBoard.Attendees.FirstOrDefault(attendee => attendee.Name == Constants.EditThirdAttendee).Name.Should().Be(editBoard.Attendees[2]);
            responseBoard.DiscussionPoints.FirstOrDefault().Link.Should().Be(editDiscussionPointModel.FirstOrDefault().Link);
            responseBoard.DiscussionPoints.FirstOrDefault().Title.Should().Be(editDiscussionPointModel.FirstOrDefault().Title);
        }

        public static async Task AssertMarkAsFinalBoard(Guid boardId, IEnumerable<BoardModel> responseBoardUpdatedMarkAsFinal)
        {
            var response = responseBoardUpdatedMarkAsFinal.FirstOrDefault();
            response.Archived.Should().Be(true);
            response.CaptureBoardMinutes.Should().Be(true);
            response.Final.Should().Be(true);
            response.Id.Should().Be(boardId);
        }

        public static void GetMarkedBoardAsFinalAndAssert(IEnumerable<BoardModel> getResponse)
        {
            var responseBoard = getResponse.FirstOrDefault();
            responseBoard.Final.Should().Be(true);
            responseBoard.Archived.Should().Be(false);
            responseBoard.CaptureBoardMinutes.Should().Be(false);
        }
    }
}