﻿using FluentAssertions;
using RestApi.Models;
using RestApi.Models.Current_Raise;
using System.Text.Json;

namespace Outpace.Assertions
{
    public class CurentRaiseAssertions
    {
        public static async Task<List<RaiseResponse>> AssertTaylorWessingTemplate(SetTemplateSuiteRequest modelTemplateTaylorWessing, HttpResponseMessage getTWTemplate)
        {
            string getApiTWTemplate = await getTWTemplate.Content.ReadAsStringAsync();
            var getResponseTWTemplate = JsonSerializer.Deserialize<List<RaiseResponse>>(getApiTWTemplate, new JsonSerializerOptions() { PropertyNameCaseInsensitive = true });
            getResponseTWTemplate.FirstOrDefault().Id.Should().Be(modelTemplateTaylorWessing.RaiseId);
            getResponseTWTemplate.FirstOrDefault().TemplateSuite.Name.Should().Be(modelTemplateTaylorWessing.TemplateSuite.ToString());
            var getResponseTermSheet = getResponseTWTemplate.FirstOrDefault().DocumentResponses.FirstOrDefault(x => x.Name == "Term sheet");
            getResponseTermSheet.Name.Should().Be("Term sheet");
            var getResponseArticleOfAssociation = getResponseTWTemplate.FirstOrDefault().DocumentResponses.FirstOrDefault(y => y.Name == "Articles of association");
            getResponseArticleOfAssociation.Name.Should().Be("Articles of association");
            var getResponseWrittenResolution = getResponseTWTemplate.FirstOrDefault().DocumentResponses.FirstOrDefault(z => z.Name == "Written resolutions");
            getResponseWrittenResolution.Name.Should().Be("Written resolutions");
            var getResponseSeedInvestmentAgreement = getResponseTWTemplate.FirstOrDefault().DocumentResponses.FirstOrDefault(a => a.Name == "Seed investment agreement");
            getResponseSeedInvestmentAgreement.Name.Should().Be("Seed investment agreement");
            return getResponseTWTemplate;
        }
    }
}