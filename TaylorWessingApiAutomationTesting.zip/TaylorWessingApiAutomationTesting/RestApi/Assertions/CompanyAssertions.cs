﻿using FluentAssertions;
using RestApi.Models.Company;
using RestApi.Models.Enum;

namespace Outpace.Assertions
{
    public class CompanyAssertions
    {
        public static void AssertCompany(CompanyDto getResponseCompany, CompanyType companyType, string companyName, CompanyStructure companyStructure, Jurisdiction jurisdiction,
            string addressLine1, string addressLine2, string city, string companiesHouseNumber, string? currency = null, string? postalCode =null )
        {
            getResponseCompany.CompanyName.ToLower().Should().Be(companyName.ToLower());
            getResponseCompany.CompanyType.Should().Be(companyType);
            getResponseCompany.CompanyStructure.Should().Be(companyStructure);
            getResponseCompany.Jurisdiction.Should().Be(jurisdiction);
            getResponseCompany.AddressLine1.Should().Be(addressLine1);
            getResponseCompany.AddressLine2.Should().Be(addressLine2);
            getResponseCompany.City.Should().Be(city);
            getResponseCompany.CompaniesHouseNumber.Should().Be(companiesHouseNumber);
            if (currency != null && postalCode != null)
            {
                getResponseCompany.Currency.Should().Be(currency);
                getResponseCompany.Postcode.Should().Be(postalCode);
            }
        }
    }
}