﻿using FluentAssertions;
using RestApi.Models.CreateUser;
using RestApi.Models.Enum;

namespace Outpace.Assertions
{
    public class StakeholderAssertions
    {
        public static void AssertStakeholder(ApplicationUserDto? getResponseStakeholder, AccessType accessType, string lastName, string firstName,
                    string phoneNumber, string addressLine1, string addressLine2, string postalCode, string city, string email,
                    DateTime birthDate)
        {
            getResponseStakeholder.Should().NotBeNull();
            getResponseStakeholder.AddressLine1.Should().Be(addressLine1);
            getResponseStakeholder.AddressLine2.Should().Be(addressLine2);
            getResponseStakeholder.FirstName.Should().Be(firstName);
            getResponseStakeholder.LastName.Should().Be(lastName);
            getResponseStakeholder.Email.Should().Be(email);
            getResponseStakeholder.PhoneNumber.Should().Be(phoneNumber);
            getResponseStakeholder.City.Should().Be(city);
            getResponseStakeholder.Birthdate.Should().Be(birthDate);
            getResponseStakeholder.Postcode.Should().Be(postalCode);
            getResponseStakeholder.Id.Should().NotBeEmpty();
            getResponseStakeholder.AccessTypeString.Should().Be(accessType.Name);
        }
    }
}