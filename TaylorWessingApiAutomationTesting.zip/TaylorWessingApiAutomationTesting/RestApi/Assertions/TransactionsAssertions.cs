﻿using FluentAssertions;
using Microsoft.Extensions.DependencyInjection;
using Outpace.Models.Transaction;
using RestApi.FrameworkConfiguration;
using RestApi.Helpers;
using RestApi.Interfaces;
using RestApi.Models.Transaction;

namespace Outpace.Assertions
{
    public class TransactionsAssertions
    {
        public static void AssertShareTransfer(IEnumerable<TransactionDto> getShareTransfer, Guid companyId, Guid shareClassId, Guid personFounderId, Guid personInvestorId)
        {
            var shareTransfer = getShareTransfer.FirstOrDefault();
            shareTransfer.CompanyId.Should().Be(companyId);
            shareTransfer.ShareTransfers.FirstOrDefault().Date.Should().Be(Constants.DateShareTansfer);
            shareTransfer.ShareTransfers.FirstOrDefault().EventName.Should().Be(Constants.EventName);
            shareTransfer.ShareTransfers.FirstOrDefault().NumberOfShares.Should().Be(Constants.NumberOfShares);
            shareTransfer.ShareTransfers.FirstOrDefault().ShareClassId.Should().Be(shareClassId);
            shareTransfer.ShareTransfers.FirstOrDefault().ReceiverStakeholderId.Should().Be(personFounderId.ToString());
            shareTransfer.ShareTransfers.FirstOrDefault().TransfererStakeholderId.Should().Be(personInvestorId.ToString());
        }

        public static void AssertSubDivision(IEnumerable<TransactionDto> getSubDivision, Guid companyId)
        {
            var subDivision = getSubDivision.FirstOrDefault();
            subDivision.CompanyId.Should().Be(companyId);
            subDivision.ShareSubDivisions.FirstOrDefault().Date.Should().Be(Constants.DateNow);
            subDivision.ShareSubDivisions.FirstOrDefault().SplitFactor.Should().Be(Constants.SplitFactor);
        }

        public static void AssertIncorporationTransaction(IEnumerable<TransactionDto> getIncorporation, Guid companyId, Guid shareClassId)
        {
            var incorporation = getIncorporation.FirstOrDefault();
            incorporation.Should().NotBeNull();
            incorporation.CompanyId.Should().Be(companyId);
            incorporation.ClosedDate.Should().Be(Constants.CloseDate);
            incorporation.Name.Should().Be(Constants.IncorporationName);
            incorporation.Investments.FirstOrDefault().InvestmentAmount.Should().Be(Constants.InvestmentAmount);
            incorporation.Investments.FirstOrDefault().ShareQuantity.Should().Be(Constants.ShareQuantity);
            incorporation.Investments.FirstOrDefault().InvestmentType.Name.Should().Be("StandardShareIssuance");
            incorporation.Investments.FirstOrDefault().ShareClassId.Should().Be(shareClassId);
        }

        public static void AssertIncorporationWithTwoInvestments(IEnumerable<TransactionDto> getIncorporationTwoInvestments, Guid companyId, Guid shareClassId)
        {
            getIncorporationTwoInvestments.Should().NotBeNull();
            getIncorporationTwoInvestments.FirstOrDefault().Name.Should().Be(Constants.IncorporationName);
            getIncorporationTwoInvestments.FirstOrDefault().CompanyId.Should().Be(companyId);
            var firstInvestment = getIncorporationTwoInvestments.FirstOrDefault().Investments.FirstOrDefault(x => x.ShareQuantity == 10000);
            firstInvestment.Should().NotBeNull();
            firstInvestment.ShareClassId.Should().Be(shareClassId);
            firstInvestment.InvestmentAmount.Should().Be(Constants.InvestmentAmount);
            firstInvestment.ShareQuantity.Should().Be(Constants.ShareQuantity);
            var secondInvestment = getIncorporationTwoInvestments.FirstOrDefault().Investments.FirstOrDefault(y => y.ShareQuantity == 15000);
            secondInvestment.Should().NotBeNull();
            secondInvestment.ShareClassId.Should().Be(shareClassId);
            secondInvestment.InvestmentAmount.Should().Be(Constants.InvestmentAmountSecond);
            secondInvestment.ShareQuantity.Should().Be(Constants.ShareQuantitySecond);
        }

        public static void  AssertOptionPool(IEnumerable<TransactionDto> getOptionPool, Guid companyId, Guid optionPoolId, Guid shareClassId)
        {
            var optionPool = getOptionPool.FirstOrDefault();
            optionPool.CompanyId.Should().Be(companyId);
            optionPool.OptionPools.FirstOrDefault().Id.Should().Be(optionPoolId);
            optionPool.OptionPools.FirstOrDefault().PoolName.Should().Be(Constants.PoolName);
            optionPool.OptionPools.FirstOrDefault().PoolPercentage.Should().Be(Constants.PoolPercentage);
            optionPool.OptionPools.FirstOrDefault().PoolSize.Should().Be(Constants.PoolSize);
            optionPool.OptionPools.FirstOrDefault().ShareClass.Id.Should().Be(shareClassId);
        }

        public static void AsseertOptionPlan(IEnumerable<TransactionDto> getOptionPlan, Guid companyId)
        {
            var optionPlan = getOptionPlan.FirstOrDefault(x =>x.Name == "Option Plan").OptionPlans.FirstOrDefault();
            optionPlan.GrantType.Should().Be(GrantType.EMI);
            optionPlan.Cliff.Should().Be(Constants.OptionPlanCliff);
            optionPlan.Name.Should().Be(Constants.OptionPlanName);
            optionPlan.StrikePrice.Should().Be(Constants.StrikePrice);
            optionPlan.VestingOption.Should().Be(VestingOption.SimpleTime);
            optionPlan.VestingDuration.Should().Be(Constants.VestingDuration);
            optionPlan.VestingFrequency.Should().Be(Constants.VestingFrequency);
        }

        public static void AssertGrantOption(IEnumerable<TransactionDto> getGrantedOption, Guid employeeId, Guid optionPlanId)
        {
            var grantedOption = getGrantedOption.FirstOrDefault(x => x.Name == "Granted options").Grants.FirstOrDefault();
            grantedOption.EmployeeId.Should().Be(employeeId.ToString());
            grantedOption.EmployeeName.Should().Be(Constants.EmployeeName);
            grantedOption.NumberOfGrants.Should().Be(Constants.NumberOfGrants);
            grantedOption.OptionPlanId.Should().Be(optionPlanId.ToString());
            grantedOption.OptionPlanName.Should().Be(Constants.OptionPlanName);
            grantedOption.VestingDuration.Should().Be(Constants.VestingDuration);
            grantedOption.VestingFrequency.Should().Be(Constants.VestingFrequency);
        }

        public static async Task GetAndAssertNominalValuePerShare(string token, Guid companyId, string nominalValuePerShare)
        {
            string responseNominalValuePerShare = await GetAndAssertNominalValuePerShareResponse(token, companyId);
            responseNominalValuePerShare.Should().Be(nominalValuePerShare);
        }

        private static async Task<string> GetAndAssertNominalValuePerShareResponse(string token, Guid companyId)
        {
            var response = await DI.Container.GetService<IRestClient>().Get($"CapTable/GetShareNominalValue/{companyId}", token);
            response.ReasonPhrase.Should().Be("OK");
            string responseNominalValuePerShare = await response.Content.ReadAsStringAsync();
            return responseNominalValuePerShare;
        }

        public static async Task AssertConvertible(IEnumerable<TransactionDto> getConvertible, decimal discount, decimal cap, string name)
        {
            var convertible = getConvertible.FirstOrDefault().ConvertibleLoans.FirstOrDefault();
            convertible.Discount.Should().Be(discount);
            convertible.Cap.Should().Be(cap);
            convertible.ConvertibleInvestments.FirstOrDefault().StakeholderName.Should().Be(name);
        }

        public static void AssertPriceRoundTransactionWithOneInvestmentAndOptionPool(IEnumerable<TransactionDto> getTransactions, Guid companyId, Guid shareClassId)
        {
            var incorporation = getTransactions.FirstOrDefault(x => x.Name == "Incorporation Name");
            incorporation.Should().NotBeNull();
            incorporation.CompanyId.Should().Be(companyId);
            incorporation.Name.Should().Be(Constants.IncorporationName);
            incorporation.Investments.FirstOrDefault().InvestmentAmount.Should().Be(Constants.InvestmentAmount);
            incorporation.Investments.FirstOrDefault().ShareQuantity.Should().Be(Constants.ShareQuantity);
            incorporation.Investments.FirstOrDefault().InvestmentType.Name.Should().Be("StandardShareIssuance");
            incorporation.Investments.FirstOrDefault().ShareClassId.Should().Be(shareClassId);

            var priceRound = getTransactions.FirstOrDefault(x => x.Name == "FoundingRound");
            priceRound.Should().NotBeNull();
            priceRound.CompanyId.Should().Be(companyId);
            priceRound.CompanyValuation.Should().Be(500000.00M);
            priceRound.ActiveRaise.Should().BeTrue();
            priceRound.Investments.FirstOrDefault().InvestmentAmount.Should().Be(10000.00M);
            priceRound.Investments.FirstOrDefault().PricePerShare.Should().Be(50.000000000000000M);
            priceRound.Investments.FirstOrDefault().CommitedAmount.Should().Be(10000.00M);
            priceRound.Investments.FirstOrDefault().ShareQuantity.Should().Be(10000);
            priceRound.OptionPools.FirstOrDefault().PoolPercentage.Should().Be(10.00M);
            priceRound.OptionPools.FirstOrDefault().PoolSize.Should().Be(Constants.NewPoolSize);
            priceRound.OptionPools.FirstOrDefault().PoolName.Should().Be(Constants.PoolName);
        }

        public static void AssertPriceRoundTransactionWithLeadInvestorAndOptionPool(IEnumerable<TransactionDto> getTransactions, Guid companyId, Guid shareClassId)
        {
            var incorporation = getTransactions.FirstOrDefault(x => x.Name == "Incorporation Name");
            incorporation.Should().NotBeNull();
            incorporation.CompanyId.Should().Be(companyId);
            incorporation.Name.Should().Be(Constants.IncorporationName);
            incorporation.Investments.FirstOrDefault().InvestmentAmount.Should().Be(Constants.InvestmentAmount);
            incorporation.Investments.FirstOrDefault().ShareQuantity.Should().Be(Constants.ShareQuantity);
            incorporation.Investments.FirstOrDefault().InvestmentType.Name.Should().Be("StandardShareIssuance");
            incorporation.Investments.FirstOrDefault().ShareClassId.Should().Be(shareClassId);

            var priceRound = getTransactions.FirstOrDefault(x => x.Name == "FoundingRound");
            priceRound.Should().NotBeNull();
            priceRound.CompanyId.Should().Be(companyId);
            priceRound.CompanyValuation.Should().Be(500000.00M);
            priceRound.ActiveRaise.Should().BeTrue();
            priceRound.Investments.Count().Should().Be(2);
            priceRound.OptionPools.FirstOrDefault().PoolPercentage.Should().Be(10.00M);
            priceRound.OptionPools.FirstOrDefault().PoolSize.Should().Be(Constants.NewPoolSize);
            priceRound.OptionPools.FirstOrDefault().PoolName.Should().Be(Constants.PoolName);
        }
    }
}