﻿using FluentAssertions;
using RestApi.Models.Enum;
using RestApi.Models.ShareClass;

namespace Outpace.Assertions
{
    public class ShareClassAssertions
    {
        public static void AssertShareClass(IEnumerable<ShareClassDto>? getResponseShareClass, bool antiDilution, bool hurdle, decimal hurdleSharePrice, bool isEntitledForDividends, bool isEntitledForVoting,
            decimal liquidationCap, int liquidationDaysPerYear, decimal liquidationInterest, decimal liquidationMultiple, bool liquidationParticipating,
            bool liquidationPreference, decimal liquidationSeniority, string shareClassName, decimal votingRightWeight, AntiDilutionType antiDilutionType)
        {
            var getResponse = getResponseShareClass.FirstOrDefault();
            getResponseShareClass.Should().NotBeNull();
            getResponse.Id.Should().NotBeEmpty();
            getResponse.AntiDilution.Should().Be(antiDilution);
            getResponse.Hurdle.Should().Be(hurdle);
            getResponse.HurdleSharePrice.Should().Be(hurdleSharePrice);
            getResponse.IsEntitledForDividends.Should().Be(isEntitledForDividends);
            getResponse.IsEntitledForVoting.Should().Be(isEntitledForVoting);
            getResponse.LiquidationCap.Should().Be(liquidationCap);
            getResponse.LiquidationDaysPerYear.Should().Be(liquidationDaysPerYear);
            getResponse.LiquidationInterest.Should().Be(liquidationInterest);
            getResponse.LiquidationMultiple.Should().Be(liquidationMultiple);
            getResponse.LiquidationParticipating.Should().Be(liquidationParticipating);
            getResponse.LiquidationPreference.Should().Be(liquidationPreference);
            getResponse.LiquidationSeniority.Should().Be(liquidationSeniority);
            getResponse.Name.Should().Be(shareClassName);
            getResponse.VotingRightWeight.Should().Be(votingRightWeight);
            getResponse.AntiDilutionType.Id.Should().Be(antiDilutionType.Id);
            getResponse.AntiDilutionType.Name.Should().Be(antiDilutionType.Name);
        }
    }
}