﻿namespace RestApi.Models.Country
{
    public class CountryCreateRequest
    {
        public string Name { get; set; }
    }
}