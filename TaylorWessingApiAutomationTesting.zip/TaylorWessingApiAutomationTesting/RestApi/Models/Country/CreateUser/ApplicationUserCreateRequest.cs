﻿using RestApi.Models.Enum;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace RestApi.Models.CreateUser
{
    public class ApplicationUserCreateRequest
    {
        [JsonIgnore]
        public int? TenantId { get; set; } = null;
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string AddressLine1 { get; set; }
        public string? AddressLine2 { get; set; }
        public string City { get; set; }
        public string Postcode { get; set; }
        public string? PhoneNumber { get; set; }
        public string Email { get; set; }
        public bool IsShareHolder { get; set; } = false;
        public bool IsLegalEntityHolder { get; set; } = false;

        public string? Password { get; set; }
        [Compare("Password", ErrorMessage = "The password and confirmation password do not match")]
        public string? ConfirmPassword { get; set; }

        public bool IsLegalEntity { get; set; } = true;
        public Guid? NationalityId { get; set; } = null;
        public DateTime? Birthdate { get; set; }

        public bool InternalUser { get; set; }

        [Required]
        public List<AccessType> ListAccessType { get; set; }

        [Required]
        public UserCreationType UserCreationType { get; set; }

        public List<Guid>? CompanyIds { get; set; } = null;
    }
}