﻿using Outpace.Models;
using RestApi.Models.Company;
using RestApi.Models.Enum;

namespace RestApi.Models.CreateUser
{
    public class ApplicationUserDto : BaseDto
    {
        public Guid Id { get; set; }
        public List<CompanySummary> Companies { get; set; } = new();
        public int? TenantId { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? AddressLine1 { get; set; }
        public string? AddressLine2 { get; set; }
        public string? City { get; set; }
        public string? Postcode { get; set; }
        public string? PhoneNumber { get; set; }
        public bool? IsShareHolder { get; set; } = false;
        public bool? IsFounder { get; set; } = false;
        public string UserName { get; set; }
        public string Email { get; set; }
        public DateTimeOffset? LockoutEnd { get; set; }
        public bool IsActive { get { return !LockoutEnd.HasValue || DateTime.Now > LockoutEnd; } }

        // Hack to allow us to get the user type without having to make multiple DB queries
        public string AccessTypeString { get; set; }
        public List<AccessType> AccessTypes { get; set; }
        public DateTime? Birthdate { get; set; } = null;

        // Used as a stackholder for the institutions. Should not be visible by Outspace users.
        public bool InternalUser { get; set; } = false;

        public string? ProfilePath { get; set; }
    }
}