﻿using System.Text.Json.Serialization;

namespace RestApi.Models.Country
{
    public class CountryDto
    {
        [JsonPropertyName("id")]
        public Guid Id { get; set; }

        [JsonPropertyName("name")]
        public string Name { get; set; }

        [JsonPropertyName("priority")]
        public Int16 Priority { get; set; }
    }
}