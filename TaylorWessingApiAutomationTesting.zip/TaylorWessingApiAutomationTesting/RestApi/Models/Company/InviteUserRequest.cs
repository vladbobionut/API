﻿using RestApi.Models.Company;

namespace Outpace.Models.Company
{
    public class InviteUserRequest
    {
        public string Email { get; set; }
        public CompanyType CompanyType { get; set; }
        public bool IsFounder { get; set; }
        public string InvitationMessage { get; set; }
    }
}