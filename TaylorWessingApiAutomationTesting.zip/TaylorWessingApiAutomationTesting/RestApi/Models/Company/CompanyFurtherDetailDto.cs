﻿using Outpace.Models;

namespace RestApi.Models.Company
{
    public class CompanyFurtherDetailDto : BaseDto
    {
        public Guid Id { get; set; }
        public Guid CompanyId { get; set; }
        public string? LinkedIn { get; set; }
        public string? Twitter { get; set; }
        public string? Website { get; set; }
        public string? LogoPath { get; set; }
        public string? SicCodes { get; set; }
    }
}