﻿namespace RestApi.Models.Company
{
    public class CompanySummary
    {
        public Guid CompanyId { get; set; }
        public string CompanyName { get; set; }
    }
}