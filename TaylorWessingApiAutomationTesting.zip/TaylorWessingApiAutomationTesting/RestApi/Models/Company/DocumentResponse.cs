﻿using RestApi.Models.Enum;

namespace RestApi.Models.Company
{
    public class DocumentResponse
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public int SignaturesRequired { get; set; }
        public int SignaturesComplete { get; set; }
        public string? UserId { get; set; } // in case document belongs to a user
        public string? UserFullName { get; set; } // in case document belongs to a user
        public Guid? CompanyId { get; set; }
        public DocumentStatus DocumentStatus { get; set; }
        public IFrameData IFrameData { get; set; }
        public List<DocumentSignatory> Signatories { get; set; }
    }

    public class IFrameData
    {
        public long? ContractId { get; set; }
        public string LicenceId { get; set; } // 1
        public string UIBaseUrl { get; set; }
        public string AccessToken { get; set; }
    }

    public class DocumentSignatory
    {
        public string Id { get; set; }
        public string Email { get; set; }
        public string Name { get; set; }
        public bool Signed { get; set; }
        public string EnvelopeId { get; set; }
    }
}