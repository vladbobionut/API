﻿using Outpace.Models;

namespace RestApi.Models.Company
{
    public class CompanyBankDetailDto : BaseDto
    {
        public Guid Id { get; set; }
        public Guid CompanyId { get; set; }
        public Guid? BankCountryId { get; set; }
        public string? AccountName { get; set; }
        public int? SortCode { get; set; }
        public string? AccountNumber { get; set; }
        public string? SWIFT { get; set; }
        public string? IBAN { get; set; }
        public DateTime? NextAccountsDue { get; set; }
        public DateTime? NextConfirmationStatementDate { get; set; }
        public string? AccountingReferenceDate { get; set; }
        public DateTime? LastAccountsMadeUpTo { get; set; }
        public DateTime? LastConfirmationStatementDate { get; set; }
    }
}