﻿namespace RestApi.Models.Company
{
    public class StartupHomePageDetails
    {
        public string CompanyName { get; set; }
        public DateTime? IncorporationDate { get; set; }
        public string BasedIn { get; set; }
        public string? Logo { get; set; }
        public CapTableHomePageDetails? CapTable { get; set; }
        public EquityPlans? EquityPlans { get; set; }
        public CompanyLawyerDetails CompanyLawyerDetails { get; set; }
        public List<DatesData> KeyDates { get; set; } = new List<DatesData>();
        public List<DatesData> LatestActions { get; set; } = new List<DatesData>();
        public ChecklistDetails ChecklistDetails { get; set; } = new ChecklistDetails();
    }

    public class CapTableHomePageDetails
    {
        //public CapTableHomePageDetails()
        //{
        //    ChartShareholdingDataList = new();
        //}

       // public List<ChartShareholdingData> ChartShareholdingDataList { get; set; }
        public int StakeholdersCount { get; set; }
        public decimal TotalInvested { get; set; }
        public decimal LatestTransactionInvestedAmount { get; set; }
        public int TransactionsCount { get; set; }
        //public List<TotalFunding> TotalFundings { get; set; }
    }

    public class EquityPlans
    {
        public Dictionary<string, decimal> DilutedPercentages { get; set; }
        public int FullyGrantedShares { get; set; }
    }

    public class DatesData
    {
        public string Message { get; set; }
        public DateTime Date { get; set; }
    }

    public class CompanyLawyerDetails
    {
        public string FullName { get; set; }
        public string PhoneNumber { get; set; }
        public string Email { get; set; }
    }

    public class ChecklistDetails
    {
        public string Title { get; set; }
        public List<ChecklistItem> ChecklistItems { get; set; }
    }

    public class ChecklistItem
    {
        public string Name { get; set; }
        public string NavigationName { get; set; }
        public bool IsComplete { get; set; }
    }
}