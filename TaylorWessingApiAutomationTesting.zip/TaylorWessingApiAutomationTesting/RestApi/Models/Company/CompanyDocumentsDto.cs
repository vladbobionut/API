﻿using Outpace.Models;
using RestApi.Models.Enum;

namespace RestApi.Models.Company
{
    public class CompanyDocumentsDto : BaseDto
    {
        public Guid Id { get; set; }
        public string CompanyName { get; set; } = string.Empty;
        public DateTime? IncorporatedDate { get; set; }
        public string Currency { get; set; } = string.Empty;
        public CompanyType CompanyType { get; set; }
        public Jurisdiction Jurisdiction { get; set; }
        public CompanyStructure CompanyStructure { get; set; }
        public string CompaniesHouseNumber { get; set; }
        public string AddressLine1 { get; set; }
        public string? AddressLine2 { get; set; }
        public string City { get; set; }
        public string Postcode { get; set; }

      //  public virtual ICollection<ContractExpressDocumentDto> Documents { get; set; } = new List<ContractExpressDocumentDto>();
    }
}