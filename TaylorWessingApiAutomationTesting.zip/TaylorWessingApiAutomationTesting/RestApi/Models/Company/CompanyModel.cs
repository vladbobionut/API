﻿using RestApi.Models.Board;
using RestApi.Models.Company;
using RestApi.Models.Enum;

namespace Outpace.Models.Company
{
    public class CompanyModel : BaseModel
    {
        public Guid Id { get; set; }
        public string CompanyName { get; set; } = string.Empty;
        public DateTime? IncorporatedDate { get; set; }
        public string Currency { get; set; } = string.Empty;
        public CompanyType CompanyType { get; set; }
        public Jurisdiction Jurisdiction { get; set; }
        public CompanyStructure CompanyStructure { get; set; }
        public string CompaniesHouseNumber { get; set; }
        public string AddressLine1 { get; set; }
        public string? AddressLine2 { get; set; }
        public string City { get; set; }
        public string Postcode { get; set; }
        public string InstitutionName { get; set; }

        public TemplateSuite? TemplateSuite { get; set; }
        public string? CompanyEmail { get; set; }

        // For Company Logo
        public string? CompanyLogo { get; set; } = String.Empty;
        public ICollection<CompanyFurtherDetailDto> CompanyFurtherDetails { get; set; } = new List<CompanyFurtherDetailDto>();
        //public ICollection<CompanyBankDetailDto> CompanyBankDetails { get; set; } = new List<CompanyBankDetailDto>();
        public ICollection<CompanyTaxDetailDto> CompanyTaxDetails { get; set; } = new List<CompanyTaxDetailDto>();
        //public ICollection<CompanyApplicationUsersModel> CompanyApplicationUsers { get; set; } = new List<CompanyApplicationUsersModel>();
        public virtual ICollection<CompanyModel> Institutions { get; set; } = new HashSet<CompanyModel>();
        public virtual ICollection<CompanyModel> Startups { get; set; } = new HashSet<CompanyModel>();
    }
}
