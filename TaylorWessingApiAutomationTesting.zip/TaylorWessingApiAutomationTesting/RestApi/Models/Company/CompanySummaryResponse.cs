﻿namespace RestApi.Models.Company
{
    public class CompanySummaryResponse
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
    }
}