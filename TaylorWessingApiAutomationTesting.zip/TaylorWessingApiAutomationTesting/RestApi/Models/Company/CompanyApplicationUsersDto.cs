﻿namespace RestApi.Models.Company
{
    public class CompanyApplicationUsersDto
    {
        public Guid CompanyId { get; set; }
        public string UserId { get; set; }
    }
}