﻿namespace RestApi.Models.Company
{
    public class CompanyTaxDetailDto
    {
        public Guid Id { get; set; }
        public Guid CompanyId { get; set; }
        public string UTR { get; set; }
        public int HMRCOfficeReferenceNumber { get; set; }
        public string VATNumber { get; set; }
    }
}