﻿namespace RestApi.Models.Company
{
    public class InvestorStartupDetails
    {
        public Guid Id { get; set; }
        public string CompanyName { get; set; }
        public StartupStage Stage { get; set; } = new StartupStage();
        public decimal PostMoneyValuation { get; set; }
        public decimal Profit { get; set; }
        public decimal Invested { get; set; }
        public decimal EquityPercentage { get; set; }
        public string Currency { get; set; }
        public Dictionary<string, decimal> DilutedPercentages { get; set; }
        public List<StartupStakeholderDetails> StartupStakeholderDetails { get; set; } = new List<StartupStakeholderDetails>();
        public List<string> LatestActions { get; set; } = new List<string>();
        public List<string> Reminders { get; set; } = new List<string>()
        {
            "Next board meeting due",
            "MI Report due"
        };
    }

    public class StartupStakeholderDetails
    {
        public bool IsFounder { get; set; }
        public string Name { get; set; }
        public decimal DilutedPercentage { get; set; }
        public decimal Profit { get; set; }
        public bool IsCurrentInvestor { get; set; }
        public decimal InvestedAmount { get; set; }
    }

    public class StartupStage
    {
        public bool Complete { get; set; }
        public string Stage { get; set; }
    }
}