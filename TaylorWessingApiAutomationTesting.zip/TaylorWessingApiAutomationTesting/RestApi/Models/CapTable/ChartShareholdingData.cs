﻿namespace RestApi.Models.CapTable
{
    public class ChartShareholdingData
    {
        public string Name { get; set; }
        public decimal SharesPercentage { get; set; }
        public decimal Investment { get; set; }
    }
}