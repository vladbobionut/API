﻿namespace RestApi.Models.CapTable
{
    public class TransactionSummaryListDto
    {
        public Guid CapTableId { get; set; }
        public string Name { get; set; }
        public DateTime DateOfTransaction { get; set; }
    }
}