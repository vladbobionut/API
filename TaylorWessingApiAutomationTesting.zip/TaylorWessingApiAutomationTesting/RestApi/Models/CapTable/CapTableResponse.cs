﻿using RestApi.Models.CapTable;
using System.Text.Json.Serialization;

namespace Contracts.Catalog.CapTable.Transactions
{
    public class CapTableResponse
    {
        public CapTableResponse()
        {
            Tables = new List<Table>();
            ChartShareholdingDataList = new();
            TotalFundings = new();
        }

        [JsonPropertyName("postMoneyValuation")]
        public decimal PostMoneyValuation { get; set; }

        [JsonPropertyName("stakeHolders")]
        public int StakeHolders { get; set; }
        [JsonPropertyName("issuedShares")]
        public decimal IssuedShares { get; set; }
        [JsonPropertyName("invested")]
        public decimal Invested { get; set; }

        [JsonPropertyName("totalDilutedShares")]
        public long TotalDilutedShares { get; set; }

        [JsonPropertyName("totalFundings")]
        public List<TotalFunding> TotalFundings { get; set; }
        [JsonPropertyName("chartShareholdingDataList")]
        public List<ChartShareholdingData> ChartShareholdingDataList { get; set; }
        [JsonPropertyName("tables")]
        public List<Table> Tables { get; set; }
    }

    public class Table
    {
        public Table()
        {
            Headers = new List<TableHeaders>();
            Sections = new List<Section>();
        }
        [JsonPropertyName("name")]
        public string Name { get; set; }
        [JsonPropertyName("headers")]
        public List<TableHeaders> Headers { get; set; }
        [JsonPropertyName("sections")]
        public List<Section> Sections { get; set; }
    }

    public class TableHeaders
    {
        [JsonPropertyName("name")]
        public string Name { get; set; }
        [JsonPropertyName("total")]
        public decimal Total { get; set; }
    }

    public class Section
    {
        public Section()
        {
            Totals = new List<decimal?>();
            Rows = new List<Row>();
        }
        [JsonPropertyName("name")]
        public string Name { get; set; }
        [JsonPropertyName("totals")]    
        public List<decimal?> Totals { get; set; }
        [JsonPropertyName("rows")]
        public List<Row> Rows { get; set; }
    }

    public class Row
    {
        public Row()
        {
            Values = new List<decimal?>();
        }
        [JsonPropertyName("name")]
        public string Name { get; set; }
        [JsonPropertyName("values")]
        public List<decimal?> Values { get; set; }
    }
}