﻿namespace RestApi.Models.CapTable
{
    public class ShareRegisterInvestment
    {
        public string Stakeholder { get; set; }
        public string ShareClass { get; set; }
        public decimal SharesNumber { get; set; }
        public string Date { get; set; }
        public string Address { get; set; }
        public Guid InvestmentId { get; set; }
    }

    public class ShareRegisterResponce
    {
        public int Count { get; set; }
        public ShareRegisterInvestment[] Items { get; set; }
    }
}