﻿namespace RestApi.Models.CapTable
{
    public class TransactionDetailDto
    {
        public TransactionDetailDto()
        {
            Tables = new List<Table>();
            ChartShareholdingDataList = new();
            TotalFundings = new();
        }

        public decimal PostMoneyValuation { get; set; }
        public int StakeHolders { get; set; }
        public decimal IssuedShares { get; set; }
        public decimal Invested { get; set; }
        public List<TotalFunding> TotalFundings { get; set; }
        public List<ChartShareholdingData> ChartShareholdingDataList { get; set; }
        public List<Table> Tables { get; set; }
    }

    public class Table
    {
        public Table()
        {
            Headers = new List<TableHeaders>();
            Sections = new List<Section>();
        }
        public string Name { get; set; }
        public List<TableHeaders> Headers { get; set; }
        public List<Section> Sections { get; set; }
    }

    public class TableHeaders
    {
        public string Name { get; set; }
        public decimal Total { get; set; }
    }

    public class Section
    {
        public Section()
        {
            Totals = new List<decimal?>();
            Rows = new List<Row>();
        }
        public string Name { get; set; }
        public List<decimal?> Totals { get; set; }
        public List<Row> Rows { get; set; }
    }

    public class Row
    {
        public Row()
        {
            Values = new List<decimal?>();
        }
        public string Name { get; set; }
        public List<decimal?> Values { get; set; }
    }
}