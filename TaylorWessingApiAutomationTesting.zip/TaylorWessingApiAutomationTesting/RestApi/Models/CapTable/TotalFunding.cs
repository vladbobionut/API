﻿namespace RestApi.Models.CapTable
{
    public class TotalFunding
    {
        //public decimal Funding { get; set; }
    }
}