﻿namespace RestApi.Models
{
    public class NameOfTheService
    {
        public const string SectionName = "NameOfTheService";
        public string BaseUrl { get; set; }
    }
}