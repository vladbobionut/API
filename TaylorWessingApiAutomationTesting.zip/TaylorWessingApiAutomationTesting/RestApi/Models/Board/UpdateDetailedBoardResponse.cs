﻿namespace RestApi.Models.Board
{
    public class UpdateDetailedBoardResponse
    {
        public List<UpdateDetailedBoardDiscussionPointResponse> DiscussionPoints { get; set; }
        public List<UpdateDetailedBoardAttendeeResponse> Attendees { get; set; }
    }
}