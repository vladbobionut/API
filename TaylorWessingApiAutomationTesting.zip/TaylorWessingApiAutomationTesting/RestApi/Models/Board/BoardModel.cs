﻿namespace RestApi.Models.Board
{
    public class BoardModel : BaseModel
    {
        public Guid Id { get; set; }
        public DateTime EventDate { get; set; }
        public string Venue { get; set; }
        public List<AttendeeModel> Attendees { get; set; }
        public bool Final { get; set; } = false;
        public bool Archived { get; set; } = false;
        public bool CaptureBoardMinutes { get; set; } = false;
        public string? Category { get; set; }
        public List<DiscussionPointModel> DiscussionPoints { get; set; }
    }
}