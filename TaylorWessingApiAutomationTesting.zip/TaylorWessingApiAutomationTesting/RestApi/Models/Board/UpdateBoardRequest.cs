﻿using System.ComponentModel.DataAnnotations;

namespace RestApi.Models.Board
{
    public class UpdateBoardRequest
    {

        [Required(ErrorMessage = "Company is required")]
        public Guid CompanyId { get; set; }

        [Required(ErrorMessage = "EventDate is required")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:MM/dd/yyyy}")]
        public DateTime EventDate { get; set; }

        [StringLength(100, ErrorMessage = "Venue can't be longer than 100 characters")]
        public string Venue { get; set; }
        public List<string> Attendees { get; set; }
        public bool Final { get; set; } = false;
    }
}