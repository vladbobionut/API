﻿namespace RestApi.Models.Board
{
    public class UpdateDetailedBoardDiscussionPointRequest : DiscussionPointModel
    {
    }
}