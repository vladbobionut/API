﻿using System.ComponentModel.DataAnnotations;

namespace RestApi.Models.Board
{
    public class AttendeeModel
    {
        public Guid Id { get; set; }
        [StringLength(30, ErrorMessage = "Attendee can't be longer than 30 characters")]
        public string Name { get; set; }
        public bool Absent { get; set; }
        public bool Chairman { get; set; }
        public Guid BoardId { get; set; }
    }
}