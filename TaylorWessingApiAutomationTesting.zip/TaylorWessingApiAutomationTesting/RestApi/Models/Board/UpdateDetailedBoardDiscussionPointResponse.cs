﻿namespace RestApi.Models.Board
{
    public class UpdateDetailedBoardDiscussionPointResponse : DiscussionPointModel
    {
    }
}