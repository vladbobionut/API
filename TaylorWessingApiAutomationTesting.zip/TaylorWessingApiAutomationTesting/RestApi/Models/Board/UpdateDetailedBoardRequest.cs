﻿namespace RestApi.Models.Board
{
    public class UpdateDetailedBoardRequest
    {
        public List<UpdateDetailedBoardDiscussionPointRequest> DiscussionPoints { get; set; }
        public List<UpdateDetailedBoardAttendeeRequest> Attendees { get; set; }
    }
}