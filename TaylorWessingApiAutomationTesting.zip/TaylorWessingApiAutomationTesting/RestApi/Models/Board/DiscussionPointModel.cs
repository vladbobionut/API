﻿using System.ComponentModel.DataAnnotations;

namespace RestApi.Models.Board
{
    public class DiscussionPointModel
    {
        public Guid? Id { get; set; } = Guid.Empty;
        public string Title { get; set; }
        public string? Link { get; set; }
        public Guid BoardId { get; set; }
        public List<KeyActionModel> KeyActions { get; set; }
        [StringLength(1200, ErrorMessage = "Notes can't be longer than 1200 characters")]
        public string? Notes { get; set; }
    }
}