﻿namespace RestApi.Models.Board
{
    public class UpdateDetailedBoardAttendeeRequest : AttendeeModel
    {

    }
}