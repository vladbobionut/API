﻿using System.ComponentModel.DataAnnotations;

namespace RestApi.Models.Board
{
    public class KeyActionModel
    {
        public Guid? Id { get; set; } = Guid.Empty;
        [StringLength(250, ErrorMessage = "Key Action can't be longer than 250 characters")]
        public string Name { get; set; }
        [StringLength(30, ErrorMessage = "Assignee can't be longer than 30 characters")]
        public string? Assignee { get; set; }
        public DateTime? Deadline { get; set; }
    }
}