﻿namespace RestApi.Models.Board
{
    public class UpdateDiscussionPointRequest
    {
        public Guid Id { get; set; }
        public string Title { get; set; }
        public string? Link { get; set; }
        public Guid BoardId { get; set; }
    }
}