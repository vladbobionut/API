﻿namespace RestApi.Models.Board
{
    public class CreateDiscussionPointRequest
    {
        public string Title { get; set; }
        public string? Link { get; set; }
    }
}