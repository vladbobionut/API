﻿namespace RestApi.Models.Board
{
    public class UpdateDetailedBoardAttendeeResponse : AttendeeModel
    {

    }
}