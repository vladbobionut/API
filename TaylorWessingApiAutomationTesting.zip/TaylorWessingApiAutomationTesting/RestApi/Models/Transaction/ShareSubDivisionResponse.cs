﻿namespace RestApi.Models.Transaction
{
    public class ShareSubDivisionResponse
    {
        public Guid Id { get; set; }
        public int SplitFactor { get; set; }
        public decimal PreviousNominalValue { get; set; }
        public decimal NominalValue { get; set; }
        public DateTime Date { get; set; }
    }
}