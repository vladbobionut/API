﻿namespace RestApi.Models.Transaction
{
    public class BaseShareTransferRequest
    {
        public string EventName { get; set; }
        public Guid TransfererStakeholderId { get; set; }
        public Guid ReceiverStakeholderId { get; set; }
        public Guid ShareClassId { get; set; }
        public DateTime Date { get; set; }
        public int NumberOfShares { get; set; }
    }
}