﻿using System.ComponentModel.DataAnnotations;

namespace RestApi.Models.Transaction
{
    public class OptionPoolCreateRequest 
    {
        public Guid CompanyId { get; set; }
        public DateTime Date { get; set; }
        public bool ReservedShares { get; set; }
        [StringLength(50, ErrorMessage = "Option pool name limit is 50 characters")]
        public string PoolName { get; set; }
        public Guid ShareClassId { get; set; }
        public int PoolSize { get; set; }
        public decimal PoolPercentage { get; set; }
    }
}