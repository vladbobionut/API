﻿using System.ComponentModel.DataAnnotations;

namespace Outpace.Models.Transaction
{
    public class OptionPlanCreateRequest 
    {
        [Required]
        public Guid CompanyId { get; set; }
        [StringLength(50, ErrorMessage = "Option plan name limit is 50 characters")]
        public string Name { get; set; }
        public DateTime Date { get; set; }
        public decimal StrikePrice { get; set; }
        public VestingOption VestingOption { get; set; }
        public DateTime VestingStartDate { get; set; }
        public int VestingDuration { get; set; }
        public int VestingFrequency { get; set; }
        public int Cliff { get; set; }
        [Required]
        public Guid OptionPoolId { get; set; }
        [Required]
        public GrantType GrantType { get; set; }
    }
}