﻿using RestApi.Models.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Outpace.Models.Transaction
{
    public class GrantType : Enumeration
    {
        public static GrantType EMI = new(1, nameof(EMI));

        public GrantType(int id, string name)
            : base(id, name)
        {
        }
    }
}
