﻿namespace RestApi.Models.Transaction
{
    public class ShareTransferResponse
    {
        public Guid Id { get; set; }
        public string EventName { get; set; }
        public string TransfererStakeholderId { get; set; }
        public string TransfererName { get; set; }
        public string ReceiverStakeholderId { get; set; }
        public string ReceiverName { get; set; }
        public Guid ShareClassId { get; set; }
        public string ShareClassName { get; set; }
        public int NumberOfShares { get; set; }
        public DateTime Date { get; set; }
    }
}