﻿using RestApi.Models.Board;
using RestApi.Models.ShareClass;

namespace Outpace.Models.Transaction
{
    public class OptionPoolModel : BaseModel
    {
        public Guid Id { get; set; }
        public string PoolName { get; set; }
        public int PoolSize { get; set; }
        public ShareClassDto ShareClass { get; set; }
        public Guid CapTableId { get; set; }
        public decimal PoolPercentage { get; set; }
    }
}