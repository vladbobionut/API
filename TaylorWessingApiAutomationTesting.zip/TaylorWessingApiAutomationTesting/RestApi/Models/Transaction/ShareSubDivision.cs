﻿namespace RestApi.Models.Transaction
{
    public class ShareSubDivision : AuditEntityBase<Guid>
    {
        public Guid CompanyId { get; set; }
        public int SplitFactor { get; set; }
        public decimal NominalValue { get; set; }
        public DateTime Date { get; set; }
    }
}