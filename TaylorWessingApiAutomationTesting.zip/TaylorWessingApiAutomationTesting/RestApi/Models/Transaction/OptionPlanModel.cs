﻿using RestApi.Models.Board;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Outpace.Models.Transaction
{
    public class OptionPlanModel : BaseModel
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public DateTime Date { get; set; }
        public decimal StrikePrice { get; set; }
        public VestingOption VestingOption { get; set; }
        public DateTime VestingStartDate { get; set; }
        public int VestingDuration { get; set; }
        public int VestingFrequency { get; set; }
        public int Cliff { get; set; }
        public Guid OptionPoolId { get; set; }
        public string OptionPoolName { get; set; }
        public GrantType GrantType { get; set; }

    }
}
