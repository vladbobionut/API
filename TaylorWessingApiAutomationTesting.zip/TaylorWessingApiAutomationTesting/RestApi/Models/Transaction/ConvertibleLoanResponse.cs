﻿using Outpace.Models.Transaction;

namespace RestApi.Models.Transaction
{
    public class ConvertibleLoanResponse
    {
        public Guid Id { get; set; }
        public Guid CompanyId { get; set; }
        public string? Name { get; set; }
        public DateTime IssueDate { get; set; }
        public DateTime? MaturityDate { get; set; }
        public decimal? Cap { get; set; }
        public bool UseCPPS { get; set; }
        public decimal? Discount { get; set; }
        public DateTime? InterestStartDate { get; set; }
        public bool? PayBackAtConversion { get; set; }
        public int? DaysPerYear { get; set; }
        public decimal? AnnualInterestPercentage { get; set; }
        public bool? PostMoney { get; set; }
        public bool IsConverted { get; set; }
        public int PreMoneyShareQuantity { get; set; }
        public int PreMoneyShareQuantityWithInstruments { get; set; }
        public List<ConvertibleInvestmentResponse> ConvertibleInvestments { get; set; } = new();
        public List<ConversionBaseType> ConversionBasis { get; set; } = new();
        public List<ConvertibleClauseType> ConvertibleClauses { get; set; } = new();
    }

    public class ConvertibleInvestmentResponse
    {
        public Guid Id { get; set; }
        public string UserId { get; set; }
        public string StakeholderName { get; set; }
        public decimal AmountCommitted { get; set; }
        public decimal InvestmentAmount { get; set; }
        public decimal PricePerShare { get; set; }
        public decimal? InterestAcquiredToDate { get; set; }
        public int NumberOfShares { get; set; }
        public decimal AmountOfResultingEquity { get; set; }
        public bool UseCPPS { get; set; }
    }
}