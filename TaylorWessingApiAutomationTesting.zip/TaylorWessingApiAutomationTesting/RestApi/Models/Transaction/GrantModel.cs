﻿namespace Outpace.Models.Transaction
{
    public class GrantModel
    {
        public Guid? Id { get; set; }
        public DateTime GrantDate { get; set; }
        public DateTime? ExpiryDate { get; set; }
        public string EmployeeId { get; set; }
        public string? EmployeeName { get; set; }
        public Guid OptionPlanId { get; set; }
        public string? OptionPlanName { get; set; }
        public int NumberOfGrants { get; set; }
        public int VestingDuration { get; set; }
        public int VestingFrequency { get; set; }
        public int Cliff { get; set; }
    }
}