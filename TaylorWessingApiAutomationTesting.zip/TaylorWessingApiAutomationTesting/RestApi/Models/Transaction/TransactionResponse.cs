﻿using RestApi.Models.Board;
using RestApi.Models.Enum;
using RestApi.Models.Transaction;

namespace Outpace.Models.Transaction
{
    public class TransactionResponse : BaseModel
    {
        public Guid Id { get; set; }
        public Guid CompanyId { get; set; }
        public string Name { get; set; }
        public DateTime? ClosedDate { get; set; } = DateTime.Now;
        public decimal? ShareNominalValue { get; set; } = null;
        public TransactionType TransactionType { get; set; }
        public decimal? CompanyValuation { get; set; } = 0;
        public bool ArchivedRaise { get; set; }
        public bool ActiveRaise { get; set; }
        public ICollection<InvestmentDto> Investments { get; set; }
        public ICollection<OptionPoolModel> OptionPools { get; set; }
        public ICollection<OptionPlanModel> OptionPlans { get; set; }
        public ICollection<ConvertibleLoanResponse> ConvertibleLoans { get; set; }
        public ICollection<ShareSubDivisionResponse> ShareSubDivisions { get; set; }
        public ICollection<ShareTransferResponse> ShareTransfers { get; set; }
        public ICollection<OptionPoolChangeResponse> OptionPoolChanges { get; set; }
        public ICollection<GrantModel> Grants { get; set; }
    }
}