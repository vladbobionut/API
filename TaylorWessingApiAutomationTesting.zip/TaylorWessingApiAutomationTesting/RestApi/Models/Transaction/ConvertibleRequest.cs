﻿using Outpace.Models.Transaction;

namespace RestApi.Models.Transaction
{
    public class ConvertibleRequest
    {
        public Guid Id { get; set; }
        public decimal ValuationCap { get; set; }
        public decimal Interest { get; set; }
        public List<ConversionBaseType> ConversionBasis { get; set; }
        public List<ConvertibleClauseType> ConvertibleClauses { get; set; }
        public List<ConvertibleInvestmentConvertRequest> ConvertibleInvestments { get; set; }
    }
}