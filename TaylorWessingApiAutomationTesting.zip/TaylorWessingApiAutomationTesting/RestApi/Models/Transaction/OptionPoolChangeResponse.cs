﻿namespace Outpace.Models.Transaction
{
    public class OptionPoolChangeResponse
    {
        public Guid OptionPoolId { get; set; }
        public string OptionPoolName { get; set; }
        public ChangePair<int> Size { get; set; }
        public ChangePair<decimal> Percentage { get; set; }
        public ChangePair<string> ShareClass { get; set; }
    }

    public class ChangePair<T>
    {
        public T From { get; set; }
        public T To { get; set; }
    }
}