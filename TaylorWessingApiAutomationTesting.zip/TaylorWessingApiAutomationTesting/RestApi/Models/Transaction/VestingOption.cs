﻿using RestApi.Models.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Outpace.Models.Transaction
{
    public class VestingOption : Enumeration
    {
        public static VestingOption SimpleTime = new(1, "Simple time-based vesting");

        public VestingOption(int id, string name)
            : base(id, name)
        {
        }
    }
}
