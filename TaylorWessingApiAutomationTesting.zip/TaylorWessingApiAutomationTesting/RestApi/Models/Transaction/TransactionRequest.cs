﻿using RestApi.Models.Enum;
using System.ComponentModel.DataAnnotations;

namespace RestApi.Models.Transaction
{
    public class TransactionRequest
    {
        [Required]
        public Guid CompanyId { get; set; }

        [RegularExpression(pattern: "^[a-zA-Z0-9 _-]+$", ErrorMessage = "Invalid Event Name")]
        public string Name { get; set; }
        public decimal PricePerShare { get; set; }
        public decimal PreMoneyValuation { get; set; }
        public long IssuedShareCapital { get; set; }
        public DateTime? ClosedDate { get; set; } = DateTime.Now;
        public TransactionType TransactionType { get; set; }
        public List<InvestmentCreateRequest> Investments { get; set; }
        public List<OptionPoolCreateRequest> OptionPools { get; set; }
        public List<ConvertibleRequest> Convertibles { get; set; } = new List<ConvertibleRequest>() { };
    }
}