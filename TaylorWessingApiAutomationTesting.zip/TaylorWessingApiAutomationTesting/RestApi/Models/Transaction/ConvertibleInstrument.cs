﻿using RestApi.Models.Enum;

namespace RestApi.Models.Transaction
{
    public class ConvertibleInstrument
    {
        public Guid? Id { get; set; }
        public string Name { get; set; }
        public int NumberOfShares { get; set; }
        public ConvertibleInstrumentType ConvertibleInstrumentType { get; set; }
    }
}