﻿using RestApi.Models.Enum;
using System.Reflection;

namespace Outpace.Models.Transaction
{
    public class ConversionBaseType : Enumeration
    {
        public static ConversionBaseType IssuedShareCapital = new(1, nameof(IssuedShareCapital));
        public static ConversionBaseType ESOPIncrease = new(2, nameof(ESOPIncrease));
        public static ConversionBaseType ESOPAllocatedShareOptions = new(3, nameof(ESOPAllocatedShareOptions));
        public static ConversionBaseType ConversionShares = new(4, nameof(ConversionShares));
        public static ConversionBaseType NewInvestorShares = new(8, nameof(NewInvestorShares));

        public ConversionBaseType(int id, string name)
            : base(id, name)
        {
        }

        public static ConversionBaseType GetById(int id)
        {
            foreach (var field in typeof(ConversionBaseType).GetFields(
                BindingFlags.Public | BindingFlags.Static))
            {
                if (field.FieldType == typeof(ConversionBaseType))
                {
                    var instance = (ConversionBaseType)field.GetValue(null);
                    if (instance.Id == id)
                        return instance;
                }
            }
            return null;
        }
    }
}