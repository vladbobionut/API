﻿using Outpace.Models.Transaction;
using System.ComponentModel.DataAnnotations;

namespace RestApi.Models.Transaction
{
    public class CreateConvertibleLoanRequest
    {
        [Required]
        public Guid CompanyId { get; set; }
        [Required]
        public DateTime IssueDate { get; set; }
        public string Name { get; set; }
        public DateTime? MaturityDate { get; set; }
        public decimal? Cap { get; set; }
        public decimal? Discount { get; set; }
        public decimal? AnnualInterestPercentage { get; set; }
        public bool? PayBackAtConversion { get; set; }
        public int? DaysPerYear { get; set; } = 365;
        public bool Completed { get; set; } = false;
        public List<ConvertibleInvestment> ConvertibleInvestments { get; set; }
        public List<ConversionBaseType> ConversionBasis { get; set; }
        public List<ConvertibleClauseType> ConvertibleClauses { get; set; }
    }

    public class ConvertibleInvestment
    {
        public Guid UserId { get; set; }
        public decimal AmountCommitted { get; set; }
    }
}