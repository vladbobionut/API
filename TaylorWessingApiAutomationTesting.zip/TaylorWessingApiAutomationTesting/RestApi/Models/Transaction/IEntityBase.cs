﻿namespace RestApi.Models.Transaction
{
    public interface IEntityBase<TKey>
    {
        TKey Id { get; set; }
    }
}