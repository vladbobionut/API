﻿namespace Outpace.Models.Transaction
{
    public class GrantCreateRequest : GrantModel
    {
        public Guid CompanyId { get; set; }
    }
}