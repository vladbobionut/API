﻿namespace RestApi.Models.Transaction
{
    public class ConvertibleInvestmentConvertRequest
    {
        public Guid Id { get; set; }
        public int ShareQuantity { get; set; }
        public decimal InvestmentAmount { get; set; }
        public Guid ShareClassId { get; set; }
        public decimal AmountOfResultingEquity { get; set; }
        public decimal PricePerShare { get; set; }
        public bool UseCPPS { get; set; }
    }
}