﻿using RestApi.Models.Enum;
using System.Reflection;

namespace Outpace.Models.Transaction
{
    public class ConvertibleClauseType : Enumeration
    {
        public static ConvertibleClauseType MostFavouredNation = new(9, nameof(MostFavouredNation));
        public static ConvertibleClauseType ProRata = new(10, nameof(ProRata));

        public ConvertibleClauseType(int id, string name)
            : base(id, name)
        {
        }

        public static ConvertibleClauseType GetById(int id)
        {
            foreach (var field in typeof(ConvertibleClauseType).GetFields(
                BindingFlags.Public | BindingFlags.Static))
            {
                if (field.FieldType == typeof(ConvertibleClauseType))
                {
                    var instance = (ConvertibleClauseType)field.GetValue(null);
                    if (instance.Id == id)
                        return instance;
                }
            }
            return null;
        }
    }
}