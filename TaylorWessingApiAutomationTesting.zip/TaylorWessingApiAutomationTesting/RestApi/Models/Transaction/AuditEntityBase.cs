﻿namespace RestApi.Models.Transaction
{
    public abstract class AuditEntityBase<TKey> : AuditEntity, IEntityBase<TKey>
    {
        public virtual TKey Id { get; set; }
    }
}