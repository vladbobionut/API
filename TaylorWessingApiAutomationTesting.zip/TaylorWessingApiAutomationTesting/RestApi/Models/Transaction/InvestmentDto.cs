﻿using Outpace.Models;
using Outpace.Models.Transaction;
using RestApi.Models.CreateUser;
using RestApi.Models.Enum;
using RestApi.Models.ShareClass;
using TransactionType = RestApi.Models.Enum.TransactionType;

namespace RestApi.Models.Transaction
{
    public class InvestmentDto : BaseDto
    {
        public Guid Id { get; set; }
        public Guid ShareClassId { get; set; }
        public Guid CapTableId { get; set; }
        public string UserId { get; set; }
        public int ShareQuantity { get; set; }
        public decimal CommitedAmount { get; set; }
        public decimal InvestmentAmount { get; set; }
        public decimal PricePerShare { get; set; }
        public DateTime ClosedDate { get; set; }
        public ShareClassDto ShareClass { get; set; }
        public ApplicationUserDto ApplicationUser { get; set; }
        public TransactionType InvestmentType { get; set; }
    }
}