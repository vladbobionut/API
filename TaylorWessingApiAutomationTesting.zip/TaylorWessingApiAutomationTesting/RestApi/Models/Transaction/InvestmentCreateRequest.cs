﻿using RestApi.Models.Enum;

namespace RestApi.Models.Transaction
{
    public class InvestmentCreateRequest
    {
        public Guid ShareClassId { get; set; }
        public Guid UserId { get; set; }
        public int ShareQuantity { get; set; }
        public decimal CommitedAmount { get; set; }
        public decimal InvestmentAmount { get; set; }
        public decimal PricePerShare { get; set; }
        public DateTime ClosedDate { get; set; }
        public InvestmentType InvestmentType { get; set; }
        public bool LeadInvestor { get; set; } = false;
    }
}