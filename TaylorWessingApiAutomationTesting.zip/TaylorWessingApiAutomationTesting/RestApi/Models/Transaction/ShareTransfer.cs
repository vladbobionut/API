﻿namespace RestApi.Models.Transaction
{
    public class ShareTransfer : AuditEntityBase<Guid>
    {
        public Guid CompanyId { get; set; }
        public string EventName { get; set; }
        public string Company { get; set; }
        public string TransfererStakeholderId { get; set; }
        public string ReceiverStakeholderId { get; set; }
        public Guid ShareClassId { get; set; }
        public Guid ShareClass { get; set; }
        public DateTime Date { get; set; }
        public int NumberOfShares { get; set; }
    }
}