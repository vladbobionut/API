﻿using Microsoft.AspNetCore.Http;

namespace Outpace.Models.Help
{
    public class HelpRequest
    {
        public string DescriptionMessage { get; set; }
        public string Subject { get; set; }
        public string CompanyId { get; set; }
        public IFormFile? ReferenceImage { get; set; }
    }
}