﻿namespace RestApi.Models.Enum
{
    public class Jurisdiction : Enumeration
    {
        public static Jurisdiction EnglandAndWales = new(1, nameof(EnglandAndWales));
        public static Jurisdiction Scotland = new(2, nameof(Scotland));
        public static Jurisdiction NorthernIreland = new(3, nameof(NorthernIreland));

        public Jurisdiction(int id, string name)
            : base(id, name)
        {
        }
    }
}