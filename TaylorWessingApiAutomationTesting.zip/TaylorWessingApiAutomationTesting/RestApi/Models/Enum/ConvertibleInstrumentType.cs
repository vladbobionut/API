﻿namespace RestApi.Models.Enum
{
    public class ConvertibleInstrumentType : Enumeration
    {
        public static ConvertibleInstrumentType IssuedShareCapital = new(1, nameof(IssuedShareCapital));
        public static ConvertibleInstrumentType ESOPIncrease = new(2, nameof(ESOPIncrease));
        public static ConvertibleInstrumentType ESOPAllocatedShareOptions = new(3, nameof(ESOPAllocatedShareOptions));
        public static ConvertibleInstrumentType ConversionShares = new(4, nameof(ConversionShares));
        public static ConvertibleInstrumentType ESOPUnallocatedShareOptions = new(5, nameof(ESOPUnallocatedShareOptions));
        public static ConvertibleInstrumentType OtherConvertibleInstruments = new(6, nameof(OtherConvertibleInstruments));
        public static ConvertibleInstrumentType CustomConvertibleInstruments = new(7, nameof(CustomConvertibleInstruments));

        public ConvertibleInstrumentType(int id, string name)
            : base(id, name)
        {
        }
    }
}