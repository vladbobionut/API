﻿namespace RestApi.Models.Enum
{
    public class AntiDilutionType : Enumeration
    {
        public static AntiDilutionType WeightedAverageBroad = new(1, nameof(WeightedAverageBroad));
        public static AntiDilutionType WeightedAverageNarrow = new(2, nameof(WeightedAverageNarrow));
        public static AntiDilutionType FullRatchet = new(3, nameof(FullRatchet));

        public AntiDilutionType(int id, string name)
            : base(id, name)
        {
        }
    }
}