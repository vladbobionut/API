﻿namespace RestApi.Models.Enum
{
    public class CompanyStructure : Enumeration
    {
        public static CompanyStructure LTD = new(1, nameof(LTD));  // Private Company Limited by Shares
        public static CompanyStructure LLP = new(2, nameof(LLP));  // Limited Liability Partnership
        public static CompanyStructure LP = new(3, nameof(LP)); // Limited Partnerhip
        public static CompanyStructure PLC = new(4, nameof(PLC)); // Public Limited Company
        public static CompanyStructure PUC = new(5, nameof(PUC)); // Private Unlimited Company
        public static CompanyStructure Other = new(6, nameof(Other)); // Other Company Type

        public CompanyStructure(int id, string name)
            : base(id, name)
        {
        }
    }
}