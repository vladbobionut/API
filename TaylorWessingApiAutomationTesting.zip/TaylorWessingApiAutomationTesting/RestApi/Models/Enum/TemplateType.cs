﻿namespace RestApi.Models.Enum
{
    public class TemplateType : Enumeration
    {
        public static TemplateType TermSheet = new(1, nameof(TermSheet));
        public static TemplateType SIA = new(2, nameof(SIA));
        public static TemplateType ArticleOfAssociation = new(3, nameof(ArticleOfAssociation));
        public static TemplateType Safe = new(4, nameof(Safe));
        public static TemplateType CompletionAgenda = new(5, nameof(CompletionAgenda));
        public static TemplateType WrittenResolutions = new(6, nameof(CompletionAgenda));
        public static TemplateType IPAssignment = new(7, nameof(IPAssignment));
        public static TemplateType FounderServiceAgreement = new(8, nameof(FounderServiceAgreement));
        public TemplateType(int id, string name) : base(id, name)
        {

        }
    }
}