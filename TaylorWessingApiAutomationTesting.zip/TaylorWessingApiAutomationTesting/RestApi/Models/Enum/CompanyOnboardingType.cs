﻿namespace RestApi.Models.Enum
{
    public class CompanyOnboardingType : Enumeration
    {
        public static CompanyOnboardingType Institution = new(1, nameof(Institution));
        public static CompanyOnboardingType StartUp = new(2, nameof(StartUp));
        public CompanyOnboardingType(int id, string name)
            : base(id, name)
        {
        }
    }
}