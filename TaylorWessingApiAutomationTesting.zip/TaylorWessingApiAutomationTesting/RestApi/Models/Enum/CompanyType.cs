﻿using RestApi.Models.Enum;

namespace RestApi.Models.Company
{
    public class CompanyType : Enumeration
    {
        public static CompanyType Institution = new(1, nameof(Institution));
        public static CompanyType Startup = new(2, nameof(Startup));

        public CompanyType(int id, string name)
            : base(id, name)
        {
        }
    }
}