﻿namespace RestApi.Models.Enum
{
    public class UserCreationType : Enumeration
    {
        public static UserCreationType RegisteredByAdmin = new(1, nameof(RegisteredByAdmin));
        public static UserCreationType NoOnBoarding = new(2, nameof(NoOnBoarding));
        public UserCreationType(int id, string name)
            : base(id, name)
        {
        }
    }
}