﻿namespace RestApi.Models.Enum
{
    public class DocumentStatus : Enumeration
    {
        public static DocumentStatus NotStarted = new(1, nameof(NotStarted));
        public static DocumentStatus Incomplete = new(2, nameof(Incomplete));
        public static DocumentStatus Draft = new(3, nameof(Draft));
        public static DocumentStatus Final = new(4, nameof(Final));
        public static DocumentStatus SentForSignature = new(5, nameof(SentForSignature));
        public static DocumentStatus Signed = new(6, nameof(Signed));

        public DocumentStatus(int id, string name)
            : base(id, name)
        {
        }
    }
}