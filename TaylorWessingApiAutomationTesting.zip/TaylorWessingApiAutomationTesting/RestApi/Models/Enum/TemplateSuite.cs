﻿namespace RestApi.Models.Enum
{
    public class TemplateSuite : Enumeration
    {
        public static TemplateSuite TaylorWessing = new(1, nameof(TaylorWessing));
        public static TemplateSuite StarCodon = new(2, nameof(StarCodon));
        public static TemplateSuite Illumina = new(3, nameof(Illumina));

        public TemplateSuite(int id, string name)
            : base(id, name)
        {
        }
    }
}