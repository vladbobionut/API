﻿namespace RestApi.Models.Enum
{
    public class InvestmentType : Enumeration
    {
        public static InvestmentType StandardShareIssuance = new(1, nameof(StandardShareIssuance));
        public static InvestmentType AntiDilutionShareIssuance = new(2, nameof(AntiDilutionShareIssuance));
        public static InvestmentType ShareTransfer = new(3, nameof(ShareTransfer));
        public static InvestmentType ConvertibleLoanShareIssuance = new(4, nameof(ConvertibleLoanShareIssuance));

        public InvestmentType(int id, string name)
            : base(id, name)
        {
        }
    }
}