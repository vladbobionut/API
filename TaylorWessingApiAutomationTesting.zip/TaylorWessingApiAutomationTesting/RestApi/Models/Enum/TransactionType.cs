﻿namespace RestApi.Models.Enum
{
    public class TransactionType : Enumeration
    {
        public static TransactionType Incorporation = new(1, nameof(Incorporation));
        public static TransactionType FundingRound = new(2, nameof(FundingRound));
        public static TransactionType ConvertibleLoan = new(3, nameof(ConvertibleLoan));
        public static TransactionType ShareSubDivision = new(4, nameof(ShareSubDivision));
        public static TransactionType ShareTransfer = new(5, nameof(ShareTransfer));

        public TransactionType(int id, string name)
            : base(id, name)
        {
        }
    }
}