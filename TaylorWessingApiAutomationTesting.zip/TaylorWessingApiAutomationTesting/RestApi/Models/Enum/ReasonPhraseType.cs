﻿using RestApi.Models.Enum;

namespace Outpace.Models.Enum
{
    public class ReasonPhraseType : Enumeration
    {
        public static ReasonPhraseType OK = new(1, nameof(OK));
        public static ReasonPhraseType Created = new(2, nameof(Created));
        public static ReasonPhraseType Forbidden = new(3, nameof(Forbidden));
        public static ReasonPhraseType Unauthorized = new(4, nameof(Unauthorized));
       

        public ReasonPhraseType(int id, string name)
            : base(id, name)
        {
        }
    }
}