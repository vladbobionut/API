﻿namespace RestApi.Models.Enum
{
    public class EmailAuthenticationMethod : Enumeration
    {
        public static EmailAuthenticationMethod SMTP = new(1, nameof(SMTP));
        public static EmailAuthenticationMethod OAuth = new(2, nameof(OAuth));

        public EmailAuthenticationMethod(int id, string name)
            : base(id, name)
        {
        }
    }
}