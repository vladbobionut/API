﻿using RestApi.Models.Enum;

namespace Outpace.Models.Enum
{
    public class Role : Enumeration
    {
        public static Role PlatformAdmin = new(1, "platform admin");
        public static Role Lawyer = new(2, nameof(Lawyer).ToLower());
        public static Role Founder = new(3, nameof(Founder).ToLower());
        public static Role InstitutionAdmin = new (4, "institution admin");
        public static Role Investor = new(5, nameof(Investor).ToLower());

        public Role(int id, string name)
            : base(id, name)
        {
        }
    }
}
