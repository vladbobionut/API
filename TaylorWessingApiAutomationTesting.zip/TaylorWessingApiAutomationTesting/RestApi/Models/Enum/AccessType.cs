﻿namespace RestApi.Models.Enum
{
    public class AccessType : Enumeration
    {
        public static AccessType InstitutionAdmin = new(1, nameof(InstitutionAdmin));
        public static AccessType StartUpAdmin = new(2, nameof(StartUpAdmin));
        public static AccessType Founder = new(3, nameof(Founder));
        public static AccessType Investor = new(4, nameof(Investor));
        public static AccessType TWLawyer = new(5, nameof(TWLawyer));
        public static AccessType PlatformAdmin = new(6, nameof(PlatformAdmin));
        public static AccessType Employee = new(7, nameof(Employee));

        public AccessType(int id, string name)
            : base(id, name)
        {
        }
    }
}