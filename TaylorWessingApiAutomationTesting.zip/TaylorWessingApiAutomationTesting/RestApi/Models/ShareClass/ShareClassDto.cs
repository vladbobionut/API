﻿using Outpace.Models;
using RestApi.Models.Enum;

namespace RestApi.Models.ShareClass
{
    public class ShareClassDto : BaseDto
    {
        public Guid Id { get; set; }
        public Guid CompanyId { get; set; }
        public string Name { get; set; }
        public bool IsEntitledForVoting { get; set; } = false;
        public bool IsEntitledForDividends { get; set; } = false;
        public decimal? VotingRightWeight { get; set; }
        public bool IsUsed { get; set; }

        public bool Hurdle { get; set; } = false;
        public decimal? HurdleSharePrice { get; set; } = null;

        public bool LiquidationPreference { get; set; } = false;
        public decimal? LiquidationSeniority { get; set; } = null;
        public decimal? LiquidationMultiple { get; set; } = null;
        public bool? LiquidationParticipating { get; set; } = null;
        public decimal? LiquidationCap { get; set; } = null;
        public decimal? LiquidationInterest { get; set; } = null;
        public int? LiquidationDaysPerYear { get; set; } = null;

        public bool? AntiDilution { get; set; } = null;
        public AntiDilutionType? AntiDilutionType { get; set; } = null;
    }
}