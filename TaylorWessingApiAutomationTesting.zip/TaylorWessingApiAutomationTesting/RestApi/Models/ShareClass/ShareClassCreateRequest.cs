﻿using RestApi.Models.Enum;
using System.ComponentModel.DataAnnotations;

namespace RestApi.Models.ShareClass
{
    public class ShareClassCreateRequest
    {
        [Required]
        public Guid CompanyId { get; set; }
        public string Name { get; set; }
        public bool IsEntitledForVoting { get; set; } = false;
        public bool IsEntitledForDividends { get; set; } = false;

        [Range(0, int.MaxValue, ErrorMessage = "Only positive voting right weight allowed")]
        public decimal? VotingRightWeight { get; set; } = null;

        public bool Hurdle { get; set; } = false;

        [Range(0, int.MaxValue, ErrorMessage = "Only positive hurdle share price allowed")]
        public decimal? HurdleSharePrice { get; set; } = null;

        public bool LiquidationPreference { get; set; } = false;

        [Range(0, int.MaxValue, ErrorMessage = "Only positive seniority allowed")]
        public decimal? LiquidationSeniority { get; set; }

        [Range(0, int.MaxValue, ErrorMessage = "Only positive multiple allowed")]
        public decimal? LiquidationMultiple { get; set; }

        public bool? LiquidationParticipating { get; set; }

        [Range(0, int.MaxValue, ErrorMessage = "Only positive cap allowed")]
        public decimal? LiquidationCap { get; set; }

        [Range(0, int.MaxValue, ErrorMessage = "Only positive interest allowed")]
        public decimal? LiquidationInterest { get; set; }

        [Range(0, int.MaxValue, ErrorMessage = "Only positive days per year allowed")]
        public int? LiquidationDaysPerYear { get; set; }

        public bool? AntiDilution { get; set; } = null;
        public AntiDilutionType? AntiDilutionType { get; set; } = null;
    }
}