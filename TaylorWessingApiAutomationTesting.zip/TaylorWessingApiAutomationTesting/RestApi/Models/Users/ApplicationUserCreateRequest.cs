﻿using RestApi.Models.Enum;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace Outpace.Models.Users
{
    public class ApplicationUserCreateRequest 
    {
        [JsonIgnore]
        public int? TenantId { get; set; } = null;
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string AddressLine1 { get; set; }
        public string? AddressLine2 { get; set; }
        public string City { get; set; }
        public string Postcode { get; set; }
        public string? PhoneNumber { get; set; }
        public string Email { get; set; }
        public bool IsLegalEntityHolder { get; set; } = false;

        public string? Password { get; set; }
        [Compare("Password", ErrorMessage = "The password and confirmation password do not match")]
        public string? ConfirmPassword { get; set; }

        public bool IsLegalEntity { get; set; } = true;
        public Guid? NationalityId { get; set; } = null;
        public DateTime? Birthdate { get; set; }

        // Used as a stackholder for the institutions. Should not be visible by Outspace users.
        public bool InternalUser { get; set; }

        [Required]
        public List<AccessType> ListAccessType { get; set; }

        [Required]
        public UserCreationType UserCreationType { get; set; }

        public List<Guid>? CompanyIds { get; set; } = null;

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if (ListAccessType.Contains(AccessType.Employee) && IsLegalEntity)
                yield return new ValidationResult("The stakeholder can't be an employee and a legal entity at the same time!");
            if (ListAccessType.Contains(AccessType.Employee) && UserCreationType != UserCreationType.NoOnBoarding)
                yield return new ValidationResult("The employee can not have access to the platform!");
        }
    }
}