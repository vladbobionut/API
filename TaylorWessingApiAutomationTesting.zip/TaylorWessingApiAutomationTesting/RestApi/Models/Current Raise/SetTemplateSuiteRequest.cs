﻿using RestApi.Models.Enum;

namespace RestApi.Models.Current_Raise
{
    public class SetTemplateSuiteRequest
    {
        public Guid CompanyId { get; set; }
        public Guid RaiseId { get; set; }
        public TemplateSuite TemplateSuite { get; set; }
    }
}