﻿using RestApi.Models.Company;
using RestApi.Models.Enum;

namespace RestApi.Models
{
    public class RaiseResponse
    {
        public Guid Id { get; set; }
        public Guid? CapTableId { get; set; }
        public TemplateSuite? TemplateSuite { get; set; }
        public bool? InvestmentReceived { get; set; }
        public string? CoSecMessage { get; set; }

        public List<RaiseHeaderItem> RaiseHeaderItems { get; set; }

        public List<DocumentResponse> DocumentResponses { get; set; } = new List<DocumentResponse>();
    }

    public class RaiseHeaderItem
    {
        public string Title { get; set; }
        public string Value { get; set; }
    }
}