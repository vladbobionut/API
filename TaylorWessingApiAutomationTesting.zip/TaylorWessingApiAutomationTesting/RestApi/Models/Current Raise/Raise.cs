﻿using RestApi.Models.Enum;
using RestApi.Models.Transaction;
using System.Reflection.Metadata;

namespace RestApi.Models.Current_Raise
{
    public class Raise : AuditEntityBase<Guid>
    {
        public bool InvestmentReceived { get; set; } = false;
        public bool ActiveRaise { get; set; } = false;
        public bool CoSecSubmitted { get; set; } = false;
        public bool ArchivedRaise { get; set; } = false;
        public TemplateSuite? TemplateSuite { get; set; }

        public Guid CompanyId { get; set; }
        public Guid? CapTableId { get; set; }
        public Guid? ConvertibleId { get; set; }
        public ICollection<Document>? Documents { get; set; }
    }
}