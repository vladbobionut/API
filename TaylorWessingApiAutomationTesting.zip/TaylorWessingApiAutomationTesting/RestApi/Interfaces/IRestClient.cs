﻿namespace RestApi.Interfaces
{
    public interface IRestClient
    {
        Task<HttpResponseMessage> Post<TModel>(TModel model, string endpoint, string token, string? subscriptionKey = null);
        Task<HttpResponseMessage> PostFormData<TModel>(TModel requestObject, string endpoint, string token, string? subscriptionKey = null);
        Task<HttpResponseMessage> Get(string endpoint, string token, string? subscriptionKey = null);
        Task<HttpResponseMessage> Patch<TModel>(TModel model, string endpoint, string token, string? subscriptionKey = null);
        Task<HttpResponseMessage> Put<TModel>(TModel model, string endpoint, string token, string? subscriptionKey = null);
        Task<HttpResponseMessage> Delete(string endpoint, string token, string? subscriptionKey = null);
    }
}