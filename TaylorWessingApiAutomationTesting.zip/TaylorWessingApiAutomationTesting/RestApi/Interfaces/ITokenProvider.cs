﻿namespace RestApi.Interfaces
{
    public interface ITokenProvider
    {
        Task<string> GetAccessTokenWithRole(string role);
        Task<string> GetAccessTokenWithUserNameAndPassword(string username, string password);
    }
}